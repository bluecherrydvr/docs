#include "common.h"
#include "mpeg4_read_header.h"

char *MP4_search_header(char * target, int target_len, char *patten, int patten_len)
{
	int i;
	int patten_pos=0;
	//printf("target_len=%d\n", target_len);
	//printf("patten_len=%d\n", patten_len);
	for( i=0 ; i<target_len ; i++ )
	{
	
	
		if((char)(target+i)[0] == (char)(patten)[patten_pos])
		{
			//printf("i=%d\n", i);
			//printf("%02x == %02x patten pos-%d\n", (target+i)[0], (patten)[patten_pos], patten_pos);
			if(patten_len == patten_pos+1)
			{
				//printf("ahah2\n");
				return (char *)(target+i-patten_len+1);
			}
			patten_pos++;
		}
		else
		{
			//printf("%02x != %02x patten pos-%d\n", (target+i)[0], (patten)[patten_pos], patten_pos);
			i=i-patten_pos;
			patten_pos=0;
		}
	}
	return NULL;
}

#define MP4_BSWAP(a) ((a) = (((a) & 0xff) << 24)  | (((a) & 0xff00) << 8) | (((a) >> 8) & 0xff00) | (((a) >> 24) & 0xff))
/*******************************************
Inputs:
	base: the begining of the stream(address)
	shift: the begining of thevalue(in bit)
	target_len: how much bit this value have. max value is 16
	
Outputs:
	Return value is the value on the shift address
*******************************************/
int MP4_get_value(char *base, int shift, int target_len)
{
	char buf[4];
	int value;
	int first_block=shift/8;
	int last_block=(shift+target_len)/8;
	int num_block=last_block-first_block+1;
	int i;

	for(i=num_block-1;i>=0;i--)
	{
		buf[i]=base[first_block+i];
	}
	value=*(int *)buf;

	MP4_BSWAP(value);

	value=((value<<(shift%8))>>(32-target_len))&(~(0xffffffff<<(target_len)));

	return value;
}

int __inline log2bin(uint32_t value)
{
/* Changed by Chenm001 */
	int n = 0;

	while (value) {
		value >>= 1;
		n++;
	}
	return n;
}

/**************************************
input:
	the begining of the stream(address)
output:
	Frame type
	0:I frame
	1:P frame
	2:B frame
**************************************/
int MP4_read_header_01b6(char * buf)
{
	char patten[4]={0,0,0x01,0xb6};
	char *head;
	int shift=0;

	//printbuf(buf, 128);
	head =MP4_search_header(buf,128, patten, 4);
	if(head!=NULL)
	{
		shift=32;
		return MP4_get_value(head, shift, 2);
	}
	return MP4_FAIL;
}

void MP4_read_header_0120(char * buf, MP4_STREAM_ATTR *mps_stream_attr)
{
	int vol_ver_id;
	int low_delay;
	int shape;
	int time_increment_resolution;
	int time_inc_bits=1;
	int fps=0;
	int width=0;
	int height=0;
	
	char *head;
	int shift=0;
	int tmp;
	char patten[4]={0,0,0x01,0x20};

	head =MP4_search_header(buf,128, patten, 4);
	if(head!=NULL)
	{
		shift+=32; 	/*video_object_layer_start_code*/
		
		//printf("random_accessible_vol:%d\n", MP4_get_value(head, shift, 1));				/*random_accessible_vol*/
		shift+=1;

		//printf("video_object_type_indication:%d\n", MP4_get_value(head, shift, 8));		/* video_object_type_indication */
		shift+=8;

		//printf("is_object_layer_identifier:%d\n", MP4_get_value(head, shift, 1));			/* is_object_layer_identifier */
		if(MP4_get_value(head, shift++, 1))	
		{
			vol_ver_id = MP4_get_value(head, shift, 4);
			shift+=4;				/* video_object_layer_verid */
			shift+=3;				/* video_object_layer_priority */
		}
		else
		{
			vol_ver_id = 1;
		}
		//printf("vol_ver_id:%d\n", vol_ver_id);
		
		tmp=MP4_get_value(head, shift, 4);			/* aspect_ratio_info */
		shift+=4;
		//printf("aspect_ratio_info:%d\n", tmp);
		if(tmp == 15)
		{
			shift+=8;			/* par_width */
			shift+=8;			/* par_height */		
		}
		//printf("vol_control_parameters:%d\n", MP4_get_value(head, shift, 1));
		if(MP4_get_value(head, shift++, 1))		/* vol_control_parameters */
		{
			shift+=2;		/* chroma_format */
			low_delay=MP4_get_value(head, shift++, 1);	/* low_delay */
			if(MP4_get_value(head, shift++, 1))		/* vbv_parameters */
			{
			#if 0
				shift+=15;		/* first_half_bitrate */
				shift++;			
				shift+=15;		/* latter_half_bitrate */
				shift++;			
				shift+=15;		/* first_half_vbv_buffer_size */
				shift++;			
				shift+=3;
				shift+=11;		/* first_half_vbv_occupancy */
				shift++;
				shift+=15;		/* latter_half_vbv_occupancy */
				shift++;
			#else
				shift+=79;
			#endif
			}
		}

		shape=MP4_get_value(head, shift, 2);	/* video_object_layer_shape */
		shift+=2;
		//printf("shape:%d\n", shape);

		if (shape == 3 && vol_ver_id != 1) 
		{
				shift+=4;	/* video_object_layer_shape_extension */
		}

		shift++;

		time_increment_resolution = MP4_get_value(head, shift, 16);	/* vop_time_increment_resolution */
		shift+=16;
		fps = ( time_increment_resolution > 1000 ) ? time_increment_resolution / 1000 : time_increment_resolution;
		//printf("time_increment_resolution:%d\n", time_increment_resolution);
		//printf("fps:%d\n", fps);
		if (time_increment_resolution > 0) 
		{
			time_inc_bits = log2bin(time_increment_resolution-1);
		}

		//printf("time_inc_bits:%d\n", time_inc_bits);
		shift++;

		if(MP4_get_value(head, shift++, 1))		/* fixed_vop_rate */
		{
			MP4_get_value(head, shift, time_inc_bits);	/* fixed_vop_time_increment */
			shift+=time_inc_bits;
		}

		if(shape == 0)
		{
			shift++;
			width=MP4_get_value(head, shift, 13);	/* video_object_layer_width */
			shift+=13;
			
			shift++;
			height=MP4_get_value(head, shift, 13);	/* video_object_layer_height */
			shift+=13;
			
		}
		mps_stream_attr->fps=fps;
		mps_stream_attr->width=width;
		mps_stream_attr->height=height;
		//printf("fps:%d, width:%d, height:%d\n", fps, width, height);
	}
	else
	{
		printf("<MP4_read_header 20>Can't find 20 header!\n");
	}
	

	
}


