#include "common.h"

#include "msgQ.h"





int messageQ_create(int *msgid, int msgkey)
{
	*msgid=msgget((key_t)msgkey, (0666 | IPC_CREAT));
	if(*msgid == -1)
	{
		printf("<messageQ_create>create fail! error: %s\n", strerror(errno));
		return MSG_FAIL;
	}
	messageQ_clean(*msgid);
	//cdr_msg(DBG_INFO,"<messageQ_create> create msgQ for %d success\n", *msgid);
	return MSG_SUCCESS;
}

int messageQ_len(int msgid)
{
	struct msqid_ds my_msgid_ds;
	if(msgctl(msgid, IPC_STAT, &my_msgid_ds)==-1){
		printf( "<Messsage_send_VPlay> msgctl fail, error: %s\n", strerror(errno));
		return MSG_FAIL;
	}else{
		return my_msgid_ds.msg_qnum;
	}
	return MSG_FAIL;
}

int messageQ_clean(int msgid)
{
	s_message message;
	
	while(messageQ_len(msgid) != 0)
	{
		messageQ_receve(msgid, &message, NONBOLCK);
	}
	return MSG_SUCCESS;
}

int messageQ_send(int msgid, void *message)
{
	if(msgsnd(msgid, (const void*)message, S_MESSAGE_LEN, 0) == -1)
	{
		printf("<messageQ_send>message send fail!err:%s\n", strerror(errno));
		return MSG_FAIL;
	}
	
	return MSG_SUCCESS;
}

int messageQ_receve(int msgid, void *message, int block)
{
	if(block)
	{
		if(msgrcv(msgid, (void *)message, S_MESSAGE_LEN, 0, 0) == -1)
		{
			printf("<messageQ_receve>message receve fail (block)\n");
			return MSG_FAIL;
		}
	}
	else
	{
		if(msgrcv(msgid, (void *)message, S_MESSAGE_LEN, 0, IPC_NOWAIT) == -1)
		{
			//printf("<messageQ_receve>message receve fail (nonblock)\n");
			return MSG_FAIL;
		}
	}
		
	return MSG_SUCCESS;
}

