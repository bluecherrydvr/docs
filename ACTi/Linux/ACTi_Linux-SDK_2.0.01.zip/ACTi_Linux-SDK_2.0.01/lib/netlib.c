// vim: ts=4 sw=4
/* #######################################################################
 * netlib.c
 * created by MingYoung for ASOC2200 Encoder platform.
 * date: 2006/07/19
 * Description:
 *     Provide function calls for networking access
 * ####################################################################### */
#include "common.h"
#include "netlib.h"

static unsigned long get_time_diff(struct timeval *begin, struct timeval *end) {
	unsigned long time_diff = 0;
	
	if(end->tv_sec >= begin->tv_sec) {
		time_diff = (end->tv_sec - begin->tv_sec) * 1000; /* in msec*/
	} else {
		time_diff = ((0xffffffff-begin->tv_sec)+end->tv_sec+1) * 1000; /* in msec*/
	}

	if(end->tv_usec >= begin->tv_usec) {
		time_diff += ((end->tv_usec-begin->tv_usec)/1000); /* in msec */
	} else {
		time_diff -= 1000;
		time_diff += (((1000000-begin->tv_usec)+end->tv_usec)/1000); /* in msec */
	}
	return time_diff;
}

/* check_timeout:
 *    check if the time interval between @begin and now is larget then the @max_time.
 *    if it does, timeout occurs.
 * inputs:
 *    begin   : the start time of record
 *    max_time: the max duration from @begin we could allowed!! the unit of max_time is msec
 * return:
 *    1: timeout occurs
 *    0: otherwise */
static int check_timeout(struct timeval *begin, unsigned long max_time) {
	struct timeval tnow;
	unsigned long time_diff;

	(void)gettimeofday(&tnow, NULL);

	/* time_diff = tnow - tout */
	time_diff = get_time_diff(begin, &tnow);
	//printf("time_diff=%d\n", time_diff);
	if(time_diff >= max_time) {
		/*
		printf("<NETLIB>: TIMEOUT (%d.%d-%d.%d=%dmsec, %d msec)\n", \
				(unsigned int)tnow.tv_sec, (unsigned int)tnow.tv_usec/1000, \
				(unsigned int)begin->tv_sec, (unsigned int)begin->tv_usec/1000, \
				(unsigned int)time_diff, (unsigned int)max_time);
		*/
	  	return 1;
	}
	return 0;
}

int bind_socket(int sock, char *ip, int port) {
	struct sockaddr_in addr;

	addr.sin_family = AF_INET;
	if(strlen(ip)) {
		addr.sin_addr.s_addr = inet_addr(ip);
	} else {
		addr.sin_addr.s_addr = htonl(INADDR_ANY);
	}
	addr.sin_port = htons(port);
	
	if(bind(sock, (struct sockaddr *) &addr, sizeof(struct sockaddr_in)) < 0)
		return NETLIB_ERR_BIND;
	
	return NETLIB_SUCCESS;
}

int connect_socket(int sock, char *ip, int port, int timeout) {
	struct sockaddr_in addr;
	struct timeval tnow;
	struct timeval tout;
	fd_set         tx_fd;
	int rc=0;

	addr.sin_family = AF_INET;
	if(strlen(ip)) {
		addr.sin_addr.s_addr = inet_addr(ip);
	} else {
		addr.sin_addr.s_addr = htonl(INADDR_ANY);
	}
	addr.sin_port = htons(port);

	set_socket_block_mode(sock, NETLIB_SOCK_BLOCK_OFF);
	
	connect(sock, (struct sockaddr *)&addr, sizeof(struct sockaddr_in));
		
	/* non-block mode */
	FD_ZERO(&tx_fd);
	gettimeofday(&tnow, NULL);
	do {
		FD_SET(sock, &tx_fd);
		tout.tv_sec  = 0;
		tout.tv_usec = NETLIB_TIME_TICK;
		rc = select(sock+1, (fd_set *)0, &tx_fd, (fd_set *)0, &tout);
		if(rc > 0) {
			if(FD_ISSET(sock, &tx_fd)) {
				set_socket_block_mode(sock, NETLIB_SOCK_BLOCK_ON);
				return NETLIB_SUCCESS;
			} else 
			{
				return  NETLIB_ERR_READ;
			}
		} else 
		if(rc < 0) 
		{
			return NETLIB_ERR_READ;
		}
		/* check if the receiving timer is expired */
		if(check_timeout(&tnow, timeout)) 
		{
			return NETLIB_ERR_CONNECT;
		}
		
	} while(1);

	
	
	return NETLIB_ERR_CONNECT;
}

int create_udp_socket(int *sock) {

	*sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
	if(*sock < 0) return NETLIB_ERR_SOCKET;
	return NETLIB_SUCCESS;
}

int create_tcp_socket(int *sock) {
	
	*sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if(*sock < 0) return NETLIB_ERR_SOCKET;
	return NETLIB_SUCCESS;
}

int listen_socket(int sock, int backlog) {

	if(listen(sock, backlog) < 0) return NETLIB_ERR_LISTEN;
	return NETLIB_SUCCESS;
}

/* read_udp_socket:
 *    receive data from UDP socket @sock to the @buf within the max interval
 * @poll_time.
 * inputs:
 *    sock     : tcp socket file descriptor
 *    buf      : start address of the data which is going to be put into
 *    mlen     : the max size of containing received data in @buf
 *    host     : the return of the sender address
 *    poll_time: the max duration of receiving this data. the unit of it is msec. If it is 0,
 *               the block mode is used!!
 * return:
 *    NETLIB_ERR_READ: read error due to fail in recv() or FD_SET error or select error.
 *    length of received data: otherwise. */
int read_udp_socket(int sock, char *buf, int mlen, struct sockaddr_in *host, unsigned long poll_time) {
	struct timeval tout;
	struct timeval tnow;
	socklen_t      addr_len = sizeof(struct sockaddr_in);
	fd_set         rx_fd;
	int            n = 0;
	int            ret = 0;
	int            len = 0;

	if(poll_time == 0) { /* block mode */
		len = recvfrom(sock, (char *)buf, mlen, 0, (struct sockaddr *)host, &addr_len);
		if(len < 0) return NETLIB_ERR_READ;
		else        return len;
	}

	/* non-block mode */
	FD_ZERO(&rx_fd);
	(void)gettimeofday(&tnow, NULL);

		FD_SET(sock, &rx_fd);
		tout.tv_sec  = 0;
		tout.tv_usec = poll_time*1000;
		n = select(sock+1, &rx_fd, (fd_set *)0, (fd_set *)0, &tout);
		if(n > 0) {
			if(FD_ISSET(sock, &rx_fd)) { /* have data in the socket */
				ret = recvfrom(	sock, \
								(char *)(buf+len), \
								(mlen-len), \
								0, \
								(struct sockaddr *)host, \
								&addr_len);	
				if(ret > 0) len += ret;
				else
				{
					printf("%s\n", strerror(errno));
					return NETLIB_ERR_READ;
				}
			} else return NETLIB_ERR_READ;
		} else if(n < 0) return NETLIB_ERR_READ;

	return len;
}

/* read_tcp_socket:
 *    receive data from TCP socket @sock to the @buf within the max interval
 * @poll_time.
 * inputs:
 *    sock     : tcp socket file descriptor
 *    buf      : start address of the data which is going to be put into
 *    max_len  : the max size of containing received data in @buf
 *    poll_time: the max duration of receiving this data. the unit of it is msec. If it is 0,
 *               the block mode is used!!
 * return:
 *    NETLIB_ERR_READ: read error due to fail in recv() or FD_SET error or select error.
 *    length of received data: otherwise. */
int read_tcp_socket(int sock, char *buf, int max_len, unsigned long poll_time) {
	struct timeval tnow;
	struct timeval tout;
	fd_set         rx_fd;
	int            n = 0;
	int            ret = 0;
	int            len = 0;
	
	if(poll_time == 0) {
		/* block mode */
		len = recv(sock, (char *)buf, max_len, 0);
		if(len < 0) return NETLIB_ERR_READ;
		else		return len;
	}
	
	/* non-block mode */
	FD_ZERO(&rx_fd);
	(void)gettimeofday(&tnow, NULL);
	do {
		FD_SET(sock, &rx_fd);
		tout.tv_sec  = 0;
		tout.tv_usec = NETLIB_TIME_TICK;
		n = select(sock+1, &rx_fd, (fd_set *)0, (fd_set *)0, &tout);
		if(n > 0) {	/* have data in the socket */
			if(FD_ISSET(sock, &rx_fd)) {	/* for this socket */
				ret = recv(sock, (char *)(buf+len), (max_len-len), 0);
				if(ret > 0) len += ret;
				else        return  NETLIB_ERR_READ;
			} else return  NETLIB_ERR_READ;
		} else if(n < 0) return NETLIB_ERR_READ;
		/* check if the receiving timer is expired */
		if(check_timeout(&tnow, poll_time)) return len;
	} while(len < max_len);
	return len;
}

/* set_broadcast_addr:
 *    set the SO_BROADCAST socket option to the @sock
 * input:
 *    sock: socket file descriptor of the socket
 * return:
 *    NETLIB_SUCCESS    : set the socket option successfully
 *    NETLIB_ERR_SET_OPT: otherwise */
int set_broadcast_addr(int sock) {
	int broadcast = 1;

	if(setsockopt(sock, SOL_SOCKET, SO_BROADCAST, &broadcast, sizeof(broadcast)) == -1)
		return NETLIB_ERR_SET_OPT;
	return NETLIB_SUCCESS;
}

/* set_mcast_interface:
 *    set the IP_MULTICAST_IF socket option to the socket @sock
 * inputs:
 *    sock: file descriptor of the socket
 *    ip  : IP address of the interface which is going to be binded.
 *          if the *ip is empty, it will use the INADDR_ANY to bind
 *          the multicast interface
 * return:
 *    NETLIB_SUCCESS    : set the socket option successfully
 *    NETLIB_ERR_SET_OPT: otherwise */
int set_mcast_interface(int sock, char *ip) {
	struct in_addr addr;

	if(strlen(ip)) {
		addr.s_addr = inet_addr(ip);
	} else {
		addr.s_addr = htonl(INADDR_ANY);
	}

	if(setsockopt(sock, IPPROTO_IP, IP_MULTICAST_IF, &addr, sizeof(addr)) == -1)
		return NETLIB_ERR_SET_OPT;
	return NETLIB_SUCCESS;
}

/* set_mcast_interface for receiver:
 *    set the IP_MULTICAST_IF socket option to the socket @sock
 * inputs:
 *    sock: file descriptor of the socket
 *    ipm  : IP address of the interface which is going to be binded.
 *          if the *ip is empty, it will use the INADDR_ANY to bind
 *          the multicast interface
 * return:
 *    NETLIB_SUCCESS    : set the socket option successfully
 *    NETLIB_ERR_SET_OPT: otherwise 
 *
 * note: add by Crota 20071018*/
int set_mcast_rcv_interface(int sock, char *mip) {
	struct ip_mreq mreq;
	
	mreq.imr_multiaddr.s_addr = inet_addr(mip);
	mreq.imr_interface.s_addr = htonl(INADDR_ANY);

	if(setsockopt(sock, IPPROTO_IP,IP_ADD_MEMBERSHIP, &mreq, sizeof(mreq)) == -1)
		return NETLIB_ERR_SET_OPT;
	return NETLIB_SUCCESS;
}

/* set_mcast_loopback:
 *    set the IP_MULTICAST_LOOP socket option @loopback to socket @sock
 * inputs:
 *    sock    : file descriptor of the socket
 *    loopback: loopback setting
 * return:
 *    NETLIB_SUCCESS    : set the socket option successfully
 *    NETLIB_ERR_SET_OPT: otherwise */
int set_mcast_loopback(int sock, int loopback) {
	unsigned char loop = 0;

	if(loopback == NETLIB_SOCKOPT_LOOP_ON)  loop = 1;
	if(setsockopt(sock, IPPROTO_IP, IP_MULTICAST_LOOP, &loop, sizeof(loop)) == -1)
		return NETLIB_ERR_SET_OPT;
	return NETLIB_SUCCESS;
}

int set_socket_block_mode(int sock, int mode) {
	int flags;
	
	flags = fcntl(sock, F_GETFL, 0);
	if(flags < 0)   return NETLIB_ERR_SOCKET;
	/* success in read of flags */
	if(mode == NETLIB_SOCK_BLOCK_OFF) {
		/* set this socket to non-block mode */
		if(!(flags & O_NONBLOCK)) {
			/* current socket is on the block mode, set it to non-block mode  */
			flags |= O_NONBLOCK;
		}
	} else {
		/* set this socket to block mode */
		if(flags & O_NONBLOCK) {
			/* current socket is on the non block mode, set it to block mode  */
			flags ^= O_NONBLOCK;
		}
	}
    /* set the flags now */
    if(fcntl(sock, F_SETFL, flags) < 0)     return NETLIB_ERR_SOCKET;
	/* success to set the flags to the socket */
	return NETLIB_SUCCESS;
}

/* set_ttl:
 *     set the IP_MULTICAST_TTL socket option to the @sock
 * input:
 *     sock: socket file descriptor of the socket
 *     ttl : ttl value
 * return:
 *     NETLIB_SUCCESS    : set the socket option successfully
 *     NETLIB_ERR_SET_OPT: otherwise */
int set_ttl(int sock, int ttl) {
	char cttl = (char) ttl;

	if(setsockopt(sock, IPPROTO_IP, IP_MULTICAST_TTL, (char *)&cttl, sizeof(cttl)) == -1)
		return NETLIB_ERR_SET_OPT;
	return NETLIB_SUCCESS;
}

/* set_reuse_addr:
 *    set the SO_REUSEADDR socket option to the @sock
 * inputs:
 *    sock: socket file descriptor of the socket
 * return:
 *    NETLIB_SUCCESS    : set the socket option successfully
 *    NETLIB_ERR_SET_OPT: otherwise */
int set_reuse_addr(int sock) {
	int opt = 1;

	if(setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, (char*)&opt, sizeof(opt)) == -1) 
		return NETLIB_ERR_SET_OPT;
	return NETLIB_SUCCESS;
}

/* set_tos:
 *   set the TOS priority to the socket option. 
 * inputs:
 *   sock: socket file descriptor of the socket
 *   tos : TOS priority settings. It could be TOS_LOWDELAY, TOS_THROUGHPUT,
 *         TOS_RELIABILITY, TOS_LOWCOST or TOS_NORMAL.
 * return:
 *   NETLIB_SUCCESS    : set the socket option successfully
 *   NETLIB_ERR_SET_TOS: otherwise */
int set_tos(int sock, int tos) {
	int new_tos = tos;

	if(setsockopt(sock, SOL_IP, IP_TOS, (char*)&new_tos, sizeof(new_tos)) == -1)
		return NETLIB_ERR_SET_TOS;
	return NETLIB_SUCCESS;
}

/* set_rcvbuf:
 *   set the bufer size to the socket option. 
 * inputs:
 *   sock: socket file descriptor of the socket.
 *   buf_size : Socket buffer size.
 * 
 * return:
 *   NETLIB_SUCCESS    : set the socket option successfully
 *   NETLIB_ERR_SET_TOS: otherwise 
 *
 * note: add by Crota 20071018*/
int set_rcvbuf(int sock, int buf_size) {
	if(setsockopt(sock, SOL_SOCKET ,SO_RCVBUF, (char *)&buf_size, sizeof(buf_size)) == -1)
		return NETLIB_ERR_SET_TOS;
	return NETLIB_SUCCESS;
}

int wait_connect(int sock, int *conn_sock, struct sockaddr_in *addr) {
	socklen_t addr_len = sizeof(struct sockaddr_in);
	
	/* block here */
	memset(addr, 0, sizeof(struct sockaddr_in));
	*conn_sock = accept(sock, (struct sockaddr *) addr, &addr_len);
	if(*conn_sock < 0)
	{
		return NETLIB_ERR_ACCEPT;
	}
	return NETLIB_SUCCESS;
}

/* write_udp_socket:
 *    send data (@mlen bytes) in @buf to the UDP socket @sock. Because it is UDP socket, 
 * it is non-blocked I/O. I don't set the timmer here. It supports the connected UDP
 * and non-connected UDP to send the data.
 * inputs:
 *     sock : UDP socket
 *     buf  : beginning address of the data
 *     mlen : size of data
 *     addr : remote host address
 *     check: 1: use the connected UDP to send data. 0: use non-connected UDP to send data
 * return:
 *     NETLIB_ERR_WRITE: fail to send the data 
 *     the number of bytes to be sent */
int write_udp_socket(int sock, char *buf, int mlen, struct sockaddr_in *addr, int check) {
	int len    = 0;
	int tx_len = 0;

	if(check) {
		/* need to connect to the remote host before I send the packet */
		if(connect(sock, (struct sockaddr *) addr, sizeof(struct sockaddr_in)) < 0) {
			/* could not connect to the remote host, fail to sent the data out */
			return NETLIB_ERR_WRITE;
		}
		/* connect to the remote host, send the data out now!! */
		do {
			if((mlen - tx_len) > UDP_MDU) {
				len = write(sock, &buf[tx_len], UDP_MDU);
			} else {
				len = write(sock, &buf[tx_len], (mlen-tx_len));
			}
			if(len < 0) return NETLIB_ERR_WRITE;
			tx_len += len;
		} while(tx_len < mlen);
		return tx_len;
	}
	/* no need to connect the remote host before I send the packet, s
	 * end the packet now */
	do {
		if((mlen - tx_len) > UDP_MDU) {
			len = sendto(	sock, \
							&buf[tx_len], \
							UDP_MDU, \
							0, \
							(struct sockaddr *) addr, \
							sizeof(struct sockaddr_in));
		} else {
			len = sendto(	sock, \
							&buf[tx_len], \
							(mlen-tx_len), \
							0, \
							(struct sockaddr *) addr, \
							sizeof(struct sockaddr_in));
		}
		if(len < 0) return NETLIB_ERR_WRITE;
		tx_len += len;
	} while(tx_len < mlen);
	return tx_len;
}

/* write_tcp_socket:
 *    send data (@max_len bytes) in @buf to the TCP socket @sock within @poll_time interval
 * inputs:
 *    sock     : tcp socket file descriptor
 *    buf      : start address of the data which is going to be sent
 *    max_len  : the max size of data in @buf 
 *    poll_time: the max duration of sending this data. the unit of it is msec. If it is 0,
 *               the block mode is used!!
 * return:
 *    NETLIB_ERR_WRITE: send error due to fail in send() or FD_SET error or select error.
 *    length of sending data: otherwise. */
int write_tcp_socket(int sock, char *buf, int max_len, unsigned long poll_time) {
	struct timeval tout;
	struct timeval tnow;
	fd_set         wr_fd;
	int            n = 0;
	int            ret = 0;
	int            len = 0;
	
	if(poll_time == 0) {
		/* block mode */
	    len = send(sock, (char *)buf, max_len, 0);
		if(len < 0) return NETLIB_ERR_WRITE;
		else        return len;
	}
	
	/* non-block mode */
	(void)gettimeofday(&tnow, NULL);
	FD_ZERO(&wr_fd);
	
	do {
		FD_SET(sock, &wr_fd);
		tout.tv_sec  = 0;
		tout.tv_usec = NETLIB_TIME_TICK;
		n = select(sock+1, (fd_set *)0, &wr_fd, (fd_set *)0, &tout);
		
		if(n > 0) {
			if(FD_ISSET(sock, &wr_fd)) { /* ready to send the packet */
				ret = send(sock, (char *)&buf[len], (max_len-len), 0);
				if(ret > 0) len += ret;
				else        return NETLIB_ERR_WRITE;
			} else return NETLIB_ERR_WRITE;
		} else if(n < 0) return NETLIB_ERR_WRITE;
		if(check_timeout(&tnow, poll_time)) return len;
	} while(len < max_len);
	return len;
}

char *decode_netlib_err(int err_msg) {

	if(err_msg == NETLIB_ERR_SOCKET) return "socket error";
	if(err_msg == NETLIB_ERR_BIND) return "bind error";
	if(err_msg == NETLIB_ERR_LISTEN) return "listen error";
	if(err_msg == NETLIB_ERR_ACCEPT) return "accept error";
	if(err_msg == NETLIB_ERR_CONNECT) return "connnect error";
	if(err_msg == NETLIB_ERR_WRITE) return "write error";
	if(err_msg == NETLIB_ERR_READ) return "read error";
	if(err_msg == NETLIB_ERR_SET_OPT) return "set opt error";
	if(err_msg == NETLIB_ERR_GET_OPT) return "get opt error";
	if(err_msg == NETLIB_ERR_SET_TOS) return "set tos error";
	return "unknown error";
}
