// vim: ts=4 sw=4
/* #######################################################################
 * NetAccess.c
 * Created by MingYoung   Date:2007/04/10
 * Description:
 *    Provide the networking Access APIs
 * ####################################################################### */
#include "common.h"
#include "NetAccess.h"

/* #######################################################################
 * Static functions
 * ####################################################################### */
static int NetTimeExpired(struct timeval *, unsigned long);

/* #######################################################################
 * Public APIs
 * ####################################################################### */
/* BindSocket:
 *    bind the socket address and port to the socket
 * inputs:
 *    sock: the socket for binding
 *    IP  : the IP address for binding. If it is NULL, the INADDR_ANY
 *          will be binded
 *    port: the port for binding
 * return:
 *    NET_SUCCESS: success
 *    NET_ERROR  : fail */
int BindSocket(int sock, char *IP, int port) {
	struct sockaddr_in addr;

	memset((char *)&addr, 0, sizeof(struct sockaddr_in));
	addr.sin_family = AF_INET;
	if(IP) addr.sin_addr.s_addr = inet_addr(IP);
	else   addr.sin_addr.s_addr = htonl(INADDR_ANY);
	addr.sin_port        = htons(port);
	if(bind(sock, (struct sockaddr *) &addr, sizeof(struct sockaddr_in)) < 0) 
		return NET_ERROR;
	return NET_SUCCESS;
}

/* CloseSocket:
 *    Close the socket. The @fd will be reset to 0 after the socket was closed
 * inputs:
 *   fd: return of the socket file descriptor
 * return:
 *    None */
void CloseSocket(int *fd) {

	close(*fd);
	*fd = 0;
	return;
}

/* Connect2Server:
 *    Connect to the server socket. Depends on the @timer to connect to server in
 * blocking or non-blocking mode.
 * inputs:
 *    sock : socket file descriptor
 *    addr : server address
 *    timer: max time in sec of connecting to the server. if it is 0, use blocking
 *           mode to connect to the server
 * return:
 *    NET_SUCCESS: success in connection the server 
 *    NET_ERROR  : fail */
int Connect2Server(int sock, struct sockaddr_in *addr, int timer) {
	struct timeval tout;
	fd_set         rx_fd;
	int            n = 0;
	int            sock_status = -1;
	int            len = sizeof(sock_status);
	int            timeout = 0;
	int            Trails = timer*10;

	if(timer) {
		/* non-block connect to server, change the socket to the non-block mode */
		if(SetSockBlockMode(sock, NET_SOCK_NONBLOCK) == NET_ERROR) return NET_ERROR;

		if(connect(sock, (struct sockaddr *) addr, sizeof(struct sockaddr_in)) < 0) {
			while(errno != EINPROGRESS) {
				usleep(100*1000);
				if(++n >= Trails) return NET_ERROR;
			}
			do {
				FD_ZERO(&rx_fd);
				FD_SET(sock, &rx_fd);
				tout.tv_sec  = 0;
				tout.tv_usec = 100*1000;
				n = select(sock+1, NULL, &rx_fd, NULL, &tout);
				if(n > 0) {
					if(getsockopt(sock, SOL_SOCKET, SO_ERROR, &sock_status, &len) == 0) {
						if(sock_status == 0) break;
					}
				}
				/* fail to get the socket error status, error in select() or timeout */
				timeout ++;
			} while(timeout < Trails);
			if(sock_status) return NET_ERROR;
		}
		if(SetSockBlockMode(sock, NET_SOCK_BLOCK) == NET_ERROR) return NET_ERROR;
		return NET_SUCCESS;
	}
	/* block connect to server */
	if(connect(sock, (struct sockaddr *) addr, sizeof(struct sockaddr_in)) < 0)
		return NET_ERROR;
	return NET_SUCCESS;
}

/* CreateTCPSocket:
 *    Create the TCP socket. If the fail of creating a TCP socket, the *fd
 * will be reset to 0.
 * inputs:
 *    fd: return of the TCP socket file descriptor
 * return:
 *    NET_SUCCESS: success in creating a TCP socket
 *    NET_ERROR  : error */
int CreateTCPSocket(int *fd) {
	
	*fd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if(*fd < 0) {
		*fd = 0;
		return NET_ERROR;
	}
	return NET_SUCCESS;
}

/* CreateUDPSocket:
 *    Create the UDP socket. If the fail of creating a UDP socket, the *fd
 * will be reset to 0.
 * inputs:
 *    fd: return of the UDP socket file descriptor
 * return:
 *    NET_SUCCESS: success in creating a UDP socket
 *    NET_ERROR  : error */
int CreateUDPSocket(int *fd) {

	*fd = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
	if(*fd < 0) {
		*fd = 0;
		return NET_ERROR;
	}
	return NET_SUCCESS;
}

/* ReadSockTCP:
 *    receive data from TCP socket @sock to the @buf within the max interval
 * @poll_time. The actual received data length will be set in the @max_len
 * inputs:
 *    sock     : tcp socket file descriptor
 *    buf      : start address of the data which is going to be put into
 *    len      : the max size of containing received data in @buf and the return
 *               of the receive length
 *    poll_time: the max duration of receiving this data. the unit of it is msec. If it is 0,
 *               the block mode is used!!
 * return:
 *    NET_ERROR  : read error due to fail in recv() or FD_SET errori, select error or
 *                 socket was closed by remote site.
 *    NET_SUCCESS: Success */
int ReadSockTCP(int sock, char *buf, int *max_len, unsigned long poll_time) {
	struct timeval tnow;
	struct timeval tout;
	fd_set         rx_fd;
	int            n = 0;
	int            ret = 0;
	int            len = 0;
	
	if(poll_time == 0) {
		/* block mode */
		len = recv(sock, (char *)buf, *max_len, 0);
		if(len < 0) return NET_ERROR;
		else {
			*max_len = len;
	 		return NET_SUCCESS;
		}
	}

	/* non-block mode */
	FD_ZERO(&rx_fd);
	(void)gettimeofday(&tnow, NULL);
	do {
		FD_SET(sock, &rx_fd);
		tout.tv_sec  = 0;
		tout.tv_usec = NET_TIME_TICK;
		n = select(sock+1, &rx_fd, (fd_set *)0, (fd_set *)0, &tout);
		if(n > 0) { /* have data in the socket */
			if(FD_ISSET(sock, &rx_fd)) {    /* for this socket */
				ret = recv(sock, buf, *max_len, 0);
				if(ret > 0) {
					*max_len = ret;
					return NET_SUCCESS;;
				}
			}
			return  NET_ERROR;
		} else if(n < 0) return NET_ERROR;
	} while(NetTimeExpired(&tnow, poll_time) == 0);
	/* timeout, return 0 length and error */
	*max_len = 0;
	return  NET_ERROR;
}

int ReadSockUDP(int sock, char *buf, int *mlen, struct sockaddr_in *Addr, int Timer) {
	struct timeval tout;
	struct timeval tnow;
	socklen_t      AddrLen = sizeof(struct sockaddr_in);
	fd_set         rx_fd;
	int            n = 0;
	int            ret = 0;
	int            len = 0;

	if(Timer == 0) { /* block mode */
		len = recvfrom(sock, (char *)buf, *mlen, 0, (struct sockaddr *)Addr, &AddrLen);
		if(len < 0) return NET_ERROR;
		else {
			*mlen = len;
	 		return NET_SUCCESS;
		}
	}
	/* non-block mode */
	(void)gettimeofday(&tnow, NULL);
	do {
		FD_ZERO(&rx_fd);
		FD_SET(sock, &rx_fd);
		tout.tv_sec  = 0;
		tout.tv_usec = NET_TIME_TICK;
		n = select(sock+1, &rx_fd, (fd_set *)0, (fd_set *)0, &tout);
		if(n > 0) {
			if(FD_ISSET(sock, &rx_fd)) { /* have data in the socket */
				ret = recvfrom(	sock, \
								(char *)(buf+len), \
								(*mlen-len), \
								0, \
								(struct sockaddr *)Addr, \
								&AddrLen);
				if(ret > 0) len += ret;
				else return NET_ERROR;
			} else return NET_ERROR;
		} else if(n < 0) return NET_ERROR;
		/* check if the receiving timer is expired */
		if(NetTimeExpired(&tnow, Timer)) {
			*mlen = len;
			return NET_SUCCESS;
		}
	} while(len < *mlen);
	*mlen = len;
	return NET_SUCCESS;
}

/* SetSockBlockMode:
 *    Set the socket blocking mode.
 * inputs:
 *    sock: socket file descriptor
 *    mode: socket blocking mode. 
 *          It could be NET_SOCK_BLOCK or NET_SOCK_NONBLOCK
 * return:
 *    NET_SUCCESS: success
 *    NET_ERROR  : error */
int SetSockBlockMode(int sock, int mode) {
	int flags = 0;

	flags = fcntl(sock, F_GETFL, 0);
	if(flags < 0)   return NET_ERROR;
	/* success in read of flags */
	if(mode == NET_SOCK_NONBLOCK) {
		/* set this socket to non-block mode */
		if(!(flags & O_NONBLOCK)) {
			/* current socket is on the block mode, set it to non-block mode  */
			flags |= O_NONBLOCK;
			/* set the flags now */
			if(fcntl(sock, F_SETFL, flags) < 0)  return NET_ERROR;
		}
	} else {
		/* set this socket to block mode */
		if(flags & O_NONBLOCK) {
			/* current socket is on the non block mode, set it to block mode  */
			flags ^= O_NONBLOCK;
			/* set the flags now */
			if(fcntl(sock, F_SETFL, flags) < 0)  return NET_ERROR;
		}
	}
	/* success to set the flags to the socket or 
	 * the socket meets the request mode already */
	return NET_SUCCESS;
}

int SockOptMembershipAdd(int sock, char *LocalIP, char *McastIP) {
	struct ip_mreq mreq;

	memset((char *)&mreq, 0, sizeof(mreq));
	mreq.imr_multiaddr.s_addr = inet_addr(McastIP);
	if(LocalIP) mreq.imr_interface.s_addr = inet_addr(LocalIP);
	else        mreq.imr_interface.s_addr = htonl(INADDR_ANY);
	
	if(setsockopt(sock, IPPROTO_IP, IP_ADD_MEMBERSHIP, &mreq, sizeof(mreq))) {
		return NET_ERROR;
	}
	return NET_SUCCESS;
}

int SockOptLoopback(int sock, unsigned char loop) {

	if(setsockopt(sock, IPPROTO_IP, IP_MULTICAST_LOOP, &loop, sizeof(loop)) == -1) {
		return NET_ERROR;
	}
	return NET_SUCCESS;
}

/* SockOptReusedAddrSet:
 *    Set the Reused Address Socket Option to the socket
 * input:
 *    sock: socket file descriptor
 * return:
 *    NET_SUCCESS: success
 *    NET_ERROR  : fail */
int SockOptReusedAddrSet(int sock) {
	int opt = 1;

	if(setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, (char*)&opt, sizeof(opt)) == -1) {
		return NET_ERROR;
	}
	return NET_SUCCESS;
}

/* WriteSockTCP:
 *    send data (@max_len bytes) in @buf to the TCP socket @sock within @poll_time interval
 * inputs:
 *    sock     : tcp socket file descriptor
 *    buf      : start address of the data which is going to be sent
 *    max_len  : the max size of data in @buf
 *    poll_time: the max duration of sending this data. the unit of it is msec. If it is 0,
 *               the block mode is used!!
 * return:
 *    NET_ERROR: send error due to fail in send() or FD_SET error or select error.
 *    length of sending data: otherwise. */
int WriteSockTCP(int sock, char *buf, int max_len, unsigned long poll_time) {
	struct timeval tout;
	struct timeval tnow;
	fd_set         wr_fd;
	int            n = 0;
	int            ret = 0;
	int            len = 0;

	if(poll_time == 0) {
		/* block mode */
		len = send(sock, (char *)buf, max_len, 0);
		if(len < 0) return NET_ERROR;
		else        return len;
	}

	/* non-block mode */
	(void)gettimeofday(&tnow, NULL);
	FD_ZERO(&wr_fd);
	do {
		FD_SET(sock, &wr_fd);
		tout.tv_sec  = 0;
		tout.tv_usec = NET_TIME_TICK;
		n = select(sock+1, (fd_set *)0, &wr_fd, (fd_set *)0, &tout);
		if(n > 0) {
			if(FD_ISSET(sock, &wr_fd)) { /* ready to send the packet */
				ret = send(sock, (char *)&buf[len], (max_len-len), 0);
				if(ret > 0) len += ret;
				else return NET_ERROR;
			} else return NET_ERROR;
		} else if(n < 0) return NET_ERROR;
		if(NetTimeExpired(&tnow, poll_time)) return len;
	} while(len < max_len);
	return len;
}

/* #######################################################################
 * Static functions
 * ####################################################################### */
/* NetTimeExpired:
 *    check if the time interval between @begin and now is larget then the @max_time.
 *    if it does, timeout occurs.
 * inputs:
 *    begin   : the start time of record
 *    max_time: the max duration from @begin we could allowed!! the unit of max_time is msec
 * return:
 *    1: timeout occurs
 *    0: otherwise */
static int NetTimeExpired(struct timeval *begin, unsigned long MaxTime) {
	struct timeval tnow;
	unsigned long diff;

	(void)gettimeofday(&tnow, NULL);
	/* calculate the time difference from the tnow to *begin */
	if(tnow.tv_sec >= begin->tv_sec) {
		diff = (tnow.tv_sec - begin->tv_sec)*1000; /* in msec*/
	} else {
		diff = ((0xffffffff-begin->tv_sec)+tnow.tv_sec+1)*1000; /* in msec*/
	}
	if(tnow.tv_usec >= begin->tv_usec) {
		diff += ((tnow.tv_usec-begin->tv_usec)/1000); /* in msec */
	} else {
		diff -= 1000;
		diff += (((1000000-begin->tv_usec)+tnow.tv_usec)/1000); /* in msec */
	}

	return (diff >= MaxTime);
}
