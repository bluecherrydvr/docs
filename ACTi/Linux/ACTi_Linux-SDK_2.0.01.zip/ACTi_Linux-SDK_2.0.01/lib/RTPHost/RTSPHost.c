// vim: ts=4 sw=4
/* #######################################################################
 * RTSPHost.c
 * Created by MingYoung   Date:2007/04/10
 * Description:
 *    Provide the RTSP Host Access APIs
 * ####################################################################### */
#include "common.h"
#include "NetAccess.h"
#include "NetRtsp.h"

#define RTSPHostMsg1(fmt, args...) printf(fmt, ##args)
#define RTSPHostMsg0(fmt, args...)

/* #######################################################################
 * Static functions
 * ####################################################################### */

/* #######################################################################
 * Public APIs
 * ####################################################################### */
int Connect2RTSPSrv(RTSP_HOST_CONF *Conf) {
	int                Sock = 0;
	struct sockaddr_in Addr;
	RTSP_HOST_INFO     *Info;

	/* create a TCP socket for RTSP session */
	if(CreateTCPSocket(&Sock) == NET_SUCCESS) {
		/* Success in creating a TCP socket, set some socket option before
		 * I go further. In here, I ignore the error in setting socket option
		 * because it does not affect to RTSP signalling */
		(void)SockOptReusedAddrSet(Sock);
	   	/* connect to the server now, Set the Server address now  */
		memset((char *)&Addr, 0, sizeof(struct sockaddr_in));
		Addr.sin_family = AF_INET;
		Addr.sin_addr.s_addr = inet_addr(Conf->SrvIP);
		Addr.sin_port        = htons(Conf->SrvPort);
		if(Connect2Server(Sock, &Addr, Conf->ConnTime) == NET_ERROR) {
			/* fail to connect to the server, leave now with error code */
			Conf->ConnState = RTSP_CONN_ERR_CONNECT;
			RTSPHostMsg1("<Connect2RTSPSrv>: connect %s:%d error\n", \
					inet_ntoa(Addr.sin_addr), ntohs(Addr.sin_port));
			return RTSP_ERR;
		}
		/* success in connection the socket. Record this Socket */
		Conf->Sock = Sock;
		/* send the RTSP option command to get the RTSP Server's supported 
		 * RTSP commands */
		/* setup the RTSP sequence number, I start it from 1 */
		Conf->Info.CSeq = 1;
		if(RTSPHostOptionGet(Conf) == RTSP_ERR) {
			/* fail to connect to the server, leave now with error code */
			CloseSocket(&Conf->Sock);
			Conf->ConnState = RTSP_CONN_ERR_SIGNAL;
			RTSPHostMsg1("<Connect2RTSPSrv>: Get OPTIONS error\n");
			return RTSP_ERR;
		}
		/* success in getting Server's Commands */
		/* check the server's supported commands, I need the DESCRIBE, SETUP, PLAY and 
		 * TERADOWN commands at least */
		Info = &Conf->Info;
		if((Info->SrvRTSPCmdCap&RTSP_CMD_CAP_DESCRIBE) && \
				(Info->SrvRTSPCmdCap&RTSP_CMD_CAP_SETUP) && \
				(Info->SrvRTSPCmdCap&RTSP_CMD_CAP_PLAY) && \
				(Info->SrvRTSPCmdCap&RTSP_CMD_CAP_TEARDOWN)) {
			if(RTSPHostDescribeHandle(Conf) == RTSP_ERR) {
				/* fail to handle the Describe */
				CloseSocket(&Conf->Sock);
				Conf->ConnState = RTSP_CONN_ERR_SIGNAL;
				RTSPHostMsg1("<Connect2RTSPSrv>: DESCRIBE error\n");
				return RTSP_ERR;
			}
			/* success in Describe authentication, go to setup session */
			if(RTSPHostSetupHandle(Conf) == RTSP_ERR) {
				/* fail to handle the Describe */
				CloseSocket(&Conf->Sock);
				Conf->ConnState = RTSP_CONN_ERR_SIGNAL;
				RTSPHostMsg1("<Connect2RTSPSrv>: SETUP error\n");
				return RTSP_ERR;
			}
			return RTSP_OK;
		}
		RTSPHostMsg1("<Connect2RTSPSrv>: RTSP Server's Cmd Error. Cmds=0x%x\n", \
				Info->SrvRTSPCmdCap);
		CloseSocket(&Conf->Sock);
		Conf->ConnState = RTSP_CONN_ERR_SIGNAL;
		return RTSP_ERR;
	}
	/* Fail to create the TCP socket, return error */
	RTSPHostMsg1("<Connect2RTSPSrv>: creating TCP socket error\n");
	Conf->ConnState = RTSP_CONN_ERR_SOCK;
	return RTSP_ERR;
}

int IsRTSPSrvAlive(RTSP_HOST_CONF *Conf) {
	char pkt[1024];
	int  len = 0;
		
	Conf->Info.CSeq += 1;
	/* build the OPTION request packet to send to RTSP server */
	sprintf(pkt, "OPTIONS rtsp://%s:%s@%s:%d RTSP/1.0\r\n" \
				 "CSeq: %d\r\n" \
				 "User-Agent: %s \r\n\r\n", \
				 Conf->Name, Conf->Pwd, Conf->SrvIP, Conf->SrvPort, \
				 Conf->Info.CSeq, \
				RTP_PLAYER);
	len = strlen(pkt);
	/* Send this RTSP Option Req packet to Server now */
	if(WriteSockTCP(Conf->Sock, pkt, len, RTSP_TIMER_TX) == len) {
		/* success in sending the RTSP OPTION REQ packet, wait for server's
		 * reply */
		len = sizeof(pkt);
		if(ReadSockTCP(Conf->Sock, pkt, &len, Conf->RespTime) == NET_SUCCESS) {
			return RTSP_OK;
		}
	}
	return RTSP_ERR;
}

int RTSPHostPlayHandle(RTSP_HOST_CONF *Conf) {

	/* send the RTSP PLAY Command for Track 1 (Video) first */
	if(RTSPPlayCmdSend(Conf) == RTSP_OK) {
		/* wait for server's reply */
		if(RTSPPlayReplyHandle(Conf) == RTSP_OK) {
			/* update the server's Sequence Numbers configurations */
			return RTSP_OK;
		}
	} else printf("<RTSPHostPlayHandle>: fail of sending PLAY Req\n");
	Conf->ConnState = RTSP_CONN_ERR_SIGNAL;
	return RTSP_ERR;
}

/* #######################################################################
 * Static functions
 * ####################################################################### */
