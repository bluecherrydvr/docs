// vim: ts=4 sw=4
/* #######################################################################
 * RTPHost.c
 * Created by MingYoung   Date:2007/04/10
 * Description:
 *    Provide the RTP Host Access APIs
 * ####################################################################### */
#include "common.h"
#include "NetAccess.h"
#include "NetRtsp.h"
#include "NetRtcp.h"
#include "NetRtp.h"

#define RTPHostMsg1(fmt, args...) printf(fmt, ##args)
#define RTPHostMsg0(fmt, args...)

/* #######################################################################
 * Static functions
 * ####################################################################### */
static void CloseRTPSockets(RTP_HOST_CONF *);
static void GetRTPVideoFrameType(unsigned char *, int *);
static int  IsRTPFrameInSock(int);

/* #######################################################################
 * Public APIs
 * ####################################################################### */
int CreateRTPHostSockets(RTP_HOST_CONF *Conf) {
	RTP_MEDIA *Media;
	int       i = 0;

	for(i = 0 ; i < 2 ; i ++) {
		Media = &Conf->Media[i];
		/* Create the RTP Host sockets */
		if(Media->Port) {
			if(CreateUDPSocket(&Media->Sock) == NET_SUCCESS) {
				/* Success in creating the socket!! bind the
				 * INADDR_ANY:Port to this socket */
				if(BindSocket(Media->Sock, NULL, Media->Port) == NET_ERROR) {
					/* fail of binding the socket */
					CloseRTPSockets(Conf);
					return RTP_ERR;
				}
				/* set the reuse address socket option to speed up
				 * re-openning these ports */
				if(SockOptReusedAddrSet(Media->Sock) == NET_ERROR) {
					/* fail of set the Reused Address socket option */
					CloseRTPSockets(Conf);
					return RTP_ERR;
				}
				if(Conf->RTPProt == RTSP_RTP_MULTICAST) {
					/* disable the loopback function */
					if(SockOptLoopback(Media->Sock, NET_SOCK_LOOP_OFF) == NET_ERROR) {
						/* fail of disabling loopback socket option */
						CloseRTPSockets(Conf);
						return RTP_ERR;
					}
					/* add RTP Server's Multicast address to socket's
					 * multicast membership */
					if(SockOptMembershipAdd(Media->Sock, \
											Conf->HostIP, \
											Conf->SrvIP) == NET_ERROR) {
						/* fail of adding server's Mcast IP to socket membership */
						CloseRTPSockets(Conf);
						return RTP_ERR;
					}
				}
				RTPHostMsg1("<CreateRTPHostSockets>: Create UDP Sock at %s:%d\n", \
						Conf->HostIP, Media->Port);
			} else {
				/* fail to create a UDP socket, close all RTCP sockets and
				 * return error */
				CloseRTPSockets(Conf);
				return RTP_ERR;
			}
		} /* else => This media is not available */
	}
	return RTP_OK;
}

void InitRTPHostConf(RTSP_HOST_CONF *Rtsp, RTP_HOST_CONF *Rtp) {
	int i = 0;

	/* set the RTPProt (RTP streaming protocol */
	Rtp->RTPProt = Rtsp->RTPProt;
	/* set the Server IP */
	if(Rtp->RTPProt == RTSP_RTP_UDP) strcpy(Rtp->SrvIP, Rtsp->SrvIP);
	else                             strcpy(Rtp->SrvIP, Rtsp->SrvMcastIP);
	strcpy(Rtp->HostIP, Rtsp->HostIP);
	/* setup the Media configuration in RTCP */
	for(i = 0 ; i < 2 ; i ++) {
		Rtp->Media[i].State = RTP_HOST_STATE_INIT;
		Rtp->Media[i].Sock = 0;
		/* RTCP Ports */
		Rtp->Media[i].Port  = Rtsp->Info.Media[i].RTPHostPort;
		/* SSRC */
		Rtp->Media[i].SrvSSRC      = 0;
		Rtp->Media[i].Seq          = 0;
		Rtp->Media[i].Data.SRPkts  = 0;
		Rtp->Media[i].Data.SRBytes = 0;
		Rtp->Media[i].Data.RRPkts  = 0;
		Rtp->Media[i].Data.RRBytes = 0;
	}
	return;
}

int RTPAudio1stFrameHunting(RTP_FRAME *Frame, RTP_HOST_CONF *Rtp, RTCP_HOST_CONF *Rtcp) {
	struct sockaddr_in Addr;
	socklen_t          AddrLen = sizeof(struct sockaddr_in);
	int                i     = 0;
	int                Len   = 0;
	RTP_HEADER         *RtpHead;
	unsigned char      buf[2000];

	Len = recvfrom( Rtp->Media[1].Sock, \
					buf, \
					2000, \
					0, \
					(struct sockaddr *)&Addr, \
					&AddrLen);
	if(Len > RTP_HEADER_LEN) {
		/* Received a RTP packet, check the header */
		RtpHead = (RTP_HEADER *) buf;
		if((RtpHead->Ver == 2) && (RtpHead->PT == RTSP_MEDIA_PCM16_8KHZ)) {
			/* this is the Audio frame!! */
			Len -= RTP_HEADER_LEN;
			Frame->Len  = Len;
			Frame->Type = RTP_FRAME_AUDIO;
			/* do the byte swap. I assume the audio data is in even length */
			for(i = 0; i < (Len-1) ; i=i+2) {
				Frame->Buf[i]   = buf[RTP_HEADER_LEN+i+1];
				Frame->Buf[i+1] = buf[RTP_HEADER_LEN+i];
			}
			Rtp->Media[1].Data.RRPkts  ++;
			Rtp->Media[1].Data.RRBytes += Len;
			/* update the Sequence number and SSRC and Statistics */
			Rtp->Media[1].SrvSSRC = ntohl(RtpHead->SSRC);
			Rtp->Media[1].Seq     = ntohs(RtpHead->Seq);
			/* Sync this settings to RTCP Host Database */
			Rtcp->Media[1].SrvSSRC = Rtp->Media[1].SrvSSRC;
			Rtcp->Media[1].Seq     = Rtp->Media[1].Seq;
			Rtcp->Media[1].Data.RRPkts  = Rtp->Media[1].Data.RRPkts;
			Rtcp->Media[1].Data.RRBytes = Rtp->Media[1].Data.RRBytes;
			RTPHostMsg1("<RTPAudio1stFrameHunting>: 1st Audio Frame @ %d, SSRC=%u\n", \
						Rtp->Media[1].Seq, Rtp->Media[1].SrvSSRC);
			RTPHostMsg0("<RTPAudio1stFrameHunting>: Data: %d,%d\n", \
						Rtp->Media[1].Data.RRPkts, Rtp->Media[1].Data.RRBytes);
			return RTP_OK;
		} 
		RTPHostMsg1("<RTPAudio1stFrameHunting>: RTP Header Error %d,%d\n", \
					RtpHead->Ver, RtpHead->PT);
	} else RTPHostMsg1("<RTPAudio1stFrameHunting>: received error\n");
	return RTP_ERR;
}
		
int RTPFrameAudioGet(RTP_FRAME *Frame, RTP_HOST_CONF *Rtp, RTCP_HOST_CONF *Rtcp) {
	struct sockaddr_in Addr;
	socklen_t          AddrLen = sizeof(struct sockaddr_in);
	int                i     = 0;
	int                Len   = 0;
	RTP_HEADER         *RtpHead;
	unsigned char      buf[2000];

	Len = recvfrom( Rtp->Media[1].Sock, \
			        buf, \
					2000, \
					0, \
					(struct sockaddr *)&Addr, \
					&AddrLen);
	if(Len > RTP_HEADER_LEN) {
		/* Received a RTP packet, check the header */
		RtpHead = (RTP_HEADER *) buf;
		if(		(RtpHead->Ver == 2) && \
				(RtpHead->PT == RTSP_MEDIA_PCM16_8KHZ) && \
				(Rtcp->Media[1].SrvSSRC == ntohl(RtpHead->SSRC))) {
			/* this is the Audio frame!! */
			Rtp->Media[1].Seq = ((Rtp->Media[1].Seq+1)&0x0ffff);
			if(Rtp->Media[1].Seq == ntohs(RtpHead->Seq)) {
				Len -= RTP_HEADER_LEN;
				Frame->Len  = Len;
				Frame->Type = RTP_FRAME_AUDIO;
				/* do the byte swap. I assume the audio data is in even length */
				for(i = 0; i < (Len-1) ; i=i+2) {
					Frame->Buf[i]   = buf[RTP_HEADER_LEN+i+1];
					Frame->Buf[i+1] = buf[RTP_HEADER_LEN+i];
				}
				Rtp->Media[1].Data.RRPkts  ++;
				Rtp->Media[1].Data.RRBytes += Len;
				RTPHostMsg0("<RTPFrameAudioGet>: Rx %dB in Last Seq=%d\n", \
						Len, ntohs(RtpHead->Seq));
				/* update teh statictics */
				Rtcp->Media[1].Seq          = Rtp->Media[1].Seq;
				Rtcp->Media[1].Data.RRPkts  = Rtp->Media[1].Data.RRPkts;
				Rtcp->Media[1].Data.RRBytes = Rtp->Media[1].Data.RRBytes;
				return RTP_OK;
			}
			RTPHostMsg1("<RTPFrameAudioGet>: Error Seq=%d/%d(%dB)\n", \
					Rtp->Media[1].Seq, ntohs(RtpHead->Seq), Len);
			Rtp->Media[1].Seq = ntohs(RtpHead->Seq);
		} else RTPHostMsg1("<RTPFrameAudioGet>: Not Valid RTP Video Frame\n");
	} else RTPHostMsg1("<RTPFrameAudioGet>: received error\n");
	return RTP_ERR;
}

int RTPVideoIFrameHunting(RTP_FRAME *Frame, RTP_HOST_CONF *Rtp, RTCP_HOST_CONF *Rtcp) {
	struct sockaddr_in Addr;
	socklen_t AddrLen = sizeof(struct sockaddr_in);
	int MaxFrame = Frame->Len;
	int Len   = 0;
	int Total = 44;
	RTP_HEADER *RtpHead;
	unsigned char buf[2000];

	do {
		Frame->Len = MaxFrame;
		Len = recvfrom(	Rtp->Media[0].Sock, \
						buf, \
						2000, \
						0, \
						(struct sockaddr *)&Addr, \
						&AddrLen);

		if(Len <= RTP_HEADER_LEN) {
			RTPHostMsg1("<RTPVideoIFrameHunting>: received error\n");
			return RTP_ERR;
		}
		/* Received a RTP packet, check the header */
		RtpHead = (RTP_HEADER *) buf;
		if((RtpHead->Ver == 2) && (RtpHead->PT == RTSP_MEDIA_MP4V_ES90000)) {
			/* this is the Video MPEG4 frame!! */
			Len -= RTP_HEADER_LEN;
			Rtp->Media[0].Data.RRPkts  ++;
			Rtp->Media[0].Data.RRBytes += Len;
			if(Total+Len < Frame->Len) {
				memcpy(&Frame->Buf[Total], &buf[RTP_HEADER_LEN], Len);
				Total += Len;
				if(RtpHead->Marker) {
					/* Last fragment packet, move the Last 44 B2 to the head */
					memcpy(Frame->Buf, &Frame->Buf[Total-44], 44);
					Frame->Len = Total-44;
					//printf("->0x%02x 0x%02x 0x%02x 0x%02x<-\n", Frame->Buf[0], Frame->Buf[1], Frame->Buf[2], Frame->Buf[3]);
					/* Check the Video Frame Type */
					GetRTPVideoFrameType(&Frame->Buf[44], &Frame->Type);
					if(Frame->Type == RTP_FRAME_VIDEO_I) {
						/* this is the I frame, update the Sequence number and SSRC
						 * and Statistics */
						//printf("%02x-%02x-%02x-%02x\n", Frame->Buf[44],Frame->Buf[45], Frame->Buf[46], Frame->Buf[47]);
						Rtp->Media[0].SrvSSRC = ntohl(RtpHead->SSRC);
						Rtp->Media[0].Seq     = ntohs(RtpHead->Seq);
						/* Sync this settings to RTCP Host Database */
						Rtcp->Media[0].SrvSSRC = Rtp->Media[0].SrvSSRC;
						Rtcp->Media[0].Seq     = Rtp->Media[0].Seq;
						Rtcp->Media[0].Data.RRPkts  = Rtp->Media[0].Data.RRPkts;
						Rtcp->Media[0].Data.RRBytes = Rtp->Media[0].Data.RRBytes;
						RTPHostMsg1("<RTPVideoIFrameHunting>: I Frame @ %d, SSRC=%u\n", \
								Rtp->Media[0].Seq, Rtp->Media[0].SrvSSRC);
						RTPHostMsg0("<RTPVideoIFrameHunting>: Data: %d,%d\n", \
								Rtp->Media[0].Data.RRPkts, Rtp->Media[0].Data.RRBytes);
						return RTP_OK;
					}
					/* P frame or Unknown vidoe frame type, drop it and retry to get the
					 * I frame */
					// printf("%02x-%02x-%02x-%02x\n", Frame->Buf[44],Frame->Buf[45], Frame->Buf[46], Frame->Buf[47]);
					Total = 44;
				}
			} else {
				RTPHostMsg1("<RTPVideoIFrameHunting>: Oversize %d\n", Total+Len);
				Total = 44;
			}
		} else {
			RTPHostMsg1("<RTPVideoIFrameHunting>: RTP Header Error %d,%d, %d,%d\n", \
					RtpHead->Ver, RtpHead->PT, Len, Total);
			Total = 44;
			break;
		}
	} while(Rtp->Media[0].State == RTP_HOST_STATE_RUN);
	return RTP_ERR;
}

int RTPFrameVideoGet(RTP_FRAME *Frame, RTP_HOST_CONF *Rtp, RTCP_HOST_CONF *Rtcp) {
	struct sockaddr_in Addr;
	socklen_t AddrLen = sizeof(struct sockaddr_in);
	int           Len   = 0;
	int           Total = 44;
	RTP_HEADER    *RtpHead;
	unsigned char buf[2000];

	do {
		Len = recvfrom( Rtp->Media[0].Sock, \
						buf, \
						2000, \
						0, \
						(struct sockaddr *)&Addr, \
						&AddrLen);
		if(Len <= RTP_HEADER_LEN) {
			RTPHostMsg1("<RTPFrameVideoGet>: received error\n");
			return RTP_ERR;
		}
		
		/* Received a RTP packet, check the header */
		RtpHead = (RTP_HEADER *) buf;
		if(		(RtpHead->Ver == 2) && \
				(RtpHead->PT == RTSP_MEDIA_MP4V_ES90000) && \
				(Rtcp->Media[0].SrvSSRC == ntohl(RtpHead->SSRC))) {
				Rtp->Media[0].Seq = ((Rtp->Media[0].Seq + 1) & 0x0ffff);
			if(Rtp->Media[0].Seq == ntohs(RtpHead->Seq)) {
				/* this is the Video MPEG4 frame!! */
				Len -= RTP_HEADER_LEN;
				if(Total+Len < Frame->Len) {
					memcpy(&Frame->Buf[Total], &buf[RTP_HEADER_LEN], Len);
					Total += Len;
					Rtp->Media[0].Data.RRPkts  ++;
					Rtp->Media[0].Data.RRBytes += Len;
					if(RtpHead->Marker) {
						/* Last fragment packet, move the Last 44 B2 to the head */
						memcpy(Frame->Buf, &Frame->Buf[Total-44], 44);
						Frame->Len = Total-44;
						/* Check the Video Frame Type */
						GetRTPVideoFrameType(&Frame->Buf[44], &Frame->Type);
						RTPHostMsg0("<RTPFrameVideoGet>: Rx %dB in Last Seq=%d\n", \
								Frame->Len, ntohs(RtpHead->Seq));
						/* update teh statictics */
						Rtcp->Media[0].Seq          = Rtp->Media[0].Seq;
						Rtcp->Media[0].Data.RRPkts  = Rtp->Media[0].Data.RRPkts;
						Rtcp->Media[0].Data.RRBytes = Rtp->Media[0].Data.RRBytes;
						return RTP_OK;
					}
				} else {
					RTPHostMsg1("<RTPFrameVideoGet>: Oversize %d\n", Total+Len);
					return RTP_ERR;
				}
			} else {
				#if 0
				RTPHostMsg1("<RTPFrameVideoGet>: Error Seq=%d/%d(%dB)\n", \
						Rtp->Media[0].Seq, ntohs(RtpHead->Seq), Len);
				#endif
				Rtp->Media[0].Seq = ntohs(RtpHead->Seq);
				return RTP_ERR;
			}
		} else {
			RTPHostMsg1("<RTPFrameVideoGet>: Not Valid RTP Video Frame\n");
			return RTP_ERR;
		}
		/* not receive the maker frame, keep going!! */
	} while(Rtp->Media[0].State == RTP_HOST_STATE_RUN);
	return RTP_ERR;
}

void RTPSeqNumUpdate(int Seq1, int Seq2, RTP_HOST_CONF *Rtp) {
	
	Rtp->Media[0].Seq = Seq1;
	Rtp->Media[1].Seq = Seq2;

	return;
}

/* #######################################################################
 * Static functions
 * ####################################################################### */
static void CloseRTPSockets(RTP_HOST_CONF *Conf) {
	int i = 0;

	for(i = 0 ; i < 2 ; i ++) {
		if(Conf->Media[i].Sock) {
			close(Conf->Media[i].Sock);
			Conf->Media[i].Sock = 0;
		}
	}
	return;
}

static void GetRTPVideoFrameType(unsigned char *buf, int *Type) {

	if((buf[0]==0x00)&&(buf[1]==0x00)&&(buf[2]==0x01)&&(buf[3]==0xb6)) {
		*Type = RTP_FRAME_VIDEO_P;
	} else if((buf[0]==0x00)&&(buf[1]==0x00)&&(buf[2]==0x01)&&(buf[3]==0xb0)) {
		*Type = RTP_FRAME_VIDEO_I;
	} else {
		*Type = RTP_FRAME_UNKNOWN;
	}
	return;
}

static int IsRTPFrameInSock(Sock) {
	struct timeval Tout;
	fd_set         RxFd;
	int            n = 0;

	Tout.tv_sec  = 0;
	Tout.tv_usec = 30*1000; /* 10 msec */
	FD_ZERO(&RxFd);
	FD_SET(Sock, &RxFd);
	n = select(Sock+1, &RxFd, (fd_set *)0, (fd_set *)0, &Tout);
	if((n > 0) && (FD_ISSET(Sock, &RxFd))) return 1;
	return 0;
}
