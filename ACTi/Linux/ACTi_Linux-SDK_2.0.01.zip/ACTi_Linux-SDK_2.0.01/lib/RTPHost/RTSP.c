// vim: ts=4 sw=4
/* #######################################################################
 * RTSP.c
 * Created by MingYoung   Date:2007/04/10
 * Description:
 *    Provide the RTSP APIs
 * ####################################################################### */
#include "common.h"
#include "NetAccess.h"
#include "NetRtsp.h"
#include "md5.h"

#define GET_DIGETS_NONCE		0x01
#define GET_DIGETS_REALM		0x02
#define GET_DIGETS_URI			0x04
#define GET_DIGETS_RESP			0x08

#define RTSPMsg1(fmt, args...) printf(fmt, ##args)
#define RTSPMsg0(fmt, args...)

/* #######################################################################
 * Static functions
 * ####################################################################### */
static int  Char2Hex(char);
static int  RTSPDigestParser(char *, int, char *);
static int  GetRTSPDigestStrings(char *, int, RTSP_DIGEST *);
static int  IsValidRTSPFrame(char *, int);
static int  RTSPDescribeReplyHandle(char *, int, RTSP_HOST_CONF *);
static void RTSPDescribeReqBuildBase64(char *, int *, RTSP_HOST_CONF *);
static void RTSPDescribeReqBuildDigest(char *, int *, RTSP_HOST_CONF *);
static void RTSPDigestRespStrBuild(RTSP_HOST_CONF *, char *, RTSP_DIGEST *);
static int  RTSPMediaDescribeGet(char *, int, RTSP_HOST_CONF *);
static int  RTSPMediaDescribeAudioGet(char *, int, RTSP_HOST_CONF *);
static int  RTSPMediaDescribeConfigGet(char *, int, RTSP_MEDIA *);
static int  RTSPMediaDescribeCtrlGet(char *, int, char *);
static int  RTSPMediaDescribeMcastIPGet(char *, int, char *);
static int  RTSPMediaDescribeProtocolGet(char *, int, int *, RTSP_MEDIA *);
static int  RTSPMediaDescribeTypeGet(char *, int, int *);
static int  RTSPMediaDescribeVideoGet(char *, int, RTSP_HOST_CONF *);
static int  RTSPOptionReplyHandle(char *, int, RTSP_HOST_INFO *);
static void RTSPPlayReqBuildBase64(char *, int *, RTSP_HOST_CONF *);
static void RTSPPlayReqBuildDigest(char *, int *, RTSP_HOST_CONF *);
static int  RTSPRetCodeCseq(char *, int, int *, int *);
static int  RTSPSessionIDGet(char *, int, int *);
static int  RTSPSetupReplyHandle(char *, int, RTSP_HOST_CONF *, RTSP_MEDIA *);
static void RTSPSetupReqBuildBase64(char *, int *, RTSP_HOST_CONF *, RTSP_MEDIA *);
static void RTSPSetupReqBuildDigest(char *, int *, RTSP_HOST_CONF *, RTSP_MEDIA *);
static void RTSPTeardownReqBuildBase64(char *, int *, RTSP_HOST_CONF *);
static void RTSPTeardownReqBuildDigest(char *, int *, RTSP_HOST_CONF *);

/* #######################################################################
 * Public APIs
 * ####################################################################### */
int RTSPFindString(char *buf, int len, int *index, char *Str) {
	int i = 0;
	int k = 0;
	int slen = strlen(Str);

	for(i = 0 ; i < len ; i ++) {
		if(buf[i] != Str[k]) k = 0;
		else k++;
		if(k == slen) {
			*index = i+1;
			return 1;
		}
	}
	return 0;
}

int RTSPGetRandomNum(void) {
	time_t seed;

	time(&seed);
	srand((unsigned int)seed);
	return rand();
}

int RTSPHostDescribeHandle(RTSP_HOST_CONF *Conf) {
	char pkt[1024];
	int  len = 0;
	int  ret = RTSP_ERR;
	int  WaitTime = Conf->RespTime;
	
	Conf->Info.CSeq += 1;
	/* build the 1st Describe request packet to send to RTSP server */
	if(Conf->Encoder == RTSP_ENCODER_BASE64) {
	RTSPDescribeReqBuildBase64(pkt, &len, Conf);
	} else {
		RTSPDescribeReqBuildDigest(pkt, &len, Conf);
	}
	/* Send this RTSP Option Req packet to Server now */
	if(WriteSockTCP(Conf->Sock, pkt, len, RTSP_TIMER_TX) == len) {
		/* success in sending the RTSP Describe REQ packet, wait for server's
		 * reply */
		len = sizeof(pkt);
		if(ReadSockTCP(Conf->Sock, pkt, &len, Conf->RespTime) == NET_SUCCESS) {
			/* reviced server's reply, get the server's command capabilities */
			ret = RTSPDescribeReplyHandle(pkt, len, Conf);
			if(ret == RTSP_RET_OK) return RTSPMediaDescribeGet(pkt, len, Conf);
			else if(ret == RTSP_OK) {
				/* this is the digest authentication process!! go for the second
				 * round. the nonce and realm were received from server in the 1st
				 * round */
				/* The Response string is 
				 *    SET_1 = MD5(UserName:Realm:PWD)
				 *    SET_2 = MD5(RTSP_CMD:URI)
				 *    Challenge String = MD5(SET_1:Nonce:SET_2) */
				RTSPDigestRespStrBuild(Conf, "DESCRIBE", &Conf->Info.Digest);
				Conf->Info.CSeq += 1;
				RTSPDescribeReqBuildDigest(pkt, &len, Conf);
				if(WriteSockTCP(Conf->Sock, pkt, len, RTSP_TIMER_TX) == len) {
					len = sizeof(pkt);
					if(Conf->RespTime < 1000) WaitTime = 1000;
					if(ReadSockTCP(Conf->Sock, pkt, &len, WaitTime) == NET_SUCCESS) {
						if(RTSPDescribeReplyHandle(pkt, len, Conf) == RTSP_RET_OK) {
							return RTSPMediaDescribeGet(pkt, len, Conf);
						}
						/* else => fail in describe digest authentication */
					} /* else => fail to received server's reply */
				} /* else => fail to send the second round of describe packet */
			} /* else => fail anthentication in Base64, Digest or None coding */
		}
	}
	return RTSP_ERR;
}

int RTSPPlayReplyHandle(RTSP_HOST_CONF *Conf) {
	char buf[1024];
	int  len   = sizeof(buf);
	int  Cseq  = 0;
	int  index = 0;
	int  ret   = 0;
	int  i     = 0;

	if(ReadSockTCP(Conf->Sock, buf, &len, Conf->RespTime) == NET_SUCCESS) {
		/* check if it is a valid RTSP packet (\r\n\r\n ending packet) */
		if(IsValidRTSPFrame(buf, len) == RTSP_OK) {
			/* received a valid RTSP packet, get the RTSP return code */
			ret = RTSPRetCodeCseq(buf, len, &index, &Cseq);
			if(Cseq != Conf->Info.CSeq) {
				RTSPMsg1("<RTSPPlayReplyHandle>: CSeq error %d/%d\n", \
						Cseq, Conf->Info.CSeq);
				return RTSP_ERR;
			}
			if(ret != RTSP_RET_OK) {
				RTSPMsg1("<RTSPPlayReplyHandle>: Ret code error %d\n", ret);
				return RTSP_ERR;
			}
			/* Check the Session */
			ret = RTSPSessionIDGet(&buf[index], (len-index), &i);
			if(ret == Conf->Info.Session) {
				/* the session ID is correct, get the sequence number per media track */
				index += i;
				if(RTSPFindString(&buf[index], (len-index), &i, "track1;seq=")) {
					index += i;
					for(i = index ; i < len ; i ++) {
						if(buf[i] == ',') {
							buf[i] = '\0';
							Conf->Info.Media[0].Seq = atoi(&buf[index]);
							index = i+1;
							RTSPMsg1("<RTSPPlayReplyHandle>: Seq1=%d\n", \
									Conf->Info.Media[0].Seq);
							break;
						} else if((buf[i]==0x0d)&&(buf[i+1]==0x0a)) {
							buf[i] = '\0';
							Conf->Info.Media[0].Seq = atoi(&buf[index]);
							index = i+2;
							RTSPMsg1("<RTSPPlayReplyHandle>: Seq1=%d, End\n", \
									Conf->Info.Media[0].Seq);
							return RTSP_OK;
						}
					}
					if(i == len) {
						RTSPMsg1("<RTSPPlayReplyHandle>: seq not found\n");
						return RTSP_ERR;
					}
				} else {
					RTSPMsg1("<RTSPPlayReplyHandle>: track1;seq not found\n");
					return RTSP_ERR;
				}
				/* Success in getting the sequence number in track 1 and there is track2
				 * appended with this reply commmand, read the sequence number of track2 */
				if(RTSPFindString(&buf[index], (len-index), &i, "track2;seq=")) {
					index += i;
					for(i = index ; i < len ; i ++) {
						if((buf[i] == ',') || ((buf[i]==0x0d)&&(buf[i+1]==0x0a))) {
							buf[i] = '\0';
							Conf->Info.Media[1].Seq = atoi(&buf[index]);
							index += (i+1);
							RTSPMsg1("<RTSPHostPalyHandle>: Seq2=%d\n", \
									Conf->Info.Media[1].Seq);
							return RTSP_OK;
						}
					}
				} else {
					RTSPMsg1("<RTSPPlayReplyHandle>: track2;seq not found\n");
				}
			} else {
				RTSPMsg1("<RTSPHostPalyHandle>: Session error %d/%d\n", \
						ret, Conf->Info.Session);
			}
		} else {
			RTSPMsg1("<RTSPHostPalyHandle>: not valid RTSP packet\n");
		}
	}
	return RTSP_ERR;
}

int RTSPHostOptionGet(RTSP_HOST_CONF *Conf) {
	char pkt[1024];
	int  len = 0;

	/* build the OPTION request packet to send to RTSP server */
	sprintf(pkt, "OPTIONS rtsp://%s:%s@%s:%d RTSP/1.0\r\n" \
				 "CSeq: %d\r\n" \
				 "User-Agent: %s \r\n\r\n", \
				 Conf->Name, Conf->Pwd, Conf->SrvIP, Conf->SrvPort, \
				 Conf->Info.CSeq, \
				 RTP_PLAYER);
	len = strlen(pkt);
	/* Send this RTSP Option Req packet to Server now */
	if(WriteSockTCP(Conf->Sock, pkt, len, RTSP_TIMER_TX) == len) {
		/* success in sending the RTSP OPTION REQ packet, wait for server's
		 * reply */
		len = sizeof(pkt);
		if(ReadSockTCP(Conf->Sock, pkt, &len, Conf->RespTime) == NET_SUCCESS) {
			/* reviced server's reply, get the server's command capabilities */
			return RTSPOptionReplyHandle(pkt, len, &Conf->Info);
		}
	}
	return RTSP_ERR;
}

int RTSPHostSetupHandle(RTSP_HOST_CONF *Conf) {
	char pkt[1024];
	int  len  = 0;
	int  port = 0;

	Conf->Info.CSeq += 1;
	/* generate the host RTP/RTCP ports if it is RTP over UDP */
	if(Conf->RTPProt == RTSP_RTP_UDP) {
		port = RTSPGetRandomNum()&0xfffe; /* even port */
		if(port <= 1024) port += 1024;
		Conf->Info.Media[0].RTPHostPort  = port;
		Conf->Info.Media[0].RTCPHostPort = port+1;
		Conf->Info.Media[1].RTPHostPort  = port+2;
		Conf->Info.Media[1].RTCPHostPort = port+3;
	}
	/* initialize the session ID */
	Conf->Info.Session = 0;
    /* build the 1st Describe request packet to send to RTSP server */
    if(Conf->Encoder == RTSP_ENCODER_BASE64) {
		/* send the video setup command first */
		RTSPSetupReqBuildBase64(pkt, &len, Conf, &Conf->Info.Media[0]);
	} else {
		/* send the video setup command first */
		RTSPSetupReqBuildDigest(pkt, &len, Conf, &Conf->Info.Media[0]);
	}
	/* send the video setup cmd */
	/* Send this RTSP Option Req packet to Server now */
	if(WriteSockTCP(Conf->Sock, pkt, len, RTSP_TIMER_TX) == len) {
		/* success in sending the RTSP SETUP Video REQ packet, 
		 * wait for server's reply */
		len = sizeof(pkt);
		if(ReadSockTCP(Conf->Sock, pkt, &len, Conf->RespTime) == NET_SUCCESS) {
			/* reviced server's reply, get the server's command capabilities */
			if(RTSPSetupReplyHandle(pkt, len, Conf, &Conf->Info.Media[0]) == RTSP_ERR) 
				return RTSP_ERR;
		}
	} else return RTSP_ERR;
	/* check if there is audio media */
	if(Conf->Info.Media[1].Type) {
		/* Setup the Audio Media */
		Conf->Info.CSeq += 1;
		/* build the 1st Describe request packet to send to RTSP server */
		if(Conf->Encoder == RTSP_ENCODER_BASE64) {
			/* send the video setup command first */
			RTSPSetupReqBuildBase64(pkt, &len, Conf, &Conf->Info.Media[1]);
		} else {
			/* send the video setup command first */
			RTSPSetupReqBuildDigest(pkt, &len, Conf, &Conf->Info.Media[1]);
		}
		if(WriteSockTCP(Conf->Sock, pkt, len, RTSP_TIMER_TX) == len) {
			/* success in sending the RTSP SETUP Audio REQ packet,
			 * wait for server's reply */
			len = sizeof(pkt);
			if(ReadSockTCP(Conf->Sock, pkt, &len, Conf->RespTime) == NET_SUCCESS) {
				/* reviced server's reply, get the server's command capabilities */
				if(RTSPSetupReplyHandle(pkt, len, Conf, &Conf->Info.Media[1]) == RTSP_ERR)
					return RTSP_ERR;
			}
			return RTSP_OK;
		}
	}
	return RTSP_OK;
}

int RTSPPlayCmdSend(RTSP_HOST_CONF *Conf) {
	char pkt[1024];
	int  len  = 0;

	/* build the RTSP PLAY Cmd packet */
	Conf->Info.CSeq += 1;
	if(Conf->Encoder == RTSP_ENCODER_BASE64) {
		RTSPPlayReqBuildBase64(pkt, &len, Conf);
	} else {
		RTSPPlayReqBuildDigest(pkt, &len, Conf);
	}
	/* send this PLAY Req packet to the server now */
	if(WriteSockTCP(Conf->Sock, pkt, len, RTSP_TIMER_TX) == len) return RTSP_OK;
	return RTSP_ERR;
}

int RTSPTeardownCmdSend(RTSP_HOST_CONF *Conf) {
	char pkt[1024];
	int  len  = 0;

	/* build the RTSP Teardown Cmd packet */
	Conf->Info.CSeq += 1;
	if(Conf->Encoder == RTSP_ENCODER_BASE64) {
		RTSPTeardownReqBuildBase64(pkt, &len, Conf);
	} else {
		RTSPTeardownReqBuildDigest(pkt, &len, Conf);
	}
	/* send this PLAY Req packet to the server now */
	if(WriteSockTCP(Conf->Sock, pkt, len, RTSP_TIMER_TX) == len) return RTSP_OK;
	return RTSP_ERR;
}

/* #######################################################################
 * Static functions
 * ####################################################################### */
static int Char2Hex(char c) {

	if((c >= '0') && (c <= '9')) return (c-'0');
	if((c >= 'a') && (c <= 'f')) return (10+(c-'a'));
	if((c >= 'A') && (c <= 'F')) return (10+(c-'A'));
	return 0;
}

static int RTSPDigestParser(char *buf, int len, char *RetStr) {
	int i = 0;
	int k = 0;
	
	/* find the first " */
	for(i = 0;  i < len ; i ++) {
		if(buf[i] == '\"') break;
	}
	if(i == len) return RTSP_ERR;
	/* find the next " */
	i ++;
	for(k = i ; k < RTSP_DIGEST_LEN ; k ++) {
		if(buf[k] == '\"') break;
	}
	if(k == RTSP_DIGEST_LEN) return RTSP_ERR;
	memcpy(RetStr, &buf[i], (k-i));
	return RTSP_OK;		
}

static int GetRTSPDigestStrings(char *buf, int len, RTSP_DIGEST *Digest) {
	int i   = 0;
	int k   = 0;
	int ret = 0;

	/* try to get the realm */
	for(i = 0 ; i < (len-5) ; i ++) {
		if( (buf[i]=='r')&&(buf[i+1]=='e')&&(buf[i+2]=='a')&&\
			(buf[i+3]=='l')&&(buf[i+4]=='m')&&(buf[i+5]=='=')) {
			/* get the realm head */
			k = i+5;
			if(RTSPDigestParser(&buf[k], (len-k), Digest->Realm) == RTSP_OK) {
				ret |= GET_DIGETS_REALM;
				RTSPMsg0("<GetRTSPDigestStrings>: realm=%s\n", Digest->Realm);
			} else return 0;
		}
		if( (buf[i]=='n')&&(buf[i+1]=='o')&&(buf[i+2]=='n')&&\
			(buf[i+3]=='c')&&(buf[i+4]=='e')&&(buf[i+5]=='=')) {
			/* get the nonce head */
			k = i+5;
			if(RTSPDigestParser(&buf[k], (len-k), Digest->Nonce) == RTSP_OK) {
				ret |= GET_DIGETS_NONCE;
				RTSPMsg0("<GetRTSPDigestStrings>: nounce=%s\n", Digest->Nonce);
			} else return 0;
		}
		if((buf[i]=='u')&&(buf[i+1]=='r')&&(buf[i+2]=='i')&&(buf[i+3]=='=')) {
			/* get the nonce head */
			k = i+3;
			if(RTSPDigestParser(&buf[k], (len-k), Digest->Uri) == RTSP_OK) {
				ret |= GET_DIGETS_URI;
				RTSPMsg0("<GetRTSPDigestStrings>: uri=%s\n", Digest->Uri);
			} else return 0;
		}
		if(	(buf[i]=='r')&&(buf[i+1]=='e')&&(buf[i+2]=='s')&&\
			(buf[i+3]=='p')&&(buf[i+4]=='o')&&(buf[i+5]=='n')&&\
			(buf[i+6]=='s')&&(buf[i+7]=='e')&&(buf[i+8]=='=')) {
			/* get the nonce head */
			k = i+8;
			if(RTSPDigestParser(&buf[k], (len-k), Digest->Resp) == RTSP_OK) {
				ret |= GET_DIGETS_RESP;
				RTSPMsg0("<GetRTSPDigestStrings>: uri=%s\n", Digest->Resp);
			} else return 0;
		}
	}
	return ret;
}

static int IsValidRTSPFrame(char *buf, int len) {
	int i = 0;

	for(i = 0 ; i < len-2 ; i=i+2) {
		if((buf[i] == 0xd) && (buf[i+1] == 0xa)) {
			if(buf[i+2] == 0xd) {
				/* I got a complete RTSP message */
				return RTSP_OK;
			}
		} else if((buf[i] == 0xa) && (buf[i+1] == 0xd)) {
			if(buf[i+2] == 0xa) {
				/* I got a complete RTSP message */
				return RTSP_OK;
			}
		}
	}
	return RTSP_ERR;
}

static void RTSPDescribeReqBuildBase64(char *buf, int *len, RTSP_HOST_CONF *Conf) {

	/* TODO!! Not implemant now */
	return;
}

static void RTSPDescribeReqBuildDigest(char *buf, int *len, RTSP_HOST_CONF *Conf) {

	if(strlen(Conf->Info.Digest.Nonce)) {
		/* there is the Nonce string from RTSP server before, Generate the
		 * chellenge string */
		sprintf(buf, "DESCRIBE rtsp://%s:%s@%s:%d RTSP/1.0\r\n" \
					 "CSeq: %d\r\n" \
					 "Accept: application/sdp\r\n" \
					 "%s username=\"%s\", realm=\"%s\", nonce=\"%s\", uri=\"%s\", response=\"%s\"\r\n"
					 "User-Agent: %s \r\n\r\n", \
					 Conf->Name, Conf->Pwd, Conf->SrvIP, Conf->SrvPort, \
					 Conf->Info.CSeq, \
					 "Authorization: Digest", Conf->Name, Conf->Info.Digest.Realm, \
					 Conf->Info.Digest.Nonce, Conf->Info.Digest.Uri, Conf->Info.Digest.Resp, \
					 RTP_PLAYER);
		*len = strlen(buf);
		return;
	}
	/* build the none encrypt describe packet */
	sprintf(buf, "DESCRIBE rtsp://%s:%s@%s:%d RTSP/1.0\r\n" \
				 "CSeq: %d\r\n" \
				 "Accept: application/sdp\r\n" \
				 "User-Agent: %s \r\n\r\n", \
				 Conf->Name, Conf->Pwd, Conf->SrvIP, Conf->SrvPort, \
				 Conf->Info.CSeq, \
				 RTP_PLAYER);
	*len = strlen(buf);
	return;
}

static int RTSPDescribeReplyHandle(char *buf, int len, RTSP_HOST_CONF *Conf) {
	int index = 0;
	int ret   = 0;
	int Cseq  = 0;

	/* check if it is a valid RTSP packet (\r\n\r\n ending packet) */
	if(IsValidRTSPFrame(buf, len) == RTSP_OK) {
		/* received a valid RTSP packet, get the RTSP return code */
		ret = RTSPRetCodeCseq(buf, len, &index, &Cseq);
		/*
		printf("<RTSPDescribeReplyHandle>: ret=%d, index=%d, cseq=%d\n", \
				ret, index, Cseq);
		*/
		if(Cseq != Conf->Info.CSeq) return RTSP_ERR;
		if(ret == RTSP_RET_OK) return RTSP_RET_OK; /* authentication success */
		if(Conf->Encoder == RTSP_ENCODER_DIGEST) {
			if(strlen(Conf->Info.Digest.Nonce) == 0) {
				/* fail of the 1st Authentication, The server gave me the 
				 * Nonce and Realm. I could used them to generate the 
				 * response string (challenge string). So, get the Nonce and
				 * Realm form this packet now */
				if(GetRTSPDigestStrings(&buf[index], \
										(len-index), \
										&Conf->Info.Digest) == \
						(GET_DIGETS_NONCE|GET_DIGETS_REALM)) {
					return RTSP_OK;
				} /* else => cannot find the realm string */
			} /* else => I already sent the challenge string to server and 
				         server reject my authentication. return fail to upper layer */
		} /* else => Not using digest authentication method, 
			         return error to upper layer */
	} /* esle => not a valid RTSP frame */
	return RTSP_ERR;
}

static void RTSPDigestRespStrBuild(RTSP_HOST_CONF *Conf, char *Cmd, RTSP_DIGEST *Digest) {
	int  len = 0;
	char buf[256];
	char data1[33];
	char data2[33];

	len = strlen(Conf->Name)+1+strlen(Digest->Realm)+1+strlen(Conf->Pwd);
	sprintf(buf, "%s:%s:%s", Conf->Name, Digest->Realm, Conf->Pwd);
	buf[len] = '\0';
	md5_generate(buf, data1, len);

	len = strlen(Cmd) + 1 + strlen(Digest->Uri);
	sprintf(buf, "%s:%s", Cmd, Digest->Uri);
	buf[len] = '\0';
	md5_generate(buf, data2, len);
	
	len = 32+1+strlen(Digest->Nonce)+1+32;
	sprintf(buf, "%s:%s:%s", data1, Digest->Nonce, data2);
	buf[len] = '\0';
	md5_generate(buf, Digest->Resp, len);
	RTSPMsg0("<RTSPDigestRespStrBuild>: Digest Resp (%dB)=%s\n", \
			strlen(Digest->Resp), Digest->Resp);
	return;
}

static int RTSPMediaDescribeGet(char *buf, int len, RTSP_HOST_CONF *Conf) {
	int i   = 0;
	int pos = 0;
	int ret = 0;

	/* get the video description first */
	if(RTSPFindString(buf, len, &pos, "m=video")) {
		ret = RTSPMediaDescribeVideoGet(&buf[pos], (len-pos), Conf);
		if(ret == 0) {
			RTSPMsg1("<RTSPMediaDescribeGet>: Error in Video description(%d/%d)\n", pos, len);
			return RTSP_ERR;
		}
		pos += (ret-1);
	} else return RTSP_ERR;
	/* get the audio description, it might not have audio description if the video
	 * server doesn't have audio */
	if(RTSPFindString(&buf[pos], (len-pos), &i, "m=audio")) {
		pos += i;
		if(RTSPMediaDescribeAudioGet(&buf[pos], (len-pos), Conf) == 0) {
			RTSPMsg1("<RTSPMediaDescribeGet>: Error in Audio description(%d/%d)\n", pos, len);
		}
	}
	return RTSP_OK;
}

static int RTSPMediaDescribeAudioGet(char *buf, int len, RTSP_HOST_CONF *Conf) {
	int i    = 0;
	int k    = 0;

	/* get the RTP protocol and the RTP/RTCP ports if the RTP protocol is UDP
	 * over Multicast */
	i = RTSPMediaDescribeProtocolGet(buf, \
									 len, \
									 &Conf->RTPProt, \
									 &Conf->Info.Media[1]);
	if(i == 0) return 0;

	/* find the audio media type */
	k = RTSPMediaDescribeTypeGet(&buf[i], (len-i), &Conf->Info.Media[1].Type);
	if(k == 0) return 0;

	/* find the control path */
	i = RTSPMediaDescribeCtrlGet(&buf[k], (len-k), Conf->Info.Media[1].CtrlPath);
	if(i == 0) return 0;
#if 0
	printf("<RTSPMediaDescribeAudioGet>: Dump\n");
	printf("Type=%d, RTPPort=(%d,%d), RTCPPort(%d,%d), MCastIP=%s, Protocol=%d\n", \
			Conf->Info.Media[1].Type, \
			Conf->Info.Media[1].RTPSrvPort, Conf->Info.Media[1].RTPHostPort, \
			Conf->Info.Media[1].RTCPSrvPort, Conf->Info.Media[1].RTCPHostPort, \
			Conf->SrvMcastIP, Conf->RTPProt);
	printf("Control=%s\n", Conf->Info.Media[1].CtrlPath);
#endif											
	return i;
}

static int RTSPMediaDescribeConfigGet(char *buf, int len, RTSP_MEDIA *Media) {
	int i = 0;
	int k = 0;
	int m = 0;

	RTSPMsg0("<RTSPMediaDescribeConfigGet>:\n");
	Media->ConfigLen = 0;
	if(RTSPFindString(buf, len, &i, "config=")) {
		for(k = i ; k < len ; k ++) {
			if((buf[k] == 0x0d)&&(buf[k+1] == 0x0a)) {
				Media->ConfigLen = m;
				RTSPMsg0("(Len=%d)\n", Media->ConfigLen);
				return (k+2);
			}
			Media->Config[m] = Char2Hex(buf[k]);
			RTSPMsg0("%02x%s", Media->Config[m], ((m+1)%10)?",":"\n");
			m ++;
			if(m == 128) return 0;
		}
	}
	return 0;
}

static int RTSPMediaDescribeCtrlGet(char *buf, int len, char *CtrlPath) {
	int i = 0;
	int k = 0;
	int m = 0;

	CtrlPath[0] = '\0';
	if(RTSPFindString(buf, len, &i, "control:")) {
		for(k = i ; k < len ; k ++) {
			if((buf[k] == 0x0d)&&(buf[k+1] == 0x0a)) {
				CtrlPath[m] = '\0';
				return (k+2);
			}
			CtrlPath[m] = buf[k];
			m ++;
			if(m == 32) {
				memset(CtrlPath, '\0', 32);
				return 0;
			}
		}
	}
	return 0;
}

static int RTSPMediaDescribeMcastIPGet(char *buf, int len, char *McastIP) {
	int i = 0;
	int k = 0;

	for(i = 0 ; i < (len-3) ; i ++) {
		if((buf[i]=='I')&&(buf[i+1]=='P')&&(buf[i+2]=='4')) {
			/* skip all space characters */
			for(k = (i+3) ; k < len ; k ++) {
				if(buf[k] != ' ') break;
			}
			if(k == len) return 0;
			for(i = k ; i < len ; i ++) {
				if((buf[i] == 0x0d)&&(buf[i+1] == 0x0a)) {
					buf[i] = '\0';
					memcpy(McastIP, &buf[k], (i-k));
					return (i+2);
				} else if(buf[i] == '/') {
					buf[i] = '\0';
					memcpy(McastIP, &buf[k], (i-k));
					return (i+1);
				}
				if((i-k) == 15) break;
			}
		}
	}
	return 0;
}

static int RTSPMediaDescribeProtocolGet(char *buf, \
										int len, \
										int *RTPProt, \
										RTSP_MEDIA *Media) {
	int i    = 0;
	int k    = 0;
	int port = 0;

	/* skip all space characters */
	for(i = 0 ; i < len ; i ++) {
		if(buf[i] != ' ') break;
	}
	if(i == len) return 0;
	/* find next space characters */
	for(k = i ; i < len ; k ++) {
		if(buf[k] == ' ') {
			buf[k] = '\0';
			port = atoi(&buf[i]);
			if(port == 0) { /* unicast RTP */
				*RTPProt = RTSP_RTP_UDP;
				RTSPMsg0("<RTSPMediaDescribeProtocolGet>: RTP Over UDP\n");
			} else {
				*RTPProt = RTSP_RTP_MULTICAST;
				/* set the RTP/RTCP ports */
				Media->RTPSrvPort   = port;
				Media->RTPHostPort  = port;
				Media->RTCPSrvPort  = port+1;
				Media->RTCPHostPort = port+1;
				RTSPMsg0("<RTSPMediaDescribeProtocolGet>: RTP Over Mcast\n");
			}
			return (k+1);
		}
	}
	/*printf("<RTSPMediaDescribeProtocolGet>: Unknown\n");*/
	return (k+1);
}

static int RTSPMediaDescribeTypeGet(char *buf, int len, int *Type) {
	int i   = 0;
	int k   = 0;
	int num = 0;

	if(RTSPFindString(buf, len, &i, "rtpmap:")) {
		for(k = i ; k < len ; k ++) {
			if(buf[k] == ' ') {
				buf[k] = '\0';
				num = atoi(&buf[i]);
				if(num == RTSP_MEDIA_MP4V_ES90000)  { /* MP4V-ES/9000 */
					*Type = RTSP_MEDIA_MP4V_ES90000;
					/*printf("<RTSPMediaDescribeTypeGet>:  MP4V-ES/9000\n");*/
					return (k+1);
				}
				if(num == RTSP_MEDIA_PCM16_8KHZ) { /* PCM, 16bit,8KHz */
					*Type = RTSP_MEDIA_PCM16_8KHZ;
					/*printf("<RTSPMediaDescribeTypeGet>:  PCM16/8000\n");*/
					return (k+1);
				}
				RTSPMsg1("<RTSPMediaDescribeTypeGet>: Unknown %d\n", num);
				return 0;
			}
		}
	}
	return 0;
}

static int RTSPMediaDescribeVideoGet(char *buf, int len, RTSP_HOST_CONF *Conf) {
	int i    = 0;
	int k    = 0;
	
	/* get the RTP protocol and the RTP/RTCP ports if the RTP protocol is UDP
	 * over Multicast */
	i = RTSPMediaDescribeProtocolGet(buf, \
									len, \
									&Conf->RTPProt, \
									&Conf->Info.Media[0]);
	if(i == 0) return 0;
	
	/* find the Multicast IP address if it is multicast RTP */
	if(Conf->RTPProt == RTSP_RTP_MULTICAST) {
		k = RTSPMediaDescribeMcastIPGet(&buf[i], (len-i), Conf->SrvMcastIP);
		if(k == 0) return 0;
		i += k;
	}
	
	/* find the video media type */
	k = RTSPMediaDescribeTypeGet(&buf[i], (len-i), &Conf->Info.Media[0].Type);
	if(k == 0) return 0;
	i += k;
	
	/* find the config string */
	k = RTSPMediaDescribeConfigGet(&buf[i], (len-i), &Conf->Info.Media[0]);
	if(k == 0) return 0;
	i += k;
	
	/* find the control path */
	k = RTSPMediaDescribeCtrlGet(&buf[i], (len-i), Conf->Info.Media[0].CtrlPath);
	if(k == 0) return 0;
	i += k;
#if 0
	printf("<RTSPMediaDescribeVideoGet>: Dump\n");
	printf("Config(%dB):\n", Conf->Info.Media[0].ConfigLen);
	for(k = 0; k < Conf->Info.Media[0].ConfigLen ; k ++) {
		printf("%02x,", Conf->Info.Media[0].Config[k]);
		if((k+1)%16 == 0) printf("\n");
	}
	printf("\n");
	printf("Type=%d, RTPPort=(%d,%d), RTCPPort(%d,%d), MCastIP=%s, Protocol=%d\n", \
			Conf->Info.Media[0].Type, \
			Conf->Info.Media[0].RTPSrvPort, Conf->Info.Media[0].RTPHostPort, \
			Conf->Info.Media[0].RTCPSrvPort, Conf->Info.Media[0].RTCPHostPort, \
			Conf->SrvMcastIP, Conf->RTPProt);
	printf("Control=%s\n", Conf->Info.Media[0].CtrlPath);
#endif
	return i;	
}

static int RTSPOptionReplyHandle(char *buf, int len, RTSP_HOST_INFO *Info) {
	int  index = 0;
	int  i     = 0;
	int  Cseq  = 0;
	char cmd[32];

	Info->SrvRTSPCmdCap = 0;
	/* check if it is a valid RTSP packet (\r\n\r\n ending packet) */
	if(IsValidRTSPFrame(buf, len) == RTSP_OK) {
		/* received a valid RTSP packet, get the RTSP return code */
		if(RTSPRetCodeCseq(buf, len, &index, &Cseq) == RTSP_RET_OK) {
			if(Cseq != Info->CSeq) {
				RTSPMsg1("<RTSPOptionReplyHandle>: Cseq Err. %d/%d\n", Cseq, Info->CSeq);
				return RTSP_ERR;
			}
			/* get the OK reply from server, read the command capability now */
			if(RTSPFindString(&buf[index], (len-index), &i, "Public:")) {
				index += i;
				i = 0;
				do {
					cmd[i] = buf[index];
					if((cmd[i] == ',') || (cmd[i] == 0x0d)) {
						cmd[i] = '\0';
						i = 0;	
						if(strcmp(cmd, "OPTIONS") == 0) {
							Info->SrvRTSPCmdCap |= RTSP_CMD_CAP_OPTION; 
						} else if(strcmp(cmd, "DESCRIBE") == 0) {
							Info->SrvRTSPCmdCap |= RTSP_CMD_CAP_DESCRIBE;
						} else if(strcmp(cmd, "SETUP") == 0) {
							Info->SrvRTSPCmdCap |= RTSP_CMD_CAP_SETUP;
						} else if(strcmp(cmd, "SET_PARAMETER") == 0) {
							Info->SrvRTSPCmdCap |= RTSP_CMD_CAP_SETPARAM;
						} else if(strcmp(cmd, "TEARDOWN") == 0) {
							Info->SrvRTSPCmdCap |= RTSP_CMD_CAP_TEARDOWN;
						} else if(strcmp(cmd, "PLAY") == 0) {
							Info->SrvRTSPCmdCap |= RTSP_CMD_CAP_PLAY;
						} else if(strcmp(cmd, "PAUSE") == 0) {
							Info->SrvRTSPCmdCap |= RTSP_CMD_CAP_PAUSE;
						} else {
							RTSPMsg1("<RTSPOptionReplyHandle>: Unknown Cmd %s\n", cmd);
							/*return RTSP_ERR;*/
						}
					} else if(cmd[i] != ' ') {
						i ++;
					}
					if((buf[index] == 0x0d)&&(buf[index+1] == 0x0a)) return RTSP_OK;
					index ++;
				} while(index < len);
				RTSPMsg1("<RTSPOptionReplyHandle>: OPTIONS parser error\n");
			} else {
				RTSPMsg1("<RTSPOptionReplyHandle>: can not find Public: tag\n");
			}
		} else {
			RTSPMsg1("<RTSPOptionReplyHandle>: Return error\n");
		}
	}
	return RTSP_ERR;
}

static void RTSPPlayReqBuildBase64(char *buf, int *len, RTSP_HOST_CONF *Conf) {
	
	return;
}

static void RTSPPlayReqBuildDigest(char *buf, int *len, RTSP_HOST_CONF *Conf) {

	/* build the challenge string for this PLAY command */
	RTSPDigestRespStrBuild(Conf, "PLAY", &Conf->Info.Digest);
	sprintf(buf, "PLAY rtsp://%s:%s@%s:%d RTSP/1.0\r\n" \
				 "CSeq: %d\r\n" \
				 "Session: %d\r\n" \
				 "Range: %s\r\n" \
				 "%s username=\"%s\", realm=\"%s\", nonce=\"%s\", uri=\"%s\", response=\"%s\"\r\n"
				 "User-Agent: %s \r\n\r\n", \
				 Conf->Name, Conf->Pwd, Conf->SrvIP, Conf->SrvPort, \
				 Conf->Info.CSeq, \
				 Conf->Info.Session, \
				 "ntp=0.0000-", \
				 "Authorization: Digest", Conf->Name, Conf->Info.Digest.Realm, \
				 Conf->Info.Digest.Nonce, Conf->Info.Digest.Uri, Conf->Info.Digest.Resp, \
				 RTP_PLAYER);
	*len = strlen(buf);
	return;
}

static int RTSPRetCodeCseq(char *buf, int len, int *index, int *Cseq) {
	int i    = 0;
	int k    = 0;
	int find = 0;
	int ret  = 0;

	for(i = 0 ; i < (len-4) ; i=i+4) {
		if( ((buf[i]=='r') && (buf[i+1]=='t') && (buf[i+2]=='s') && (buf[i+3]=='p')) || \
			((buf[i]=='R') && (buf[i+1]=='T') && (buf[i+2]=='S') && (buf[i+3]=='P'))) {
			/* find the RTSP string, find the first space */
			find = 1;
			while(buf[++i] != ' ');
			i ++;
			break;
		}
	}
	if(find) {
		/* find the return code */
		k = i;
		/* find the next space */
		while(buf[++k] != ' ');
		buf[k] = '\0';
		k ++;
		ret = atoi(&buf[i]);
	} else return RTSP_ERR;
	/* found the return code. try to get the CSeq now */
	if(RTSPFindString(&buf[k], (len-k), &i, "CSeq:")) {
		k += i;
		/* find the CSeq: string. skip all space characters */
		for(i = k ; i < len ; i ++) {
			if(buf[i] != ' ') {
				break;
			}
		}
		k = i;
		while((buf[i]!=0x0d)&&(buf[i+1]!=0x0a)) i++;
		buf[i]='\0';
		*Cseq = atoi(&buf[k]);
		*index = i + 2;
		RTSPMsg0("<RTSPRetCodeCseq>: CSeq=%d, RetCode=%d\n", *Cseq, ret);
		return ret;
	}
	return RTSP_ERR;
}

static int RTSPSessionIDGet(char *buf, int len, int *index) {
	int i = 0;
	int k = 0;

	if(RTSPFindString(buf, len, &i, "Session:")) {
		/* find the Session: Tag, skip the empty characters */
		for(k = i ; k < len ; k ++) {
			if(buf[k] != ' ') {
				/* find the 0x0d, 0x0a */
				i = k;
				while((buf[i]!=0x0d)&&(buf[i+1]!=0x0a)) i++;
				buf[i]='\0';
				*index = i + 2;
				return atoi(&buf[k]);
			}
		}
	}
	return -1;
}

static int RTSPSetupReplyHandle(char *buf, \
								int len, \
								RTSP_HOST_CONF *Conf, \
								RTSP_MEDIA *Media) {
	int  i      = 0;
	int  k      = 0;
	int  index  = 0;
	int  Cseq   = 0;

	/* check if it is a valid RTSP packet (\r\n\r\n ending packet) */
	if(IsValidRTSPFrame(buf, len) == RTSP_OK) {
		/* received a valid RTSP packet, get the RTSP return code */
		if(RTSPRetCodeCseq(buf, len, &index, &Cseq) == RTSP_RET_OK) {
			if(Cseq != Conf->Info.CSeq) {
				RTSPMsg1("<RTSPSetupReplyHandle>: Cseq Err. %d/%d\n", \
						Cseq, Conf->Info.CSeq);
				return RTSP_ERR;
			}
			/* success in the setup process !! record the server ports */
			if(Conf->RTPProt == RTSP_RTP_UDP) {
				if(RTSPFindString(&buf[index], len, &k, "server_port=")) {
					index += k;
					/* find the server-port string. get the server ports */
					for(i = index ; i < (index+6) ; i ++) {
						if(buf[i] == '-') {
							buf[i] = '\0';
							Media->RTPSrvPort = atoi(&buf[index]);
							index = i+1;	
							RTSPMsg1("<RTSPSetupReplyHandle>: Srv RTP port=%d\n", \
									Media->RTPSrvPort);				
							break;
						}
					}
						if(i == (index+6)) return RTSP_ERR;
					for(i = index ; i < (index+6) ; i ++) {
						if((buf[i] == 0x0d) && (buf[i+1] == 0x0a)) {
							buf[i] = '\0';
							Media->RTCPSrvPort = atoi(&buf[index]);
							index = i+2;			
							RTSPMsg1("<RTSPSetupReplyHandle>: Srv RTCP port=%d\n", \
									Media->RTCPSrvPort);				
							break;
						}
					}
					if(i == (index+6)) return RTSP_ERR;
				} else return RTSP_ERR;
			} else {
				if(RTSPFindString(&buf[index], len, &k, "port=")) {
					index += k;
					for(i = index ; i < (index+6) ; i ++) {
						if((buf[i]==';')||((buf[i]==0x0d)&&(buf[i+1]==0x0a))) {
							buf[i] = '\0';
							Media->RTPSrvPort  = atoi(&buf[index]);
							Media->RTCPSrvPort = Media->RTPSrvPort+1;
							index = i+1;
							RTSPMsg1("<RTSPSetupReplyHandle>: Srv /RTPRTCP port=%d/%d\n", \
									Media->RTPSrvPort, Media->RTCPSrvPort);
							break;
						}
					}
					if(i == (index+6)) return RTSP_ERR;
				} else return RTSP_ERR;
			}
			/* get the Session number */
			if(RTSPFindString(&buf[index], len, &k, "Session:")) {
				index += k;
				for(i = index ; i < len ; i ++) {
					if(buf[i] != ' ') break;
				}
				if(i == len) return RTSP_ERR;
				index = i;
				for(i = index ; i < len ; i ++) {
					if((buf[i] == 0x0d) && (buf[i+1] == 0x0a)) {
						buf[i] = '\0';
						Conf->Info.Session = atoi(&buf[index]);
						RTSPMsg1("<RTSPSetupReplyHandle>: Session=%d\n", \
								Conf->Info.Session);
						return RTSP_OK;
					}
				}
			}
		}
	}

    return RTSP_ERR;
}

static void RTSPSetupReqBuildBase64(char *buf, \
									int *len, \
									RTSP_HOST_CONF *Conf, \
									RTSP_MEDIA *Media) {

	/* TODO!! not implemented */
	return;
}

static void RTSPSetupReqBuildDigest(char *buf, \
									int *len, \
									RTSP_HOST_CONF *Conf, \
									RTSP_MEDIA *Media) {

	/* build the challenge string for this SETUP command */
	RTSPDigestRespStrBuild(Conf, "SETUP", &Conf->Info.Digest);
	//Conf->Info.CSeq += 1;
	if(Conf->Info.Session == 0) {
		sprintf(buf, "SETUP rtsp://%s:%s@%s:%d/%s RTSP/1.0\r\n" \
					 "CSeq: %d\r\n" \
					 "Transport: RTP/AVP;%s;client_port=%d-%d\r\n" \
					 "%s username=\"%s\", realm=\"%s\", nonce=\"%s\", uri=\"%s\", response=\"%s\\r\n" \
					 "User-Agent: %s\r\n\r\n", \
					 Conf->Name, Conf->Pwd, Conf->SrvIP, Conf->SrvPort, \
					 Media->CtrlPath, \
					 Conf->Info.CSeq, \
					 (Conf->RTPProt==RTSP_RTP_UDP)?"unicast":"multicast", \
					 Media->RTPHostPort, Media->RTCPHostPort, \
					 "Authorization: Digest", Conf->Name, Conf->Info.Digest.Realm, \
					 Conf->Info.Digest.Nonce, Conf->Info.Digest.Uri, Conf->Info.Digest.Resp, \
					 RTP_PLAYER);
	} else {
		sprintf(buf, "SETUP rtsp://%s:%s@%s:%d/%s RTSP/1.0\r\n" \
				     "CSeq: %d\r\n" \
					 "Transport: RTP/AVP;%s;client_port=%d-%d\r\n" \
					 "Session: %d\r\n" \
					 "%s username=\"%s\", realm=\"%s\", nonce=\"%s\", uri=\"%s\", response=\"%s\\r\n" \
					 "User-Agent: %s\r\n\r\n", \
					 Conf->Name, Conf->Pwd, Conf->SrvIP, Conf->SrvPort, \
					 Media->CtrlPath, \
					 Conf->Info.CSeq, \
					 (Conf->RTPProt==RTSP_RTP_UDP)?"unicast":"multicast", \
					 Media->RTPHostPort, Media->RTCPHostPort, \
					 Conf->Info.Session, \
					 "Authorization: Digest", Conf->Name, Conf->Info.Digest.Realm, \
					 Conf->Info.Digest.Nonce, Conf->Info.Digest.Uri, Conf->Info.Digest.Resp, \
					 RTP_PLAYER);
	}
	*len = strlen(buf);
	return;
}

static void RTSPTeardownReqBuildBase64(char *buf, int *len, RTSP_HOST_CONF *Conf) {

	return;
}

static void RTSPTeardownReqBuildDigest(char *buf, int *len, RTSP_HOST_CONF *Conf) {

	/* build the challenge string for this SETUP command */
	RTSPDigestRespStrBuild(Conf, "TEARDOWN", &Conf->Info.Digest);
	sprintf(buf, "TEARDOWN rtsp://%s:%s@%s:%d RTSP/1.0\r\n" \
			 	 "CSeq: %d\r\n" \
				 "Session: %d\r\n" \
				 "%s username=\"%s\", realm=\"%s\", nonce=\"%s\", uri=\"%s\", response=\"%s\\r\n" \
				 "User-Agent: %s\r\n\r\n", \
				 Conf->Name, Conf->Pwd, Conf->SrvIP, Conf->SrvPort, \
				 Conf->Info.CSeq, \
				 Conf->Info.Session, \
				 "Authorization: Digest", Conf->Name, Conf->Info.Digest.Realm, \
				 Conf->Info.Digest.Nonce, Conf->Info.Digest.Uri, Conf->Info.Digest.Resp, \
				 RTP_PLAYER);
	*len = strlen(buf);
	return;
}
