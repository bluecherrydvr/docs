// vim: ts=4 sw=4
/* #######################################################################
 * RTCPHost.c
 * Created by MingYoung   Date:2007/04/10
 * Description:
 *    Provide the RTCP Host Access APIs
 * ####################################################################### */
#include "common.h"
#include "NetAccess.h"
#include "NetRtsp.h"
#include "NetRtcp.h"

#define RTCPHostMsg1(fmt, args...) printf(fmt, ##args)
#define RTCPHostMsg0(fmt, args...)

/* #######################################################################
 * Static functions
 * ####################################################################### */
static void CloseRTCPSockets(RTCP_HOST_CONF *);
static int  IsRRTimerExpired(RTCP_DATA *, time_t);
static int  IsValidRTCPPkt(char *, int);
static void RTCPHostPktHandler(RTCP_MEDIA *);
static void RTCPSendRRPkt(RTCP_HOST_CONF *, RTCP_MEDIA *);
static void RTCPSRHandler(RTCP_HEADER *, RTCP_MEDIA *);

/* #######################################################################
 * Public APIs
 * ####################################################################### */
int CreateRTCPHostSockets(RTCP_HOST_CONF *Conf) {
	RTCP_MEDIA         *Media;
	int                i = 0;

	for(i = 0 ; i < 2 ; i ++) {
		Media = &Conf->Media[i];
		/* Create the RTCP Host sockets */
		if(Media->SrvPort && Media->HostPort) {
			if(CreateUDPSocket(&Media->Sock) == NET_SUCCESS) {
				/* Success in creating the socket!! bind the 
				 * INADDR_ANY:Port to this socket */
				if(BindSocket(Media->Sock, NULL, Media->HostPort) == NET_ERROR) {
					/* fail of binding the socket */
					RTCPHostMsg1("<CreateRTCPHostSockets>: fail to bind socket @ port=%d", \
							Media->HostPort);
					CloseRTCPSockets(Conf);
					return RTCP_ERR;
				}
				/* set the reuse address socket option to speed up 
				 * re-openning these ports */
				if(SockOptReusedAddrSet(Media->Sock) == NET_ERROR) {
					/* fail of set the Reused Address socket option */
					RTCPHostMsg1("<CreateRTCPHostSockets>: fail to set ReusedAddr sockopt\n");
					CloseRTCPSockets(Conf);
					return RTCP_ERR;
				}
				if(Conf->RTPProt == RTSP_RTP_MULTICAST) {
					/* disable the loopback function */
					if(SockOptLoopback(Media->Sock, NET_SOCK_LOOP_OFF) == NET_ERROR) {
						/* fail of disabling loopback socket option */
						RTCPHostMsg1("<CreateRTCPHostSockets>: fail to disable loopback sockopt\n");
						CloseRTCPSockets(Conf);
						return RTCP_ERR;
					}
					/* add RTP Server's Multicast address to socket's 
					 * multicast membership */
					if(SockOptMembershipAdd(Media->Sock, \
											Conf->HostIP, \
											Conf->SrvIP) == NET_ERROR) {
						/* fail of adding server's Mcast IP to socket membership */
						RTCPHostMsg1("<CreateRTCPHostSockets>: fail to add membership %s:%s\n", \
								Conf->HostIP, Conf->SrvIP);
						CloseRTCPSockets(Conf);
						return RTCP_ERR;
					}
				}
			} else { 
				/* fail to create a UDP socket, close all RTCP sockets and 
				 * return error */
				CloseRTCPSockets(Conf);
				return RTCP_ERR;
			}
		} /* else => This media is not available */
	}
	return RTCP_OK;
}

void InitRTCPHostConf(RTSP_HOST_CONF *Rtsp, RTCP_HOST_CONF *Rtcp) {
	int i = 0;

	/* Initialize the RTCP host state */
	Rtcp->State = RTCP_HOST_STATE_INIT;
	/* set the RTPProt (RTP streaming protocol */
	Rtcp->RTPProt = Rtsp->RTPProt;
	/* set the Server IP */
	if(Rtcp->RTPProt == RTSP_RTP_UDP) strcpy(Rtcp->SrvIP, Rtsp->SrvIP);
	else                              strcpy(Rtcp->SrvIP, Rtsp->SrvMcastIP);
	strcpy(Rtcp->HostIP, Rtsp->HostIP);
	/* setup the Media configuration in RTCP */
	for(i = 0 ; i < 2 ; i ++) {
		Rtcp->Media[i].Sock = 0;
		/* RTCP Ports */
		Rtcp->Media[i].SrvPort  = Rtsp->Info.Media[i].RTCPSrvPort;
		Rtcp->Media[i].HostPort = Rtsp->Info.Media[i].RTCPHostPort;
		/* SSRC */
		Rtcp->Media[i].SrvSSRC  = 0;
		Rtcp->Media[i].HostSSRC = (unsigned int)RTSPGetRandomNum();
		/* Timers */
		Rtcp->Media[i].Data.SRTimer    = (time_t) 0;
		Rtcp->Media[i].Data.SRInterval = MIN_SR_INTERVAL;
		Rtcp->Media[i].Data.RRTimer    = (time_t) 0;
		Rtcp->Media[i].Data.RRInterval = MIN_RR_INTERVAL/2;
		/* Statics */
		Rtcp->Media[i].Data.SRPkts  = 0;
		Rtcp->Media[i].Data.SRBytes = 0;
		Rtcp->Media[i].Data.RRPkts  = 0;
		Rtcp->Media[i].Data.RRBytes = 0;
	}
	return;
}

int RTCPHostHandler(RTCP_HOST_CONF *Conf) {
	struct timeval Tout;
	time_t         Tnow;
	fd_set         RxFd;
	int            MaxFd = 0;
	int            n     = 0;
	int            i     = 0;

	/* Setup the polling timer to probe the Socket buffer to see if there
	 * is RTCP packets from server */
	Tout.tv_sec  = 0;
	Tout.tv_usec = 500*1000; /* 500 msec */
	FD_ZERO(&RxFd);
	MaxFd = 0;
	/* register the valid RTCP socket to rx_fd */
	for(i = 0 ; i < 2 ; i ++) {
		if(Conf->Media[i].Sock) {
			if(Conf->Media[i].Sock > MaxFd) MaxFd = Conf->Media[i].Sock;
			FD_SET(Conf->Media[i].Sock, &RxFd);
		}
	}	
	n = select(MaxFd+1, &RxFd, (fd_set *)0, (fd_set *)0, &Tout);
	if(n > 0) {
		for(i = 0 ; i < 2 ; i ++) {
			if((Conf->Media[i].Sock) && (FD_ISSET(Conf->Media[i].Sock, &RxFd))) {
				/* there is a packet in the socket buffer, process it now */
				RTCPHostPktHandler(&Conf->Media[i]);
			}
		}
	} else if(n < 0) return RTCP_ERR;
	/* check if I need to send the RTCP RR packet to the derver or not */
	time(&Tnow);
	for(i = 0 ; i < 2 ; i ++) {
		if(IsRRTimerExpired(&Conf->Media[i].Data, Tnow)) 
			RTCPSendRRPkt(Conf, &Conf->Media[i]);
	}
	return RTCP_OK;	
}

void RTCPSendByePkt(RTCP_HOST_CONF *Conf) {
	RTCP_BYE_PKT       Pkt;
	int                Len = sizeof(Pkt);
	struct sockaddr_in Addr;
	int                i = 0;
	RTCP_MEDIA         *Media;

	for(i = 0 ; i < 2 ; i ++) {
		Media = &Conf->Media[i];
		/* build the RTCP BYE Packet */
		if(Media->SrvSSRC) {
			/* RR Packet */
			Pkt.Head.Cnt     = 1;
			Pkt.Head.Pad     = 0;
			Pkt.Head.Ver     = 2;
			Pkt.Head.PT      = RTCP_PT_RR;
			Pkt.Head.Len     = htons(7);
			Pkt.SSRC         = htonl(Media->HostSSRC);
			Pkt.RR.SSRC      = htonl(Media->SrvSSRC);
			Pkt.RR.TotalLost = 0;
			Pkt.RR.FractLost = 0;
			Pkt.RR.LastSeq   = htons(Media->Seq);
			Pkt.RR.Jitter    = 0;
			Pkt.RR.LSR       = 0;
			Pkt.RR.DLSR      = 0;
			/* Bye packet */
			Pkt.ByeHead.Cnt = 1;
			Pkt.ByeHead.Pad = 0;
			Pkt.ByeHead.Ver = 2;
			Pkt.ByeHead.PT  = RTCP_PT_BYE;
			Pkt.ByeHead.Len = htons(1);
			Pkt.SSRCBye     = htonl(Media->HostSSRC);
			/* Setup the Address to send */
			memset((char *)&Addr, 0, sizeof(struct sockaddr_in));
			Addr.sin_family = AF_INET;
			Addr.sin_addr.s_addr = inet_addr(Conf->SrvIP);
			Addr.sin_port        = htons(Media->SrvPort);
			/* send the packet out */
			if(sendto(  Media->Sock, \
						(char *)&Pkt.Head, \
						Len, \
						0, \
						(struct sockaddr *) &Addr, \
						sizeof(struct sockaddr_in)) != Len) {
				RTCPHostMsg1("<RTCPSendByePkt>: fail to send BYE packet-%d\n", i);
			}
			else
			{
				RTCPHostMsg1("<RTCPSendByePkt>:Send BYE packet success-%d\n", i);
			}
		}
	}
	return;
}

void RTCPSeqNumUpdate(int Seq1, int Seq2, RTCP_HOST_CONF *Rtcp) {

	Rtcp->Media[0].Seq = Seq1;
	Rtcp->Media[1].Seq = Seq2;
	return;
}
			
/* #######################################################################
 * Static functions
 * ####################################################################### */
static void CloseRTCPSockets(RTCP_HOST_CONF *Conf) {
	int i = 0;

	for(i = 0 ; i < 2 ; i ++) {
		if(Conf->Media[i].Sock) {
			close(Conf->Media[i].Sock);
			Conf->Media[i].Sock = 0;
		}
	}
	return;
}

static int IsRRTimerExpired(RTCP_DATA *Data, time_t tnow) {
	int Interval = 0;

	/* Get the Current time */
	if(Data->RRTimer) {
		if(tnow >= Data->RRTimer) Interval = (int) (tnow - Data->RRTimer);
		else { /* over-round */
			Interval = Data->RRInterval;
		}
		if(Interval >= Data->RRInterval) {
			Data->RRTimer = tnow;
			return 1;
		}
	} else {
		Data->RRTimer = tnow;
		return 0;
	}
	return 0;
}

static int IsValidRTCPPkt(char *buf, int Len) {
	RTCP_HEADER *p;
	int         Total = 0;

	p = (RTCP_HEADER *) buf;
	/* All RTCP packets must be compound packets (RFC1889, section 6.1) */
	if(((ntohs(p->Comm.Len)+1)*4) == Len) {
		/* Not a compound packet */
		/*printf("<IsValidRTCPPkt>: error! not a compound packet\n");*/
		return RTCP_ERR;
	}
	/* Check the RTCP version, payload type and padding of the first in  */
	if( (p->Comm.PT != RTCP_PT_SR) && \
		(p->Comm.PT != RTCP_PT_RR)) {
		printf("<IsValidRTCPPkt>: header payload type error, %d\n", p->Comm.PT);
		return RTCP_ERR;
	}
	/* Check all following parts of the compund RTCP packet. The RTP version
	 * number must be 2, and the padding bit must be zero on all apart from
	 * the last packet. */
	do {
		if(p->Comm.Ver != 2) {
			printf("<IsValidRTCPPkt>: header version error %d\n", p->Comm.Ver);
			return RTCP_ERR;
		}
		if(p->Comm.Pad != 0) {
			printf("<IsValidRTCPPkt>: header pad error %d\n", p->Comm.Pad);
			return RTCP_ERR;
		}
		Total += (ntohs(p->Comm.Len) + 1) * 4;
		p  = (RTCP_HEADER *) &buf[Total];
	} while(Total < Len);
	if(Total != Len) {
		printf("<IsValidRTCPPkt>: header length error %d!=%d\n", Total, Len);
		return RTCP_ERR;
	}
	return RTCP_OK;
}

static void RTCPHostPktHandler(RTCP_MEDIA *Media) {
	char buf[2000];	/* the RTCP packet could not be fragmented */
	RTCP_HEADER *p;
	struct sockaddr_in Addr;
	socklen_t AddrLen = sizeof(struct sockaddr_in);
	int Len           = 0;
	int Total         = 0;

	Len = recvfrom(	Media->Sock, \
					buf, \
					sizeof(buf), \
					0, \
					(struct sockaddr *)&Addr, \
					&AddrLen);
	if(Len > 0) {
		/* check if it is a valid RTCP packet */
		if(IsValidRTCPPkt(buf, Len) == RTCP_OK) {
			/* Yes!! It is a valid RTCP packet, process it now */
			do {
				p = (RTCP_HEADER *) &buf[Total];
				/* Only Sender Report needs to be processed */
				switch(p->Comm.PT) {
					case RTCP_PT_SR: /* Sender Report Packet */
						RTCPSRHandler(p, Media);
						break;
					case RTCP_PT_RR: /* drop it */
						break;
					case RTCP_PT_SDES:
						break;
					case RTCP_PT_BYE:
						break;
					case RTCP_PT_APP:
						break;
				}
				Total += (ntohs(p->Comm.Len) + 1) * 4;
			} while(Total < Len);
		}
	}
	return;
}

static void RTCPSendRRPkt(RTCP_HOST_CONF *Conf, RTCP_MEDIA *Media) {
	RTCP_RR_PKT        Pkt;
	int                Len = sizeof(Pkt);
	struct sockaddr_in Addr;

	/* build the RTCP_RR Packet */
	if(Media->SrvSSRC) {
		/* RR Packet */
		Pkt.Head.Cnt     = 1;
		Pkt.Head.Pad     = 0;
		Pkt.Head.Ver     = 2;
		Pkt.Head.PT      = RTCP_PT_RR;
		Pkt.Head.Len     = htons(7);
		Pkt.SSRC         = htonl(Media->HostSSRC);
		Pkt.RR.SSRC      = htonl(Media->SrvSSRC);
		Pkt.RR.TotalLost = 0;
		Pkt.RR.FractLost = 0;
		Pkt.RR.LastSeq   = htons(Media->Seq);
		Pkt.RR.Jitter    = 0;
		Pkt.RR.LSR       = 0;
		Pkt.RR.DLSR      = 0;
		/* Sdes Packet */
		Pkt.SDESHead.Cnt = 1;
		Pkt.SDESHead.Pad = 0;
		Pkt.SDESHead.Ver = 2;
		Pkt.SDESHead.PT  = RTCP_PT_SDES;
		Pkt.SDESHead.Len = htons(2);
		Pkt.SSRCSdes     = htonl(Media->HostSSRC);
		Pkt.SdesType     = RTCP_SDES_CNAME;
		Pkt.SdesLen      = 1;
		Pkt.SdesData[0]  = 0x00;
		Pkt.SdesData[1]  = 0x00;
		
		/* Setup the Address to send */
		memset((char *)&Addr, 0, sizeof(struct sockaddr_in));
		Addr.sin_family = AF_INET;
		Addr.sin_addr.s_addr = inet_addr(Conf->SrvIP);
		Addr.sin_port        = htons(Media->SrvPort);
		/* send the packet out */
		if(sendto(	Media->Sock, \
					(char *)&Pkt.Head, \
					Len, \
					0, \
					(struct sockaddr *) &Addr, \
					sizeof(struct sockaddr_in)) != Len) {
			RTCPHostMsg1("<RTCPSendSRPkt>: fail to send RR packet\n");
		} else {
			/* update the RRInterval */
			if(Media->Data.RRInterval*2 <= MIN_RR_INTERVAL) Media->Data.RRInterval *= 2;
			RTCPHostMsg0("<RTCPSendSRPkt>: send RR packet\n");
		}
	}
	return;
}

static void RTCPSRHandler(RTCP_HEADER *p, RTCP_MEDIA *Media) {
	RTCP_SR *SRPkt;
	time_t  tnow;
	int     Interval = 0;

	SRPkt = &p->Head.SR.SRPkt;
	if((Media->SrvSSRC) && (Media->SrvSSRC == ntohl(SRPkt->SSRC))) {
		/* this is the RTCP SR to me!! update the SRTimer and SRInterval,
		 * get the currnet time in sec */
		time(&tnow);
		if(Media->Data.SRTimer) {
			if(tnow > Media->Data.SRTimer) 
				Interval = (int)(tnow - Media->Data.SRTimer);
			else {
				/* over-round */
				Media->Data.SRTimer = tnow;
				Interval = 0;
			}
			if(Interval > Media->Data.SRInterval) Media->Data.SRInterval = Interval;
		} else {
			Media->Data.SRTimer = tnow;
		}
		/* update the server statistics */
		Media->Data.SRPkts  = SRPkt->Pkts;
		Media->Data.SRBytes = SRPkt->Bytes;
		RTCPHostMsg0("<RTCPSRHandler>: Update SR. Interval=%d, SSRC=%u\n", \
				Media->Data.SRInterval, Media->SrvSSRC);
	}
	else 
	{
		RTCPHostMsg1("<RTCPSRHandler>: SSRC Error %u/%u\n", \
				Media->SrvSSRC, ntohl(SRPkt->SSRC));
	}
	return;
}
