#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <ctype.h>
#include <fcntl.h>
#include <unistd.h>
#include <sched.h>
#include <string.h>
#include <errno.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/termios.h>
#include <sys/time.h>
#include <arpa/inet.h>


//#include "utils.h"
#include "util_time.h"

/**************************************
	input:
		mode:1)WAIT_IN_FIRST_TIME, 2)DONT_WAIT_IN_FIRST_TIME
		timeout: time in ms
***************************************/
int timeout_setup(s_timeout_check *t_check, int mode, int timeout)
{
	t_check->firsttime=1;
	t_check->mode=mode;
	t_check->time_wait=timeout;
	return TIMEOUT_SUCCESS;
}

int timeout_reset(s_timeout_check *t_check)
{
	t_check->firsttime=1;
	return TIMEOUT_SUCCESS;
}

int timeout_check(s_timeout_check *t_check)
{
	if(t_check->firsttime==1)
	{
		gettimeofday(&t_check->start_time, NULL);
		t_check->firsttime=0;
		if(t_check->mode==DONT_WAIT_IN_FIRST_TIME)
		{
			return TIMEOUT_FIRST_TIME;
		}
	}
	else
	{
		gettimeofday(&t_check->now, NULL);
		if(timeout_time_passed(&t_check->start_time, &t_check->now)>t_check->time_wait)
		{
			//printf("<timeout_check>%d-%d\n", (int)t_check->start_time.tv_sec, (int)t_check->now.tv_sec);
			memcpy(&t_check->start_time, &t_check->now, sizeof(struct timeval));
			
			return TIMEOUT_TRUE;
		}
	}
	return TIMEOUT_FAULT;
}


long timeout_time_passed(struct timeval *time_from, struct timeval *time_to)
{
	long diff_sec, diff_usec;

	if(time_from->tv_sec <= time_to->tv_sec) /* sec not round  */
	{
		diff_sec = time_to->tv_sec - time_from->tv_sec;
	}else/* sec round  */
	{
		diff_sec = ((unsigned long)0-1) - time_from->tv_sec + time_to->tv_sec;
	}

	if(time_from->tv_usec <= time_to->tv_usec) 
	{
		diff_usec = time_to->tv_usec - time_from->tv_usec;
	}
	else
	{
		diff_sec--;
		diff_usec = 1000000+time_to->tv_usec - time_from->tv_usec;
	}
	
	

	return diff_sec*1000+diff_usec/1000; /* return time in ms */
}

