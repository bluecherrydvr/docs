#define MP4_SUCCESS		0
#define MP4_FAIL	-1

#define I_FRAME	0
#define P_FRAME	1
#define B_FRAME	2

typedef struct
{
	int     is_I;
	int     width;
	int     height;
	int     fps;
} MP4_STREAM_ATTR;

int MP4_read_header_01b6(char * buf);
void MP4_read_header_0120(char * buf, MP4_STREAM_ATTR *mps_stream_attr);
