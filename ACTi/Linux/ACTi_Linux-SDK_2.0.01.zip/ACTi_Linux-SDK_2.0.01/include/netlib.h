// vim: ts=4 sw=4
/* #######################################################################
 * netlib.h
 * ####################################################################### */

#define NETLIB_TIME_TICK     20*1000    /* in usec */

#define UDP_MDU              1472		/* in bytes */

#define NETLIB_SUCCESS       0
#define NETLIB_ERR_SOCKET    -1
#define NETLIB_ERR_BIND      -2
#define NETLIB_ERR_LISTEN    -3
#define NETLIB_ERR_ACCEPT    -4
#define NETLIB_ERR_CONNECT   -5
#define NETLIB_ERR_WRITE     -6
#define NETLIB_ERR_READ      -7
#define NETLIB_ERR_SET_OPT   -8
#define NETLIB_ERR_GET_OPT   -9
#define NETLIB_ERR_SET_TOS   -10

#define SOCKTYPE_TCP         1
#define SOCKTYPE_UDP         2

#define IPREC_PRIORITY       0x20
#define TOS_LOWDELAY         0x10|IPREC_PRIORITY
#define TOS_THROUGHPUT       0x08|IPREC_PRIORITY
#define TOS_RELIABILITY      0x04|IPREC_PRIORITY
#define TOS_LOWCOST          0x02|IPREC_PRIORITY
#define TOS_NORMAL           0x00

/* #######################################################################
 * definitions of the loopback setting used in the set_mcast_loopback().
 * ####################################################################### */
#define NETLIB_SOCKOPT_LOOP_ON    1
#define NETLIB_SOCKOPT_LOOP_OFF   0

#define NETLIB_SOCK_BLOCK_ON      1
#define NETLIB_SOCK_BLOCK_OFF     0

/* #######################################################################
 * functions in netlib.c 
 * ####################################################################### */
int  bind_socket(int, char *, int);
int connect_socket(int sock, char *ip, int port, int timeout);
int  create_udp_socket(int *);
int  create_tcp_socket(int *);
int  listen_socket(int, int);
int  read_udp_socket(int, char *, int, struct sockaddr_in *, unsigned long);
int  read_tcp_socket(int, char *, int, unsigned long);
int  set_broadcast_addr(int);
int  set_mcast_interface(int, char *);
int set_mcast_rcv_interface(int sock, char *mip);
int  set_mcast_loopback(int, int);
int  set_ttl(int, int);
int  set_reuse_addr(int);
int  set_socket_block_mode(int, int);
int  set_tos(int, int);
int set_rcvbuf(int sock, int buf_size);
int  wait_connect(int, int *, struct sockaddr_in *);
int  write_udp_socket(int, char *, int, struct sockaddr_in *, int);
int  write_tcp_socket(int, char *, int, unsigned long);
char *decode_netlib_err(int);
