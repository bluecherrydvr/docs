/**********************************************/
/********** Utiltty ******************************/ 
/**********************************************/
int __util_url_send(char *ip_addr, int port, char *url_out, char *url_in, int url_in_len);
int __util_get_value_by_name(char *Stream, char *Name, char *value, int value_buf_len);
int __util_init_stream(CONECT_OBJ* con);
int __util_init_control(CONECT_OBJ* con);
int __util_init_audioout(CONECT_OBJ* con);

/**********************************************/
/********** RTP Connection **********************/ 
/**********************************************/
#define MAX_VIDEO_FRAME	1024*512
#define MAX_AUDIO_FRAME	1024*2
void __rtp_init(void* arg);
void __rtp_config(CONECT_OBJ* con);
void *__rtp_rtcp_thread(void *arg);
void *__rtp_video_thread(void *arg);
void *__rtp_audio_thread(void *arg);
void __rtp_closeAllSockets(RTSP_HOST_CONF *Rtsp, RTP_HOST_CONF *Rtp, RTCP_HOST_CONF *Rtcp);
void __rtp_start(void* arg);
void __rtp_stop(void* arg);
void __rtp_destroy(void* arg);

/**********************************************/
/********** Control connection *******************/ 
/**********************************************/
int __control_connect(CONECT_OBJ* con);
int __control_live_check(CONECT_OBJ* con);
int __control_exit(CONECT_OBJ* con);
void *__control_thread(void *arg);

void __control_init(void* arg);
void __control_start(void* arg);
void __control_stop(void* arg);
void __control_destroy(void* arg);

/**********************************************/
/********** Stream connection ********************/ 
/**********************************************/
int __tcp3_connect(CONECT_OBJ* con);
void *__tcp3_thread(void *arg);
void __tcp3_init(void* arg);
void __tcp3_start(void* arg);
void __tcp3_stop(void* arg);
void __tcp3_destroy(void* arg);

int __mul_connect(CONECT_OBJ* con);
void *__mul_thread(void *arg);
void __mul_init(void* arg);
void __mul_start(void* arg);
void __mul_stop(void* arg);
void __mul_destroy(void* arg);

/**********************************************/
/********** Audio out connection ******************/ 
/**********************************************/
int __audioout_connect(CONECT_OBJ* con);
void *__audioout_thread(void *arg);
void __audioout_init(void* arg);
void __audioout_start(void* arg);
void __audioout_stop(void* arg);
void __audioout_destroy(void* arg);

/**********************************************/
/********** Error CallBack ***********************/ 
/**********************************************/
#define ERR_CALLBACK(maj, min, con)\
	if(con->callback_err!=NULL)\
		con->callback_err(maj, min, con)

