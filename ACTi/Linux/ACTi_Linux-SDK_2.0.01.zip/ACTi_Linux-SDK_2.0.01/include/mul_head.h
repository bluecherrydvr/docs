
/*old MCAST_HeAD*/
#if 0
typedef struct {
	unsigned char id;				/* Not used */
	unsigned char sub_id;    		/* 0 -- video , 1 -- audio */
	unsigned char last;      			/* 1: last packet of a frame. 0: otherwise */
	unsigned char packets;   		/* total fragmanted UDP packets in a frame. This is
								   only valid if only if the last = 1. The value is
								   undefined if the last is 0 */
	unsigned char seq;       		/* sequence number in the fragmented UDP frames and
								   started from 1 */
	unsigned char checksum;		/* XOR of whole raw data of frame. That's 
								   XOR(Video B2 frame + MPEG4 Video Frame) */
	unsigned char fpsmode_res;	/* only for TCP1.0 where bit[7:4]:fps mode and 
								   bit[3:0] resolution index.
								   for TCP2.0, this value is undefined */
	unsigned char fps_num;		/* only for TCP1.0 where bit[7:0]:fps number 
								   corresponding to the fps mode.
								   for TCP2.0, this value is undefined. */
	unsigned int  frame_num; 		/* frame counter, increased by 1. the video and audio
								   has its own counter. */
	unsigned int  frame_len; 		/* length of payload in a fragmented UDP packet. The
								   Multicast Header is NOT included. */
} MCAST_HEAD;

#define MCAST_HEAD_LEN      sizeof(MCAST_HEAD)
#endif

/*New MCAST_HEAD update 2007/09/28*/

/* #######################################################################
 * mcast.h
 * created by MingYoung. date: 2006/07/19
 * Description:
 *    header file of the mcast.c
 * ####################################################################### */

/* #######################################################################
 * Multicast Video/Audio UDP framing rules in Video Server
 * 1. These rules will be applied to all kinds of video servers and camera
 * 2. Because the max length of Audio data is shorted than MAX UDP packet,
 *    it does not need to fragment Audio frame.
 * 3. The Raw data in a video frame is Video B2 frame + MPEG4 video frame
 * 4. The checksum = XOR(Video Raw Data).
 * 5. The Raw data in a video frame will be fragmented into serval UDP
 *    packets. The Multicast header will be added in the front of every
 *    fragmented UDP packet.
 * |======================================================================|
 * |      Video B2 Frame + Video Frame                                    |
 * |======================================================================|
 *              ||                         \\                        \\
 * |===========================|  |===============================| ...
 * | Mcast Head + Fragment UDP |  | Mcast Header + Fragmented UDP | ...
 * |===========================|  |===============================| ...
 *
 * 6. In the receiver, it has to count the "seq" in Mcast header to know
 *    if there is any fragmented UDP packet missed.
 *    Assembly all received fragmented UDP packets when it received the
 *    last fragmented UDP packet where the "last" is set and the "packets"
 *    matches total received fragmented UDP packet.
 *    The frame_len is used to help to check if the reception of every
 *    fragmented UDP packet is correct.
 * ####################################################################### */

#define MAX_MCAST_MTU             1472  /* bytes */
#define ETHER_MTU				1500 /* bytes */

/* To send the Video and Audio Frames over the Multicast UDP socket, the frame needs
 * to be fragmented into several UDP packets if the frame length is longer than the
 * IP's MTU (say 1500). To help the host to process the received fragmented Video/
 * Audio packet, it inserts a Multicast Header into every head of fragmented packet.
 * Therefore, the max raw video/audio data in the fragmented UDP packet is defined
 * in MAX_MCAST_MTU.*/

/* ##### definitions of sub_id in MCAST_HEAD */
#define MCAST_HEAD_SUBID_VIDEO    0
#define MCAST_HEAD_SUBID_AUDIO    1
/* ##### definitions of last in MCAST_HEAD */
#define MCAST_HEAD_LAST_PKT       1
#define MCAST_HEAD_NOT_LAST_PKT   0
typedef struct {
	unsigned char  id;          /* Not used */
	unsigned char  sub_id;      /* 0 -- video , 1 -- audio */
	unsigned char  last;        /* 1: last packet of a frame. 0: otherwise */
	unsigned char  checksum;    /* XOR of whole raw data of frame. That's
								   XOR(Video B2 frame + MPEG4 Video Frame), Not used! */
	unsigned short seq;         /* sequence number in the fragmented UDP frames and
	                               started from 1 */
	unsigned char  fpsmode_res; /* only for TCP1.0 where bit[7:4]:fps mode and
	                               bit[3:0] resolution index.
	                               for TCP2.0, this value is undefined */
	unsigned char fps_num;      /* only for TCP1.0 where bit[7:0]:fps number
	                               corresponding to the fps mode.
	                               for TCP2.0, this value is undefined. */
	unsigned int  frame_num;    /* frame counter, increased by 1. the video and audio
	                               has its own counter. */
	unsigned int  frame_len;    /* length of video or audio frame includeing the B2. 
								   The Multicast Header is NOT included. */
} MCAST_HEAD;

#define MCAST_HEAD_LEN      sizeof(MCAST_HEAD)
