/* #######################################################################
 * header.h
 *    Definied header 
 * ####################################################################### */

/* #######################################################################
 * B2 FRAME HEADER
 * ####################################################################### */
/* definitions of msg in B2_HEADER */
#define B2_VIDEO_MPEG4				0x01
#define B2_AUDIO_8KPCM       		0x02
/* TODO!! TEMP WORK!!! */
#define B2_AUDIO_TS_8KPCM          0x02
#define B2_VIDEO_MJPEG				0x04
#define B2_VIDEO_H264				0x05
/* RS485 used in the control session */
#define CTRL_SERIAL_RECV_REQ   	0x00000035	/* not used */
#define CTRL_SERIAL_RECV_RSP   	0x00010035
#define CTRL_SERIAL_SEND_REQ   	0x00000036
#define CTRL_SERIAL_SEND_RSP   	0x00010036	/* not used */
/* AUDIO_IN used in the control session */
#define CTRL_AUDIO_PLAY_REQ    	0x00000037
#define CTRL_AUDIO_PLAY_RSP    	0x00010037	/* not used */
/* VIDEO LOSS used in the control session */
#define CTRL_VIDEO_LOSS_REQ    	0x00000038	/* not used */
#define CTRL_VIDEO_LOSS_RSP    	0x00010038
/* MOTION used in the control session */
#define CTRL_MOTION_DETECT_REQ 	0x00000039	/* not used */
#define CTRL_MOTION_DETECT_RSP 	0x00010039
/* CAMERA NAME in the control session */
#define CTRL_CAMERA_NAME_REQ        0x00000040
#define CTRL_CAMERA_NAME_RSP        0x00010040

typedef struct {
	unsigned char head[4];  /* 00 00 01 B2 */
	unsigned char msg_type;
	unsigned char stream_id;
	unsigned char ext_b2_len;
	unsigned char rsvd;
	unsigned int  len;
} B2_HEADER;
#define B2_HEADER_LEN					sizeof(B2_HEADER)

typedef struct {
	unsigned char head[4];  /* A C T i */
	unsigned int  msg_type;
	unsigned int  len;
} HANDSHAKE_HEADER;
#define HANDSHAKE_HEADER_LEN					sizeof(HANDSHAKE_HEADER)

/* #######################################################################
 * PRIVATE DATA IN VIDEO B2 FRAME
 * ####################################################################### */
/* ##### definitions of video_loss in VIDEO_PRIVATE_DATA ##### */
#define B2_VIDEO_LOSS_NOT_FOUND     	1 /* video ok */
#define B2_VIDEO_LOSS_FOUND         	0 /* video loss */
typedef struct {
	time_t         date_time;   /* timestamp in sec of encoded this video frame */
	unsigned char  time_zone;   /* mapping the TIME_ZONE in conf file. 0:-12, ..., 24:+13 */
	unsigned char  video_loss;  /* 0: video loss, 1 : video ok */
	unsigned char  motion;      /* bit[3]:motion region 3, bit[2]:motion region 2, 
								   bit[1]:motion region 1. "1" means motion occurs */
	unsigned char  dio;			/* bit[1]:DI2, bit[0]:DI1. DI pins level */
	unsigned int   count;		/* video frame counter */
	unsigned char  resolution;  /* mapping the VIDEO_RESOLUTION in cond file. 0:N720x480, ... */
	unsigned char  bitrate;     /* mapping the VIDEO_BITRATE in cond file. 0:28K, ... */
	unsigned char  fps_mode;    /* mapping the VIDEO_FPS in cond file. 0:MODE1(constant), 1:0:MODE2 */
	unsigned char  fps_number;  /* in constant FPS mode, it indicates the video server's constant
								   FPS number, i.e. atoi(VIDEO_FPS_NUM).
								   in variable FPS mode, in indicates the variable FPS number which
								   was requested by the TCP host. If it is not in TCP, it indicates
								   the variable FPS number, i.e. atoi(VIDEO_VARIABLE_FPS) */
	struct timeval timestamp;	/* timestamp in usec of encoded this video frame */
	unsigned char  reserved[8]; /* not used */
} VIDEO_PRIVATE_DATA;
#define VIDEO_PRIVATE_DATA_LEN			sizeof(VIDEO_PRIVATE_DATA)

/* #######################################################################
 * PRIVATE DATA IN AUDIO B2 FRAME
 * ####################################################################### */
typedef struct {
	struct timeval timestamp;
	unsigned char  reserved[8];
} AUDIO_PRIVATE_DATA;
#define AUDIO_PRIVATE_DATA_LEN          sizeof(AUDIO_PRIVATE_DATA)

/* #######################################################################
 * VIDEO B2 FRAME
 * NOTE:
 * In here, lt looks like the video B2 frame is fixed length. But, in
 * runtime, it could be variable length. The ext_b2_len in header has to
 * be checked to know if there is extended data appended to the b2 frame
 * ####################################################################### */
typedef struct {
	B2_HEADER          header; /* len in header = VIDEO_PRIVATE_DATA_LEN
								  no matter the ext_b2_len value */
	VIDEO_PRIVATE_DATA prdata;
} VIDEO_B2_FRAME;
#define VIDEO_B2_FRAME_LEN				sizeof(VIDEO_B2_FRAME)

/* #######################################################################
 * AUDIO B2 FRAME (FIXED length)
 * ####################################################################### */
typedef struct {
	B2_HEADER          header;	/* len = AUDIO_PRIVATE_DATA_LEN+data len */
	AUDIO_PRIVATE_DATA prdata;
} AUDIO_B2_FRAME;
#define AUDIO_B2_FRAME_LEN              sizeof(AUDIO_B2_FRAME)

/* #######################################################################
 * #######################################################################
 * FRAMES in TCP SESSION
 * #######################################################################
 * ####################################################################### */
/* #######################################################################
 * TCP AUTHENTICATION REQUEST FRAME 
 * ####################################################################### */
/* ##### definitions in encrypt_type in TCP_AUTHEN_REQ ##### */
#define PWD_ENCRYPTED_NONE				0
#define PWD_ENCRYPTED_BASE64			1
typedef struct {
	unsigned char  name[32];     /* user name in plain text format */
	unsigned char  rsvd[28];     /* not used */
	unsigned short stream_id;    /* platform-T only */
	unsigned short encrypt_type; /* password encryption type */
	unsigned char  pwd[64];      /* user password. might be enctrpted */
} TCP_AUTHEN_REQ;
#define TCP_AUTHEN_REQ_LEN				sizeof(TCP_AUTHEN_REQ)
/* #######################################################################
 * TCP AUTHENTICATION RESPONSE FRAME
 * ####################################################################### */
#define TCP_AUTHEN_SUCCESS              0x00
#define TCP_AUTHEN_ERROR                0x01
typedef struct {
	unsigned char  status;    /* status code of authentication process */
	unsigned char  rsvd[1];   /* not used */
	unsigned short stream_id; /* same as the stream_id in TCP_AUTHEN_REQ */
	int            sock;      /* socket file descriptior of this session */
	char           camera_name[120]; /* camera name (max. 31 characters) */
} TCP_AUTHEN_RSP;
#define TCP_AUTHEN_RSP_LEN				sizeof(TCP_AUTHEN_RSP)

/* #######################################################################
 * TCP MESSAGE FRAME
 * ####################################################################### */
/* ##### definitions in msg_type in header in TCP_MSG ##### */
/* ##### VARIABLE FPS ##### */
#define ACTI_TCP_VARIABLE_FPS_REQ		0x00000020
#define ACTI_TCP_VARIABLE_FPS_RSP       0x00010020
/* ##### PAUSE ##### */
#define ACTI_TCP_VARIABLE_PAUSE_REQ		0x00000021
#define ACTI_TCP_VARIABLE_PAUSE_RSP		0x00010021
/* #######################################################################
 * Definitions of appended data (1 byte) in TCP VARIABLE FPS MESAGE FRAME 
 * the number of fps 
 * ####################################################################### */
/* #######################################################################
 * Definitions of appended data (1 byte) in TCP PAUSE MESAGE FRAME
 * ####################################################################### */
#define ACTI_TCP_PAUSE_OFF              0
#define ACTI_TCP_PAUSE_ON				1

/* #######################################################################
 * #######################################################################
 * FRAMES in CTRL SESSION
 * #######################################################################
 * ####################################################################### */
/* #######################################################################
 * CTRL AUTHENTICATION REQUEST FRAMES
 * ####################################################################### */
/* ##### definitions in token in CTRL_AUTHEN_REQ ##### */
#define TOKEN_UNKNOWN_REQ				0x00
#define TOKEN_CTRL_REQ					0x01
#define TOKEN_AUDIO_REQ					0x02
typedef struct {
	char           name[32];     /* user name in plain text format */
	int            token;
	char           rsvd[24];     /* not used */
	unsigned short stream_id;    /* same definition as it in TCP_AUTHEN_REQ*/
	unsigned short encrypt_type; /* same definition as it in TCP_AUTHEN_REQ */
	char           pwd[64];      /* same definition as it in TCP_AUTHEN_REQ */
} CTRL_AUTHEN_REQ;
#define CTRL_AUTHEN_REQ_LEN   			sizeof(CTRL_AUTHEN_REQ)
/* #######################################################################
 * CTRL AUTHENTICATION RESPONSE FRAMES
 * ####################################################################### */
/* ##### definitions in the result in CTRL_RSP_HEADER ##### */
#define CTRL_RSP_OK                		0x00
#define CTRL_RSP_ERR               		0x01
/* ##### definitions in the err_code in CTRL_RSP_HEADER ##### */
#define ERR_NO_ERROR					0x00000000
#define ERR_ACCOUNT						0x00010001
#define ERR_UNKNOWN_TOKEN				0x00010002
#define ERR_CTRL_TOKEN_BUSY				0x00010003
#define ERR_AUDIO_TOKEN_BUSY			0x00010004
#define ERR_AUDIO_NOT_SUPPORT			0x00010005
typedef struct {
	char         result;
	char         rsvd1[3]; /* not used */
	int          err_code;
	unsigned int ip_addr; /* ip address of the audio token owner when the token
						     in CTRL_AUTHEN_REQ is TOKEN_AUDIO_REQ */
	char         rsvd2[116];
} CTRL_AUTHEN_RSP;
#define CTRL_AUTHEN_RSP_LEN   			sizeof(CTRL_AUTHEN_RSP)

/* #######################################################################
 * CTRL MESSAGE FRAME
 * definitions in msg_type in header in CTRL MESSAGE FRAME 
 * ####################################################################### */
/* ##### LIVE CHECK #####*/
#define CTRL_LIVE_REQ              0x00000030
#define CTRL_LIVE_RSP              0x00010030  /* not used */
#define CTRL_EXIT_REQ              0x00000031
#define CTRL_EXIT_RSP              0x00010031  /* not used */
/* ##### DIOs ##### */
#define CTRL_DIO_OUT_REQ           0x00000032
#define CTRL_DIO_OUT_RSP           0x00010032  /* not used*/
#define CTRL_DIO_STATUS_REQ        0x00000033
#define CTRL_DIO_STATUS_RSP        0x00010033
#define CTRL_DIO_INPUT_REQ         0x00000034  /* not used */
#define CTRL_DIO_INPUT_RSP         0x00010034
/* ##### RS485 ##### */
#define CTRL_SERIAL_RECV_REQ       0x00000035  /* not used */
#define CTRL_SERIAL_RECV_RSP       0x00010035
#define CTRL_SERIAL_SEND_REQ       0x00000036
#define CTRL_SERIAL_SEND_RSP       0x00010036  /* not used */
/* ##### AUDIO ##### */
#define CTRL_AUDIO_PLAY_REQ        0x00000037
#define CTRL_AUDIO_PLAY_RSP        0x00010037  /* not used */
/* ##### VIDEO LOSS ##### */
#define CTRL_VIDEO_LOSS_REQ        0x00000038  /* not used */
#define CTRL_VIDEO_LOSS_RSP        0x00010038
/* ##### MOTION ##### */
#define CTRL_MOTION_DETECT_REQ     0x00000039  /* not used */
#define CTRL_MOTION_DETECT_RSP     0x00010039
/* ##### CAMERA NAME ##### */
#define CTRL_CAMERA_NAME_REQ        0x00000040
#define CTRL_CAMERA_NAME_RSP        0x00010040
/* #######################################################################
 * There are two types of CTRL MESSAGES:
 * 1. HANDSHAKE_HEADER only frame. There is no extra information in the frame.
 *    just only to decode the header to know how to response it. 
 *    The CTRL frame in this type is
 *    - CTRL_LIVE_REQ, 
 *    - CTRL_EXIT_REQ, 
 *    - CTRL_DIO_STATUS_REQ
 *    - CTRL_CAMERA_NAME_REQ
 * 2. HANDSHAKE_HEADER with parameters. There is parameter data appended to the
 *    header. The len in header will address the length of appended data
 *    The CTRL frame in this type is
 *    - CTRL_DIO_OUT_REQ
 *    - CTRL_DIO_STATUS_RSP
 *    - CTRL_DIO_INPUT_RSP
 *    - CTRL_SERIAL_RECV_RSP
 *    - CTRL_SERIAL_SEND_REQ
 *    - CTRL_AUDIO_PLAY_REQ
 *    - CTRL_VIDEO_LOSS_RSP
 *    - CTRL_MOTION_DETECT_RSP
 *    - CTRL_CAMERA_NAME_RSP
 * #######################################################################
 * The definitions in appended data (1 byte) in CTRL DIO MESSAGE FRAME is
 * bit[4]:DO2, bit[3]:DO1, bit[1]:DI2, bit[0]:DI1. The "1" in these bits
 * is the high level in the corresponding DIO pins.
 * #######################################################################
 * The definitions in appended data (1 byte) in CTRL VIDEO LOSS MESSAGE 
 * FRAME is the same as the video_loss in VIDEO_PRIVATE_DATA where 
 * 0: video loss, 1 : video ok
 * #######################################################################
 * The definitions in appended data (1 byte) in CTRL MOTION MESSAGE FRAME 
 * is the same as the motion in VIDEO_PRIVATE_DATA where 
 * bit[3]:motion region 3, bit[2]:motion region 2, bit[1]:motion region 1
 * The "1" in these bits tells the motion in corresponding region occurs
 * ####################################################################### */
