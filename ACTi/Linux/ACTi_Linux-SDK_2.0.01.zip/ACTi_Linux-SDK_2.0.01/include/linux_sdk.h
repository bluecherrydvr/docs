#include "NetRtsp.h"
#include "NetRtcp.h"
#include "NetRtp.h"
#include "NetAccess.h"

#define VERSON	"2.01.00"

#define LS_SUCCESS 			0
#define LS_FAIL 				-1
#define LS_ERR_URL_SEND	-2
#define LS_BUFFER_FULL		-3

#define MAX_FRAME_SIZE	1024*256

#define AUDIO_OUT_PKG_LEN	1024*4	/*This should NOT be changed!*/

#define DEFAULT_TIME_OUT	1500	/*1000 ms*/
#define DEFAULT_MUL_RCVBUF	MAX_FRAME_SIZE*10

#define STATUS_NULL				0
#define STATUS_CONNECTING		1
#define STATUS_CONNECTED		2
#define STATUS_CLOSING			3
#define STATUS_CLOSED			4

#define STATE_NULL				0x01
#define STATE_CONNECTING		0x02
#define STATE_CONNECTED		0x04
#define STATE_CLOSING			0x08
#define STATE_CLOSED			0x10

/**********************************************
*	Multicast priv data
***********************************************/
typedef struct
{
	pthread_t thread_id;
	int status;			
	int sockfd;
	int time_out; 		/*Time out for socket access. The unit is ms, Default value is DEFAULT_TIME_OUT*/
	int rcvbuf;			/*Socket buffer size. The default value is DEFAULT_MUL_RCVBUF*/
	char *frame_buf;
	int frame_buf_len;
}MUL_PRIV;
#define MUL_PRIV_LEN sizeof(MUL_PRIV)

/**********************************************
*	TCP3.0 priv data
***********************************************/
typedef struct
{
	pthread_t thread_id;
	int sockfd;
	int url_id;			/*Url ID from video server.*/
	int time_out; 		/*Time out for socket access. The unit is ms, Default value is DEFAULT_TIME_OUT*/
}TCP3_PRIV;
#define TCP3_PRIV_LEN sizeof(TCP3_PRIV)

/**********************************************
*	RTP priv data
***********************************************/
typedef struct
{
	pthread_t rtcp_thread_id;
	pthread_t video_thread_id;
	pthread_t audio_thread_id;
	int rtcp_thread_state;
	int video_thread_state;
	int audio_thread_state;
	RTSP_HOST_CONF rtsp_host_conf;
	RTCP_HOST_CONF rtcp_host_conf;
	RTP_HOST_CONF rtp_host_conf;
	int time_out; 		/*Time out for socket access. The unit is ms, Default value is DEFAULT_TIME_OUT*/

}RTP_PRIV;
#define RTP_PRIV_LEN sizeof(RTP_PRIV)

/**********************************************
*	Audio Out priv data
***********************************************/
typedef struct
{
	pthread_t thread_id;
	int sockfd;
	int status;			
	int time_out; 		/*Time out for socket access. The unit is ms, Default value is DEFAULT_TIME_OUT*/
}AUDIOOUT_PRIV;
 #define AUDIOOUT_PRIV_LEN sizeof(CONTROL_PRIV)

/**********************************************
*	Control priv data
***********************************************/
typedef struct
{
	pthread_t thread_id;
	int sockfd;
	int status;			
	int time_out; 		/*Time out for socket access. The unit is ms, Default value is DEFAULT_TIME_OUT*/
}CONTROL_PRIV;
 #define CONTROL_PRIV_LEN sizeof(CONTROL_PRIV)

/**********************************************
*	Thread data
***********************************************/
typedef struct
 {
 	int status;
	void (* init)(void *argv);
	void (* start)(void *argv);
	void (* stop)(void *argv);
	void (* destroy)(void *argv);
	void *priv;
 }THREAD_T;

/**********************************************
*	Connection data
***********************************************/
#define STREAMING_METHOD_TCP 				0
#define STREAMING_METHOD_MULTICAST		1
#define STREAMING_METHOD_TCP_MUL			2
#define STREAMING_METHOD_RTP_UDP			3
#define STREAMING_METHOD_RTP_MUL			4
#define STREAMING_METHOD_RTP_UDP_MUL	5
typedef struct
{
	unsigned int seq;
	/*Configs*/
	char WAN_IP[16];  			/*IP of video server*/
	char V2_MULTICAST_IP[16];	/*Muticast IP of video server*/
	int PORT_HTTP;				/*HTTP Port of video server*/
	int PORT_VIDEO;				/*Video Stream Port of video server*/
	int PORT_CONTROL;			/*Control Connection Port of video server*/
	int PORT_MULTICAST;			/*Multicast Stream Port of video server*/
	int V2_PORT_RTSP;			/*RTP Port of video server*/
	char user_name[32];			/*User Name of video server*/
	char password[64];			/*Password of video server*/
	int V2_STREAMING_METHOD;	/*(0:TCP Only,(1:Multicast Only, 2:TCP&Multicast,(3:RTP Over UDP,(4:RTP Over Multicast,(5:RTP Over UDP & Multicast*/
	int V2_AUDIO_ENABLED; 		/*0)Disable, 1)Enable*/
	int VIDEO_VARFPS;			/*Variable frame rate*/
	int SOURCE_TYPE; 			/*0)Video Server 1)Quad Video Server 2)Multi-Channel Video Server*/
	int QUAD_CHANNEL;			/*Channel of Quad Video Server*/
	int multi_channel;			/*Channel of Multi-Channel Video Server*/

	char camera_name[32];

	/*Local Config*/
	char Local_WAN_IP[16]; 		/*Local WAN ip address*/
	char Local_LAN_IP[16];  		/*Local LAN ip address*/
	
	/*User priv data*/
	void *priv;

	/*Thread control*/
	THREAD_T stream_thread;
	THREAD_T control_thread;
	THREAD_T audio_out_thread;

	/*Call Backs*/
	void (* callback_video)(VIDEO_B2_FRAME *video_b2, void *arg);
	void (* callback_audio)(AUDIO_B2_FRAME *audio_b2, void *arg);
	void (* callback_control)(HANDSHAKE_HEADER *handshake_header, void *arg);
	void (* callback_stream_connected)(void *arg);
	void (* callback_audioout_connected)(void *arg);
	void (* callback_control_connected)(void *arg);
	void (* callback_err)(int err_maj, int err_min, void *arg);
}CONECT_OBJ;
#define CONECT_OBJ_LEN sizeof(CONECT_OBJ)

/**********************************************/
/********** Stream connection ********************/ 
/**********************************************/
int stream_set_video_callback(CONECT_OBJ* con, void *callback);
int stream_set_audio_callback(CONECT_OBJ* con, void *callback);
int stream_set_connected_callback(CONECT_OBJ* con, void *callback);

int stream_start(CONECT_OBJ* con);
int stream_stop(CONECT_OBJ* con);

/**********************************************/
/********** Control connection *******************/ 
/**********************************************/
#define LS_DI1 0x01
#define LS_DI2 0x02
#define LS_DO1 0x04
#define LS_DO2 0x08
#define LS_DIO_SHORT	1 /*I/O ping be shorted*/
#define LS_DIO_OPEN		0 /*I/O ping be opened*/

int control_set_callback(CONECT_OBJ* con, void *callback);
int contro_set_connected_callback(CONECT_OBJ* con, void *callback);

int control_start(CONECT_OBJ* con);
int control_stop(CONECT_OBJ* con);

int inline control_is_connected(CONECT_OBJ* con);
int control_serial_send(CONECT_OBJ* con, char *buf, int len);
int conrol_DIO_send(CONECT_OBJ* con, int di1, int di2);

/**********************************************/
/********** Audio out connection ******************/ 
/**********************************************/
int audioout_set_connected_callback(CONECT_OBJ* con, void *callback);
int audioout_start(CONECT_OBJ* con);
int audioout_stop(CONECT_OBJ* con);
int audioout_send(CONECT_OBJ* con, char *buf, int len);
int inline audioout_is_connected(CONECT_OBJ* con);

/**********************************************/
/********** Utiltty ******************************/ 
/**********************************************/
#define CONFIG_VALUE_LEN	128
#define URL_IN_BUF_SIZE	1024*4
#define URL_OUT_BUF_SIZE	256

int util_url_command(CONECT_OBJ *con, char *cmd_maj, char *cmd_min, char *return_value, int return_value_len);
int util_url_get_setting(CONECT_OBJ *con, char *cmd_maj, char *cmd_min, char *return_value, int return_value_len);
int util_get_server_info(CONECT_OBJ *con);
CONECT_OBJ* util_creat_connect_obj(void);
int util_init_connect_obj(CONECT_OBJ* con);
int util_destroy_connect_obj(CONECT_OBJ* con);
int util_set_error_callback(CONECT_OBJ* con, void *callback);

int util_set_priv_data(CONECT_OBJ* con, void *priv);

/**********************************************/
/********** Error code **************************/ 
/**********************************************/
#define LS_ERR_TCP3			-1
#define LS_ERR_MUL			-2
#define LS_ERR_RTP			-3
#define LS_ERR_CTRL			-4
#define LS_ERR_URL			-5
#define LS_ERR_AUDIOOUT	-6

#define LS_ERR_AUDIOOUT_CONNECT	-1		 /*<__audioout_thread>__audioout_connect FAIL!*/
#define LS_ERR_AUDIOOUT_LEN		-2 		 /*<audioout_send>Audio out data length MUST be 4096 bytes!*/
#define LS_ERR_AUDIOOUT_NOCONNECTION -3 	/*<audioout_send>Audio out didn't connect.*/
#define LS_ERR_AUDIOOUT_SEND1 	-4 		/*<audioout_send>Audio out header send FAIL!*/
#define LS_ERR_AUDIOOUT_SEND2 	-5 		/*<audioout_send>Audio out data send FAIL!*/

#define LS_ERR_CTRL_SOCKET			-1 		/*<__control_connect>create_tcp_socket FAIL*/
#define LS_ERR_CTRL_CONNECT		-2		/*<__control_connect> Can't connect */
#define LS_ERR_CTRL_AUTHEN_REQ	-3 		/*<__control_connect> Can't send CTRL_AUTHEN_REQ */
#define LS_ERR_CTRL_AUTHEN_RSP	-4		/*<__control_connect> Can't read CTRL_AUTHEN_RSP */
#define LS_ERR_CTRL_RSP_ERR		-5		/*<__control_connect>CTRL_RSP_ERR */
#define LS_ERR_CTRL_LIVE_REQ		-6		/*<__control_live_check> Can't send CTRL_LIVE_REQ */
#define LS_ERR_CTRL_EXIT_REQ		-7		/*<__control_exit> Can't send CTRL_EXIT_REQ */

#define LS_ERR_CTRL_READ_HEADER	-8		/*<__control_thread>read HANDSHAKE_HEADER FAIL! */
#define LS_ERR_CTRL_READ_DATA		-9		/*<__control_thread>read ACTI_DATA FAIL! */

#define LS_ERR_TCP3_SOCKET			-1		/*<__tcp3_connect>create_tcp_socket FAIL */
#define LS_ERR_TCP3_CONNECT		-2		/*<__tcp3_connect> Can't connect */
#define LS_ERR_TCP3_AUTHEN_REQ	-3		/*<__tcp3_connect> Can't send CTRL_AUTHEN_REQ */
#define LS_ERR_TCP3_AUTHEN_RSP	-4		/*<__tcp3_connect> Can't read CTRL_AUTHEN_RSP */
#define LS_ERR_TCP3_RSP_ERR		-5		/*<__tcp3_connect>TCP3_RSP_ERR */

#define LS_ERR_TCP3_READ_B2		-6		/*<__tcp3_thread>read b2_header FAIL! */
#define LS_ERR_TCP3_CHECK_B2		-7		/*<__tcp3_thread>check b2_header FAIL! */
#define LS_ERR_TCP3_READ_DATA		-8		/*<__tcp3_thread>read b2 payload FAIL! */

#define LS_ERR_RTP_CONNECT			-1		/*<__rtp_start> __rtp_connect FAIL*/
#define LS_ERR_RTP_RTCP_THREAD	-2		/*<__rtp_start>Creat __rtp_rtcp_thread FAIL*/
#define LS_ERR_RTP_VIDEO_THREAD	-3		/*<__rtp_start>Creat __rtp_video_thread FAIL*/
#define LS_ERR_RTP_AUDIO_THREAD	-4		/*<__rtp_start>Creat __rtp_audio_thread FAIL*/

#define LS_ERR_MUL_SOCKET			-1		/*<__mul_connect>create_tcp_socket FAIL */
#define LS_ERR_MUL_CONNECT		-2		/*<__mul_connect>bind_socket FAIL */
#define LS_ERR_MUL_INTERFACE		-3		/*<__mul_connect>set_mcast_interface FAIL */
#define LS_ERR_MUL_SET_BUF			-4		/*<__mul_connect>set_rcvbuf FAIL */

#define LS_ERR_MUL_RECEIVE			-5		/*<__mul_get_frame>read_udp_socket FAIL */
#define LS_ERR_MUL_DATA_LEN_1		-6		/*<__mul_get_frame>data length error-1! */
#define LS_ERR_MUL_DATA_LEN_2		-7		/*<__mul_get_frame>data length error-2! */


