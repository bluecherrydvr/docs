// vim: ts=4 sw=4
/* #######################################################################
 * NetAccess.h
 * Created by MingYoung   Date:2007/0410
 * Description:
 *    Header file for NetAccess Library. Refer to Libs/Src/NetAccess.c
 * ####################################################################### */
#define NET_SUCCESS       0
#define NET_ERROR         -1

#define NET_TIME_TICK     20000   /* 20000 usec */

#define NET_SOCK_BLOCK    0
#define NET_SOCK_NONBLOCK 1

#define NET_SOCK_LOOP_OFF 0
#define NET_SOCK_LOOP_ON  1

/* #######################################################################
 * Public APIs from NetAccess.c
 * ####################################################################### */
int  BindSocket(int, char *, int);
void CloseSocket(int *);
int  Connect2Server(int, struct sockaddr_in *, int);
int  CreateTCPSocket(int *);
int  CreateUDPSocket(int *);
int  ReadSockTCP(int, char *, int *, unsigned long);
int  ReadSockUDP(int, char *, int *, struct sockaddr_in *, int);
int  SetSockBlockMode(int, int);
int  SockOptMembershipAdd(int, char *, char *);
int  SockOptLoopback(int, unsigned char);
int  SockOptReusedAddrSet(int);
int  WriteSockTCP(int, char *, int, unsigned long);
