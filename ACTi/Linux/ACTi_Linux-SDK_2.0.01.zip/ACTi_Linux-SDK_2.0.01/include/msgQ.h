//###########################
//##	Struct of message
//###########################
typedef struct st_message{
	long int msg_typ;

	int index;
	void *priv;
	char name[32];
	char value[512];
}s_message;

typedef struct
{
	long int my_msg_type;
	char some_text[512];
}s_SED3300_msg;
	
#define	S_MESSAGE_LEN	sizeof(s_message)-sizeof(long int)

#define MSG_SUCCESS	0
#define MSG_FAIL		-1

//###########################
//##	Message types
//###########################
#define	MSG_VIDEO				01
#define	MSG_AUDIO				02
#define	MSG_STOP_CONTROL		03
#define	MSG_STOP_AUDIOOUT	04

//###########################
//##	Message IDs
//###########################
int	id_msg2mainloop;
int	id_msg2audioplay;
int	id_msg2audioout;
int	id_msg2rs485;

int	id_msg2mainloop_sed3300;

int 	id_msg2watchdog;

//###########################
//##	Message IDs
//###########################
#define	key_msg2mainloop	6533
#define	key_msg2audioplay	6534
#define	key_msg2audioout	6535
#define	key_msg2rs485		6536

#define	key_msg2mainloop_sed3300	7948

#define	key_msg2watchdog	3300

//###########################
//##	receive mode
//###########################
#define BOLCK		1
#define NONBOLCK	0

//###########################
//##	command to mainloop
//###########################
//command should put to s_message.index
#define STOP 					1


int messageQ_create(int *msgid, int msgkey);
int messageQ_len(int msgid);
int messageQ_clean(int msgid);
int messageQ_send(int msgid, void *message);
int messageQ_receve(int msgid, void *message, int block);

