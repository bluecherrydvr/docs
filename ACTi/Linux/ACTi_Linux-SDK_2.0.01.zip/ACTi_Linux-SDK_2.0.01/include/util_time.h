/* Time out check struct*/
typedef struct
{
	struct timeval start_time;
	struct timeval now;
	int firsttime;
	int mode;

	long time_wait;			/*how long you can wait in ms*/
}s_timeout_check;
#define	WAIT_IN_FIRST_TIME			1
#define	DONT_WAIT_IN_FIRST_TIME		2

#define TIMEOUT_SUCCESS	2
#define TIMEOUT_TRUE		1
#define TIMEOUT_FAULT		0
#define TIMEOUT_FIRST_TIME	2

extern int		timeout_setup(s_timeout_check *t_check, int mode, int timeout);
extern int 	timeout_reset(s_timeout_check *t_check);
extern int		timeout_check(s_timeout_check *t_check);
extern long 	timeout_time_passed(struct timeval *time_from, struct timeval *time_to);
