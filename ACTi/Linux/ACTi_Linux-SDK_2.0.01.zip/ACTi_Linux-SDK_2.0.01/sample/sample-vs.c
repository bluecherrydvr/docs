#include "common.h"
#include "header.h"
#include "linux_sdk.h"
#include "netlib.h"
#include "msgQ.h"

#define SUCCESS	0
#define FAIL		-1

#define MAX_CLIENTS		20
int s_sockfd=FAIL;
int c_sockfd[MAX_CLIENTS];

int server_status=FAIL;

void stream_video_callback(VIDEO_B2_FRAME* video_b2_frame, void *arg)
{
	CONECT_OBJ *con=(CONECT_OBJ *)arg;
	char *raw_data;
	int raw_data_len;
	
	raw_data=(char *)video_b2_frame+VIDEO_B2_FRAME_LEN;
	raw_data_len=video_b2_frame->header.len-VIDEO_PRIVATE_DATA_LEN;

	printf("<stream_video_callback>con->seq=%d, MPEG4--0x%x, len=%d\n", con->seq, raw_data[3], raw_data_len);
}

void stream_audio_callback(AUDIO_B2_FRAME* audio_b2_frame, void *arg)
{
	CONECT_OBJ *con=(CONECT_OBJ *)arg;
	char *raw_data;
	int raw_data_len;
	
	raw_data=(char *)audio_b2_frame+AUDIO_B2_FRAME_LEN;
	raw_data_len=audio_b2_frame->header.len-AUDIO_PRIVATE_DATA_LEN;

	printf("<stream_audio_callback>con->seq=%d, len=%d\n", con->seq, raw_data_len);
}

void control_callback(HANDSHAKE_HEADER *handshake_header, void *arg)
{
	struct timeval now;
	gettimeofday(&now, NULL);
	printf("%d-%d-%c%c%c%c ", (int)now.tv_sec, (int)now.tv_usec, handshake_header->head[0], handshake_header->head[1], handshake_header->head[2], handshake_header->head[3]);
	if(handshake_header->msg_type==CTRL_MOTION_DETECT_RSP)
		printf("<control_callback>CTRL_MOTION_DETECT_RSP\n");
	else if(handshake_header->msg_type==CTRL_DIO_INPUT_RSP)
		printf("<control_callback>CTRL_DIO_INPUT_RSP\n");
	else
	{
		printf("<control_callback>handshake_header->msg_type=0x%x\n", handshake_header->msg_type);
	}
}

void error_callback(int err_maj, int err_min, void *arg)
{
	printf("<error_callback>err_maj-%d, err_min-%d\n", err_maj, err_min);
}

int main(void)
{
	CONECT_OBJ *connect_1;
	s_message message;
	
	printf("Linux SDk %s Test AP - Video Camera\n", VERSON);

	messageQ_create(&id_msg2mainloop, key_msg2mainloop);
	
	/*Creat connect obj*/
	connect_1=util_creat_connect_obj();
	

	/*Setup callback functions.*/
	util_set_error_callback(connect_1, &error_callback);
	stream_set_video_callback(connect_1, &stream_video_callback);
	stream_set_audio_callback(connect_1, &stream_audio_callback);
	control_set_callback(connect_1, &control_callback);

	/*Config connect obj*/
	strcpy(connect_1->WAN_IP, "172.16.3.59");
	connect_1->PORT_HTTP=80;
	strcpy(connect_1->user_name, "Admin");
	strcpy(connect_1->password, "123456");	
	if(util_get_server_info(connect_1)==LS_SUCCESS)
	{
		printf("Multicast IP : %s\n", connect_1->V2_MULTICAST_IP);
		printf("Port of Video : %d\n", connect_1->PORT_VIDEO);
		printf("Port of Control : %d\n", connect_1->PORT_CONTROL);
		printf("Port of Muticast : %d\n", connect_1->PORT_MULTICAST);
		printf("Port of RTSP : %d\n", connect_1->V2_PORT_RTSP);
		printf("Streaming Method : %d\n", connect_1->V2_STREAMING_METHOD);
		printf("Audio Enabled : %d\n", connect_1->V2_AUDIO_ENABLED);
		

		/*Init connect obj*/
		if(util_init_connect_obj(connect_1)==LS_FAIL)
		{
			printf("<main>util_init_connect_obj FAIL!\n");
			return 0;
		}

		/*Start threads*/
		stream_start(connect_1);
		control_start(connect_1);

		/*Main loop*/
		printf("<Main Loop>start!\n");
		while(1)
		{
			if(messageQ_receve(id_msg2mainloop, &message, NONBOLCK)==MSG_SUCCESS)
			{
				printf("<Main Loop>Receive message, %s\n", message.name);
				break;
			}
			usleep(500*1000);
		}
		printf("<Main Loop>stop!\n");
		
		/*Stop threads*/
		stream_stop(connect_1);
		control_stop(connect_1);

		/*Destroy connect obj*/
		if(util_destroy_connect_obj(connect_1)==LS_FAIL)
			printf("<main>util_destroy_connect_obj FAIL!");
	}
	else
	{
		printf("<main>util_get_server_info FAIL!\n");
	}

	printf("Linux SDk %s Test AP EXIT\n", VERSON);
	return 0;
}
