#include "common.h"
#include "msgQ.h"

int main(void)
{
	s_message message;
	
	messageQ_create(&id_msg2mainloop, key_msg2mainloop);

	message.msg_typ=1;
	message.index=STOP;
	sprintf(message.name, "Stop Main Loop!\n");
	messageQ_send(id_msg2mainloop, &message);
	return 0;
}
