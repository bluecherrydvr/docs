#include "common.h"
#include "header.h"
#include "linux_sdk.h"
#include "netlib.h"
#include "msgQ.h"

int main(void)
{
	CONECT_OBJ *connect_1;

	char buf[256];
	
	printf("Linux SDk %s Test AP - URL Command\n", VERSON);

	messageQ_create(&id_msg2mainloop, key_msg2mainloop);
	
	/*Creat connect obj*/
	connect_1=util_creat_connect_obj();

	/*Config connect obj*/
	strcpy(connect_1->WAN_IP, "172.16.3.59");
	connect_1->PORT_HTTP=80;
	strcpy(connect_1->user_name, "Admin");
	strcpy(connect_1->password, "123456");	

	util_url_command(connect_1, "system", "SYSTEM_INFO", buf, 256);
	printf("%s\n", buf);

	util_url_get_setting(connect_1, "system", "V2_MULTICAST_IP", buf, 256);
	printf("%s\n", buf);
	
	if(util_get_server_info(connect_1)==LS_SUCCESS)
	{
		printf("Multicast IP : %s\n", connect_1->V2_MULTICAST_IP);
		printf("Port of Video : %d\n", connect_1->PORT_VIDEO);
		printf("Port of Control : %d\n", connect_1->PORT_CONTROL);
		printf("Port of Muticast : %d\n", connect_1->PORT_MULTICAST);
		printf("Port of RTSP : %d\n", connect_1->V2_PORT_RTSP);
		printf("Streaming Method : %d\n", connect_1->V2_STREAMING_METHOD);
		printf("Audio Enabled : %d\n", connect_1->V2_AUDIO_ENABLED);
	}

	/*Destroy connect obj*/
	if(util_destroy_connect_obj(connect_1)==LS_FAIL)
		printf("<main>util_destroy_connect_obj FAIL!");
	
	printf("Linux SDk %s Test AP EXIT-URL Command\n", VERSON);
	return 0;
}


