#include "common.h"
#include "header.h"
#include "linux_sdk.h"
#include "netlib.h"
#include "msgQ.h"

#define SUCCESS	0
#define FAIL		-1

void *control_thread(void *arg)
{
	CONECT_OBJ *con=(CONECT_OBJ *)arg;
	int flip=0;
	
	printf("<control_thread-%d>\n", con->seq);
	while(1)
	{
		usleep(1000*1000);
		printf("<control_thread>send serial data: ABCDEFG\n");
		control_serial_send(con, "ABCDEFG", 7);
		
		if(flip==0)
		{
			conrol_DIO_send(con, LS_DIO_SHORT, LS_DIO_OPEN);
			flip=1;
		}
		else
		{
			conrol_DIO_send(con, LS_DIO_OPEN, LS_DIO_SHORT);
			flip=0;
		}
	}

	pthread_detach(pthread_self());
	pthread_exit(NULL);
}

void control_callback(HANDSHAKE_HEADER *handshake_header, void *arg)
{
	char buf[128];

	if(handshake_header->msg_type==CTRL_MOTION_DETECT_RSP)
	{
		printf("<control_callback>CTRL_MOTION_DETECT_RSP\n");
	}
	else if(handshake_header->msg_type==CTRL_DIO_INPUT_RSP)
	{
		printf("<control_callback>CTRL_DIO_INPUT_RSP\n");
	}
	else if(handshake_header->msg_type==CTRL_SERIAL_RECV_RSP)
	{
		memcpy(buf, (char *)handshake_header+HANDSHAKE_HEADER_LEN, handshake_header->len);
		buf[handshake_header->len]='\0';
		printf("<control_callback>ACTI_CTRL_SERIAL_RECV_RSP\n");
		printf("<control_callback>Serial data: %s\n", buf);
	}
	else
	{
		printf("<control_callback>handshake_header->msg_type=0x%x\n", handshake_header->msg_type);
	}
}

void error_callback(int err_maj, int err_min, void *arg)
{
	CONECT_OBJ *con=(CONECT_OBJ *)arg;
	printf("<error_callback-%d>err_maj-%d, err_min-%d\n", con->seq, err_maj, err_min);
}

void control_connected_callback(void *arg)
{
	pthread_t thread_id;
	
	CONECT_OBJ *con=(CONECT_OBJ *)arg;
	printf("<control_connected_callback-%d>\n", con->seq);
	pthread_create(&thread_id, NULL, control_thread, (void *)con);
}

int main(void)
{
	CONECT_OBJ *connect_1;
	s_message message;
	char buf[256];
	printf("Linux SDk %s Test AP - Control\n", VERSON);

	messageQ_create(&id_msg2mainloop, key_msg2mainloop);
	
	/*Creat connect obj*/
	connect_1=util_creat_connect_obj();
	

	/*Setup callback functions.*/
	util_set_error_callback(connect_1, &error_callback);
	control_set_callback(connect_1, &control_callback);
	contro_set_connected_callback(connect_1, &control_connected_callback);

	/*Config connect obj*/
	strcpy(connect_1->WAN_IP, "172.16.3.59");
	connect_1->PORT_HTTP=80;
	strcpy(connect_1->user_name, "Admin");
	strcpy(connect_1->password, "123456");	

	util_url_command(connect_1, "system", "SYSTEM_INFO", buf, 256);
	printf("%s\n", buf);
	
	connect_1->multi_channel=4;/*Setup quad channel*/
	
	if(util_get_server_info(connect_1)==LS_SUCCESS)
	{
		printf("Multicast IP : %s\n", connect_1->V2_MULTICAST_IP);
		printf("Port of Video : %d\n", connect_1->PORT_VIDEO);
		printf("Port of Control : %d\n", connect_1->PORT_CONTROL);
		printf("Port of Muticast : %d\n", connect_1->PORT_MULTICAST);
		printf("Port of RTSP : %d\n", connect_1->V2_PORT_RTSP);
		printf("Streaming Method : %d\n", connect_1->V2_STREAMING_METHOD);
		printf("Audio Enabled : %d\n", connect_1->V2_AUDIO_ENABLED);
		

		/*Init connect obj*/
		if(util_init_connect_obj(connect_1)==LS_FAIL)
		{
			printf("<main>util_init_connect_obj FAIL!\n");
			return 0;
		}

		/*Start threads*/
		control_start(connect_1);

		/*Main loop*/
		printf("<Main Loop>start!\n");
		while(1)
		{
			if(messageQ_receve(id_msg2mainloop, &message, NONBOLCK)==MSG_SUCCESS)
			{
				printf("<Main Loop>Receive message, %s\n", message.name);
				break;
			}
			usleep(500*1000);
		}
		printf("<Main Loop>stop!\n");
		
		/*Stop threads*/
		control_stop(connect_1);

		/*Destroy connect obj*/
		if(util_destroy_connect_obj(connect_1)==LS_FAIL)
			printf("<main>util_destroy_connect_obj FAIL!");
	}
	else
	{
		printf("<main>util_get_server_info FAIL!\n");
	}

	
	
	printf("Linux SDk %s Test AP EXIT\n", VERSON);
	return 0;
}




