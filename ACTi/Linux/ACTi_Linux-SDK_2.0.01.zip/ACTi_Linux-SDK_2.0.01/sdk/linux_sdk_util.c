
#include "common.h"
#include "header.h"
#include "linux_sdk.h"
#include "__linux_sdk.h"
#include "mul_head.h"
#include "netlib.h"
#include "util_time.h"

#define destroy_wait_time	10

unsigned int seq_count=0;

void printbuf(unsigned char *buf,unsigned int len_print);/*todo: remove this line before release*/

/**********************************************/
/********** Utiltty ******************************/ 
/**********************************************/
int __util_url_send(char *ip_addr, int port, char *url_out, char *url_in, int url_in_len)
{
	int socketfd;
	char buf[256];
	int rc;

	if(create_tcp_socket(&socketfd)==NETLIB_ERR_SOCKET)
	{
		printf("err <URL_send> Can't creat socket.\n");
		return LS_ERR_URL_SEND;
	}

	set_socket_block_mode(socketfd, NETLIB_SOCK_BLOCK_ON);
	
	if(connect_socket(socketfd, ip_addr, port, DEFAULT_TIME_OUT)==NETLIB_ERR_CONNECT)
	{
		printf("err <URL_send> Can't connect to %s.\n", ip_addr);
		close(socketfd);
		return LS_ERR_URL_SEND;
	}

	sprintf(buf, "%s%s%s\r\n%s\r\n%s%s\r\n%s\r\n\r\n", "GET ", url_out, " HTTP/1.1", "Accept: */*", "Host: ", ip_addr, "Connection: Keep-Alive");
	//printf("%s\n", buf);
	rc=write_tcp_socket(socketfd, buf, strlen(buf), 0);
	if(rc==NETLIB_ERR_WRITE)
	{
		printf("err <URL_send> Can't write to server.\n");
		close(socketfd);
		return LS_ERR_URL_SEND;
	}

	rc=read_tcp_socket(socketfd, url_in, url_in_len, 1000);
	if(rc==url_in_len)
	{
		printf("err <URL_send> Buffer is full\n");
		return LS_BUFFER_FULL;
	}
	
	close(socketfd);
	return LS_SUCCESS;
}

int __util_get_value_by_name(char *Stream, char *Name, char *value, int value_buf_len)
{
	int Stream_len=strlen(Stream);
	int Name_len=strlen(Name);
	int Value_len;
	char *pLeft, *pRight ;
	int i=0;
	int j=0;

	//printf("Namd: %s, Stream_len=%d, Name_len=%d\n", Name, Stream_len, Name_len);
	for(i=0;i<Stream_len;i++)
	{
		for(j=0;j<Name_len;j++)
		{
			if(Stream[i+j]!=Name[j])
				break;
		}
		//printf("%d\n", j);
		if(j==(Name_len))
		{
			pLeft = strchr( Stream+i+j, '\'' )+1;
			pRight = strchr( pLeft, '\'' );
			Value_len=pRight-pLeft;
			if(Value_len > (value_buf_len-1))
			{
				printf("err <__util_get_value_by_name>buf is not enough!");
				return LS_FAIL;
			}
			memcpy(value, pLeft, Value_len);
			value[Value_len]='\0';
			
			return LS_SUCCESS;
		}
	}
	
	return LS_FAIL;
}

int __util_init_stream(CONECT_OBJ* con)
{
	THREAD_T *thread=&con->stream_thread;

	switch(con->V2_STREAMING_METHOD)
	{
		case STREAMING_METHOD_TCP:
			thread->init=&__tcp3_init;
			thread->init(con);
			break;
		case STREAMING_METHOD_MULTICAST:
			thread->init=&__mul_init;
			thread->init(con);
			break;
		case STREAMING_METHOD_TCP_MUL:
			printf("<__util_init_stream>STREAMING_METHOD_TCP_MUL not support.\n");
			return LS_FAIL;
			break;
		case STREAMING_METHOD_RTP_UDP:
			thread->init=&__rtp_init;
			thread->init(con);
			return LS_FAIL;
			break;
		case STREAMING_METHOD_RTP_MUL:
			printf("<__util_init_stream>STREAMING_METHOD_RTP_MUL not support.\n");
			return LS_FAIL;
			break;
		case STREAMING_METHOD_RTP_UDP_MUL:
			printf("<__util_init_stream>STREAMING_METHOD_RTP_UDP_MUL not support.\n");
			return LS_FAIL;
			break;
		default :
			printf("<__util_init_stream>Unknow streaming method %d\n", con->V2_STREAMING_METHOD);
			return LS_FAIL;
		
	}
	return LS_SUCCESS;
}

int __util_init_control(CONECT_OBJ* con)
{
	THREAD_T *thread=&con->control_thread;
	
	thread->init=&__control_init;
	thread->init((void *)con);
	return LS_SUCCESS;
}

int __util_init_audioout(CONECT_OBJ* con)
{
	THREAD_T *thread=&con->audio_out_thread;
	
	thread->init=&__audioout_init;
	thread->init((void *)con);
	return LS_SUCCESS;
}

void *__util_get_cameraname_thread(void *arg)
{
	CONECT_OBJ * con=(CONECT_OBJ *)arg;
	
	#define BUF_SIZE 64
	char url_out[URL_OUT_BUF_SIZE];
	char url_in[URL_IN_BUF_SIZE];
	char buf[BUF_SIZE];
	
	
	sprintf(url_out, "/cgi-bin/%s?USER=%s&PWD=%s&%s", "mpeg4",con->user_name, con->password, "VIDEO_CAMERA_NAME");
	//printf("%s\n", url_out);
	if(__util_url_send(con->WAN_IP, con->PORT_HTTP, url_out, url_in, URL_IN_BUF_SIZE)==LS_ERR_URL_SEND)
	{
		printf("err <util_get_server_info>URL_send FAiL!\n");
		ERR_CALLBACK(LS_ERR_URL, 0, con);
		goto __util_get_cameraname_thread_exit;
	}
	//printf("%s\n", url_in);

	if(__util_get_value_by_name(url_in, "VIDEO_CAMERA_NAME", buf, BUF_SIZE)==LS_FAIL)
	{
		printf("err <util_get_server_info>Can't get VIDEO_CAMERA_NAME!\n");
		ERR_CALLBACK(LS_ERR_URL, 0, con);
		goto __util_get_cameraname_thread_exit;
	}
	sprintf(con->camera_name, buf);

	__util_get_cameraname_thread_exit:
	pthread_detach(pthread_self());
	pthread_exit(NULL);
}

void __util_get_cameraname(CONECT_OBJ * con)
{
	pthread_t thread_id;
	pthread_create(&thread_id, NULL, __util_get_cameraname_thread, (void *)con);
	
}

int util_url_command(CONECT_OBJ *con, char *cmd_maj, char *cmd_min, char *return_value, int return_value_len)
{
	int rc;
	char command[128];

	sprintf(command, "/cgi-bin/%s?USER=%s&PWD=%s&%s", cmd_maj,con->user_name, con->password, cmd_min);
	//printf("%s\n", command);
	rc=__util_url_send(con->WAN_IP, con->PORT_HTTP, command, return_value, return_value_len);
	if(rc==LS_ERR_URL_SEND)
	{
		printf("err <util_url_command>URL_send FAiL!\n");
		return LS_FAIL;
	}else if(rc==LS_BUFFER_FULL)
	{
		printf("err <util_url_command>Buffer is FULL\n");
		return LS_BUFFER_FULL;
	}
	//printf("%s\n", return_value);

	return LS_SUCCESS;
}

int util_url_get_setting(CONECT_OBJ *con, char *cmd_maj, char *cmd_min, char *return_value, int return_value_len)
{
	char url_in[128];
	char command[128];

	sprintf(command, "/cgi-bin/%s?USER=%s&PWD=%s&%s", cmd_maj,con->user_name, con->password, cmd_min);
	//printf("%s\n", command);
	if(__util_url_send(con->WAN_IP, con->PORT_HTTP, command, url_in, 128)==LS_ERR_URL_SEND)
	{
		printf("err <util_url_get_setting>URL_send FAiL!\n");
		return LS_FAIL;
	}
	//printf("%s\n", url_in);

	if(return_value_len==0)
		return LS_SUCCESS;
	
	if(__util_get_value_by_name(url_in, cmd_min, return_value, return_value_len)==LS_FAIL)
	{
		printf("err <util_url_get_setting>Can't get %s!\n", cmd_min);
		return LS_FAIL;
	}
	return LS_SUCCESS;
}

int util_get_server_info(CONECT_OBJ *con)
{
	#define BUF_SIZE 64
	char url_out[URL_OUT_BUF_SIZE];
	char url_in[URL_IN_BUF_SIZE];
	char buf[BUF_SIZE];
	
	
	sprintf(url_out, "/cgi-bin/%s?USER=%s&PWD=%s&CHANNEL=%d&%s", "system",con->user_name, con->password, con->multi_channel, "&WAN_IP&V2_MULTICAST_IP&PORT_HTTP&PORT_VIDEO&PORT_CONTROL&PORT_MULTICAST&V2_PORT_RTSP&V2_STREAMING_METHOD&V2_AUDIO_ENABLED");
	//printf("%s\n", url_out);
	if(__util_url_send(con->WAN_IP, con->PORT_HTTP, url_out, url_in, URL_IN_BUF_SIZE)==LS_ERR_URL_SEND)
	{
		printf("err <util_get_server_info>URL_send FAiL!\n");
		ERR_CALLBACK(LS_ERR_URL, 0, con);
		return LS_FAIL;
	}
	//printf("%s\n", url_in);

	if(__util_get_value_by_name(url_in, "V2_MULTICAST_IP", buf, BUF_SIZE)==LS_FAIL)
	{
		printf("err <util_get_server_info>Can't get V2_MULTICAST_IP!\n");
		ERR_CALLBACK(LS_ERR_URL, 0, con);
		return LS_FAIL;
	}
	sprintf(con->V2_MULTICAST_IP, buf);

	if(__util_get_value_by_name(url_in, "PORT_VIDEO", buf, BUF_SIZE)==LS_FAIL)
	{
		printf("err <util_get_server_info>Can't get PORT_VIDEO!\n");
		ERR_CALLBACK(LS_ERR_URL, 0, con);
		return LS_FAIL;
	}
	con->PORT_VIDEO=atoi(buf);

	if(__util_get_value_by_name(url_in, "PORT_CONTROL", buf, BUF_SIZE)==LS_FAIL)
	{
		printf("err <util_get_server_info>Can't get PORT_CONTROL!\n");
		ERR_CALLBACK(LS_ERR_URL, 0, con);
		return LS_FAIL;
	}
	con->PORT_CONTROL=atoi(buf);

	if(__util_get_value_by_name(url_in, "PORT_MULTICAST", buf, BUF_SIZE)==LS_FAIL)
	{
		printf("err <util_get_server_info>Can't get PORT_MULTICAST!\n");
		ERR_CALLBACK(LS_ERR_URL, 0, con);
		return LS_FAIL;
	}
	con->PORT_MULTICAST=atoi(buf);

	if(__util_get_value_by_name(url_in, "V2_PORT_RTSP", buf, BUF_SIZE)==LS_FAIL)
	{
		printf("err <util_get_server_info>Can't get V2_PORT_RTSP!\n");
		ERR_CALLBACK(LS_ERR_URL, 0, con);
		return LS_FAIL;
	}
	con->V2_PORT_RTSP=atoi(buf);

	if(__util_get_value_by_name(url_in, "V2_STREAMING_METHOD", buf, BUF_SIZE)==LS_FAIL)
	{
		printf("err <util_get_server_info>Can't get V2_STREAMING_METHOD!\n");
		ERR_CALLBACK(LS_ERR_URL, 0, con);
		return LS_FAIL;
	}
	con->V2_STREAMING_METHOD=atoi(buf);
	
	if(__util_get_value_by_name(url_in, "V2_AUDIO_ENABLED", buf, BUF_SIZE)==LS_FAIL)
	{
		printf("err <util_get_server_info>Can't get V2_AUDIO_ENABLED!\n");
		ERR_CALLBACK(LS_ERR_URL, 0, con);
		return LS_FAIL;
	}
	con->V2_AUDIO_ENABLED=atoi(buf);
	
	return LS_SUCCESS;
}

CONECT_OBJ* util_creat_connect_obj(void)
{
	CONECT_OBJ *con;
	con=(CONECT_OBJ *)malloc(sizeof(CONECT_OBJ));
	memset(con, 0, sizeof(CONECT_OBJ));

	con->seq=seq_count++;

	con->QUAD_CHANNEL=0;
	con->multi_channel=1;

	con->priv=NULL;
	con->callback_video=NULL;
	con->callback_audio=NULL;
	con->callback_stream_connected=NULL;
	con->callback_control=NULL;
	con->callback_control_connected=NULL;
	con->callback_err=NULL;
	con->callback_audioout_connected=NULL;
	
	return con;
}

int util_init_connect_obj(CONECT_OBJ* con)
{
	__util_init_stream(con);
	__util_init_control(con);
	__util_init_audioout(con);
	return LS_SUCCESS;
}

int util_destroy_connect_obj(CONECT_OBJ* con)
{

	if(con->stream_thread.destroy!=NULL)
		con->stream_thread.destroy(con);
	
	if(con->control_thread.destroy!=NULL)
		con->control_thread.destroy(con);

	if(con!=NULL)
	{
		free(con);
		con=NULL;
	}
	
	printf("<util_destroy_connect_obj>\n");
	return LS_SUCCESS;
}

int util_set_error_callback(CONECT_OBJ* con, void *callback)
{
	con->callback_err=callback;
	//printf("<util_set_error_callback>\n");
	return LS_SUCCESS;
}

int util_set_priv_data(CONECT_OBJ* con, void *priv)
{
	con->priv=priv;
	return LS_SUCCESS;
}

/**********************************************/
/********** Control connection *******************/ 
/**********************************************/
int __control_connect(CONECT_OBJ* con)
{
	THREAD_T *thread=&con->control_thread;
	CONTROL_PRIV *priv = thread->priv;
	CTRL_AUTHEN_REQ auth_req;
	CTRL_AUTHEN_RSP auth_rsp;
	int rc;

	thread->status|=STATE_CONNECTING;
	
	if(create_tcp_socket(&priv->sockfd)==NETLIB_ERR_SOCKET)
	{
		printf("err <__control_connect>create_tcp_socket FAIL\n");
		priv->sockfd=LS_FAIL;
		return LS_ERR_CTRL_SOCKET;
	}

	set_socket_block_mode(priv->sockfd, NETLIB_SOCK_BLOCK_ON);
	
	if(connect_socket(priv->sockfd, con->WAN_IP, con->PORT_CONTROL, priv->time_out)==NETLIB_ERR_CONNECT)
	{
		printf("err <__control_connect> Can't connect to %s.\n", con->WAN_IP);
		close(priv->sockfd);
		priv->sockfd=LS_FAIL;
		return LS_ERR_CTRL_CONNECT;
	}

	sprintf(auth_req.name, con->user_name);
	sprintf(auth_req.pwd, con->password);
	auth_req.token=TOKEN_CTRL_REQ;
	if(write_tcp_socket(priv->sockfd, (char *)&auth_req, CTRL_AUTHEN_REQ_LEN, priv->time_out)==NETLIB_ERR_WRITE)
	{
		printf("err <__control_connect> Can't send CTRL_AUTHEN_REQ\n");
		close(priv->sockfd);
		priv->sockfd=LS_FAIL;
		return LS_ERR_CTRL_AUTHEN_REQ;
	}

	if((rc=read_tcp_socket(priv->sockfd, (char *)&auth_rsp, CTRL_AUTHEN_RSP_LEN, priv->time_out))==NETLIB_ERR_WRITE)
	{
		printf("err <__control_connect> Can't read CTRL_AUTHEN_RSP\n");
		close(priv->sockfd);
		priv->sockfd=LS_FAIL;
		return LS_ERR_CTRL_AUTHEN_RSP;
	}
	
	if(auth_rsp.result!=CTRL_RSP_OK)
	{
		printf("err <__control_connect>CTRL_RSP_ERR: %d\n", auth_rsp.err_code);
		close(priv->sockfd);
		priv->sockfd=LS_FAIL;
		return LS_ERR_CTRL_RSP_ERR;
	}

	thread->status|=STATE_CONNECTED;
	printf("<__control_connect>Connect Success!\n");
	return LS_SUCCESS;
}

int __control_live_check(CONECT_OBJ* con)
{
	THREAD_T *thread = &con->control_thread;
	CONTROL_PRIV *priv = thread->priv;
	HANDSHAKE_HEADER handshake_header;
	
	sprintf(handshake_header.head, "ACTi");
	handshake_header.msg_type=CTRL_LIVE_REQ;
	handshake_header.len=0;

	if(write_tcp_socket(priv->sockfd, (char *)&handshake_header, HANDSHAKE_HEADER_LEN, priv->time_out)==NETLIB_ERR_WRITE)
	{
		printf("err <__control_live_check> Can't send CTRL_LIVE_REQ\n");
		return LS_ERR_CTRL_LIVE_REQ;
	}
	//printf("<__control_live_check>CTRL_LIVE_REQ was send.\n");
	return LS_SUCCESS;
}

int __control_exit(CONECT_OBJ* con)
{
	THREAD_T *thread = &con->control_thread;
	CONTROL_PRIV *priv = thread->priv;
	
	HANDSHAKE_HEADER handshake_header;
	
	sprintf(handshake_header.head, "ACTi");
	handshake_header.msg_type=CTRL_EXIT_REQ;
	handshake_header.len=0;

	if(write_tcp_socket(priv->sockfd, (char *)&handshake_header, HANDSHAKE_HEADER_LEN, priv->time_out)==NETLIB_ERR_WRITE)
	{
		printf("err <__control_exit> Can't send CTRL_EXIT_REQ\n");
		return LS_ERR_CTRL_EXIT_REQ;
	}
	printf("<__control_exit>CTRL_EXIT_REQ was send.\n");
	return LS_SUCCESS;
}


void *__control_thread(void *arg)
{
	CONECT_OBJ * con=(CONECT_OBJ *)arg;
	THREAD_T *thread = &con->control_thread;
	CONTROL_PRIV *priv = thread->priv;
	int rc=0;
	s_timeout_check live_time_check;
	char *buf=NULL;
	char *buf_tmp=NULL;
	int buf_len=HANDSHAKE_HEADER_LEN;
	int bytesread=0;
	HANDSHAKE_HEADER *handshake_header;
	int error_maj=LS_SUCCESS;
	int error_min=LS_SUCCESS;
	
	printf("<__control_thread-%d>Start\n", con->seq);

	buf=malloc(buf_len);
	handshake_header=(HANDSHAKE_HEADER *)buf;
	
	if(priv->time_out==0)
		priv->time_out=DEFAULT_TIME_OUT;

	if((error_min=(__control_connect(con)))!=LS_SUCCESS)
	{
		printf("err <__control_thread>control_connect FAIL!\n");
		thread->stop(con);
	}
	else
	{
		if(con->callback_control_connected!=NULL)
			con->callback_control_connected(con);
	}
	
	timeout_setup(&live_time_check, WAIT_IN_FIRST_TIME, 25*1000);  /*Send live check every 25 s.*/

	while((thread->status&STATE_CLOSING)==0)/*check status*/
	{	
		/*send live check*/
		if(timeout_check(&live_time_check)==TIMEOUT_TRUE)
		{
			timeout_reset(&live_time_check);
			if((error_min=__control_live_check(con))!=LS_SUCCESS)
			{
				printf("err <__control_thread>control_live_check FAIL!\n");
				thread->stop(con);
				break;
			}
		}

		/*listen for control pkg*/
		memset(buf, 0, buf_len);
		handshake_header=(HANDSHAKE_HEADER *)buf;
		if((bytesread=read_tcp_socket(priv->sockfd, buf, HANDSHAKE_HEADER_LEN, 500))==NETLIB_ERR_READ)
		{
			printf("err <__control_thread>read HANDSHAKE_HEADER FAIL!\n");
			thread->stop(con);
			error_min=LS_ERR_CTRL_READ_HEADER;
			break;
		}
		else if(bytesread>0)
		{
			if((handshake_header->len+HANDSHAKE_HEADER_LEN)>buf_len)
			{
				buf_len=handshake_header->len+HANDSHAKE_HEADER_LEN;
				buf_tmp=(char *)malloc(buf_len);
				memcpy(buf_tmp, buf, HANDSHAKE_HEADER_LEN);
				free(buf);
				buf=buf_tmp;
				handshake_header=(HANDSHAKE_HEADER *)buf;
			}
			
			if(handshake_header->len>0)
			{
				if((bytesread=read_tcp_socket(priv->sockfd, buf+HANDSHAKE_HEADER_LEN, handshake_header->len, priv->time_out))==NETLIB_ERR_READ)
				{
					printf("err <__control_thread>read ACTI_DATA FAIL!\n");
					thread->stop(con);
					error_min=LS_ERR_CTRL_READ_DATA;
					break;
				}
			}
			
			if(con->callback_control!=NULL)
				con->callback_control(handshake_header, con);
			else
				printf("err <__control_thread>NO callback function!\n");
			
		}

		
		
	}
	
	if(priv->sockfd!=LS_FAIL)
	{
		rc=__control_exit(con);
		close(priv->sockfd);
		priv->sockfd=LS_FAIL;
	}

	if(buf!=NULL)
	{
		free(buf);
		buf=NULL;
	}

	if(error_min!=LS_SUCCESS)
	{
		error_maj=LS_ERR_CTRL;
		ERR_CALLBACK(error_maj, error_min, con);
	}
	
	printf("<__control_thread-%d>STATUS_CLOSED\n", con->seq);
	thread->status|=STATE_CLOSED;
	
	pthread_detach(pthread_self());
	pthread_exit(NULL);
}

void __control_init(void* arg)
{
	CONECT_OBJ *con=(CONECT_OBJ *)arg;
	THREAD_T *thread=&con->control_thread;
	CONTROL_PRIV *priv;
	
	//printf("<__control_init-%d>\n", con->seq);

	if(thread->priv!=NULL)
	{
		free(thread->priv);
		thread->priv=NULL;
	}
	
	priv=thread->priv=malloc(CONTROL_PRIV_LEN);
	priv->sockfd=LS_FAIL;
	priv->thread_id=LS_FAIL;
	priv->time_out=DEFAULT_TIME_OUT;

	thread->start=&__control_start;
	thread->stop=&__control_stop;
	thread->destroy=&__control_destroy;

	thread->status=STATE_NULL;
}

void __control_start(void* arg)
{
	CONECT_OBJ *con=(CONECT_OBJ *)arg;
	THREAD_T *thread = &con->control_thread;
	CONTROL_PRIV *priv = thread->priv;
	
	printf("<__control_start-%d>\n", con->seq);

	if (pthread_create(&priv->thread_id, NULL, __control_thread, (void *)con) < 0)
	{
            printf("err <__control_start>Creat control_thread FAIL\n");
            thread->stop(con);
        }
}

void __control_stop(void* arg)
{
	CONECT_OBJ *con=(CONECT_OBJ *)arg;
	THREAD_T *thread = &con->control_thread;
	CONTROL_PRIV *priv = thread->priv;

	thread->status|=STATE_CLOSING;

	if(priv->sockfd!=LS_FAIL)
		shutdown(priv->sockfd, 0);

	printf("<__control_stop-%d>STATUS_CLOSING\n", con->seq);

}

void __control_destroy(void* arg)
{
	CONECT_OBJ *con=(CONECT_OBJ *)arg;
	THREAD_T *thread = &con->control_thread;
	CONTROL_PRIV *priv = thread->priv;
	int count=0;
	
	if((thread->status&STATE_CONNECTING)==STATE_CONNECTING)
	{
		thread->stop(con);
		
		while((thread->status&STATE_CLOSED)==0)
		{
			printf("<__control_destroy>Waiting %d - %d\n", con->seq, thread->status);
			usleep(priv->time_out*1000);

			if(count++>destroy_wait_time) break;
		}
	}

	if(thread->priv!=NULL)
	{
		free(priv);
		priv=NULL;
	}

	printf("<__control_destroy-%d>finished\n", con->seq);
}

int control_set_callback(CONECT_OBJ* con, void *callback)
{
	con->callback_control=callback;
	return LS_SUCCESS;
}

int contro_set_connected_callback(CONECT_OBJ* con, void *callback)
{
	con->callback_control_connected=callback;
	return LS_SUCCESS;
}

int control_start(CONECT_OBJ* con)
{
	con->control_thread.start(con);
	return LS_SUCCESS;
}

int control_stop(CONECT_OBJ* con)
{
	con->control_thread.stop(con);
	return LS_SUCCESS;
}

int inline control_is_connected(CONECT_OBJ* con)
{
	if(
		(con->control_thread.status&STATE_CONNECTED)>0 &&
		(con->control_thread.status&STATE_CLOSING)==0
	)
		return 1;
	else
		return 0;
}

int control_serial_send(CONECT_OBJ* con, char *buf, int len)
{
	THREAD_T *thread = &con->control_thread;
	CONTROL_PRIV *priv = thread->priv;
	
	HANDSHAKE_HEADER *handshake_header;
	char *pkg;
	int pkg_len;

	if(con==NULL)
	{
		printf("err<control_serial_send>Connect obj is NULL\n");
		return LS_FAIL;
	}

	if(!control_is_connected(con))
	{
		printf("err<control_serial_send>Control connection is not connected.\n");
		return LS_FAIL;
	}
	
	pkg_len=HANDSHAKE_HEADER_LEN+len;
	pkg=(char *)malloc(pkg_len);
	handshake_header=(HANDSHAKE_HEADER *)pkg;

	sprintf(handshake_header->head, "ACTi");
	handshake_header->msg_type=CTRL_SERIAL_SEND_REQ;
	handshake_header->len=len;
	memcpy((char *)pkg+HANDSHAKE_HEADER_LEN, buf, len);

	if(write_tcp_socket(priv->sockfd, pkg, pkg_len, priv->time_out)==NETLIB_ERR_WRITE)
	{
		printf("<control_serial_send>write_tcp_socket FAIL\n");
		free(pkg);
		return LS_FAIL;
	}
	
	free(pkg);
	return LS_SUCCESS;
}

int conrol_DIO_send(CONECT_OBJ* con, int di1, int di2)
{
	THREAD_T *thread = &con->control_thread;
	CONTROL_PRIV *priv = thread->priv;
	
	HANDSHAKE_HEADER *handshake_header;
	char dio_stat=0x00;
	int pkg_len;
	char *pkg;
	
	if(con==NULL)
	{
		printf("err<conrol_DIO_send>Connect obj is NULL\n");
		return LS_FAIL;
	}

	if(!control_is_connected(con))
	{
		printf("err<conrol_DIO_send>Control connection is not connected.\n");
		return LS_FAIL;
	}

	if(di1==LS_DIO_SHORT)
		dio_stat&=~LS_DI1;
	else
		dio_stat|=LS_DI1;

	if(di2==LS_DIO_SHORT)
		dio_stat&=~LS_DI2;
	else
		dio_stat|=LS_DI2;
	
	pkg_len=HANDSHAKE_HEADER_LEN+1;
	pkg=(char *)malloc(pkg_len);
	handshake_header=(HANDSHAKE_HEADER *)pkg;

	sprintf(handshake_header->head, "ACTi");
	handshake_header->msg_type=CTRL_DIO_OUT_REQ;
	handshake_header->len=1;
	pkg[HANDSHAKE_HEADER_LEN]=dio_stat;
	//printf("<conrol_DIO_send>0x%02x\n", dio_stat);
	if(write_tcp_socket(priv->sockfd, pkg, pkg_len, priv->time_out)==NETLIB_ERR_WRITE)
	{
		printf("<conrol_DIO_send>write_tcp_socket FAIL\n");
		free(pkg);
		return LS_FAIL;
	}
	free(pkg);
	return LS_SUCCESS;
}

/**********************************************/
/********** Stream connection ********************/ 
/**********************************************/
int __tcp3_connect(CONECT_OBJ* con)
{
	TCP_AUTHEN_REQ auth_req;
	TCP_AUTHEN_RSP auth_rsp;
	THREAD_T *thread=&con->stream_thread;
	TCP3_PRIV *priv=thread->priv;
	int rc;

	thread->status|=STATE_CONNECTING;
	
	if(create_tcp_socket(&priv->sockfd)==NETLIB_ERR_SOCKET)
	{
		printf("err <__tcp3_connect>create_tcp_socket FAIL\n");
		priv->sockfd=LS_FAIL;
		return LS_ERR_TCP3_SOCKET;
	}

	set_socket_block_mode(priv->sockfd, NETLIB_SOCK_BLOCK_ON);
	set_reuse_addr(priv->sockfd);
	
	printf("<__tcp3_connect-%d>%s ***********************\n", con->seq, con->WAN_IP);
	if(connect_socket(priv->sockfd, con->WAN_IP, con->PORT_VIDEO, priv->time_out)==NETLIB_ERR_CONNECT)
	{
		printf("err <__tcp3_connect> Can't connect to %s:%d\n", con->WAN_IP, con->PORT_VIDEO);
		return LS_ERR_TCP3_CONNECT;
	}

	sprintf(auth_req.name, con->user_name);
	sprintf(auth_req.pwd, con->password);
	auth_req.stream_id=0;
	auth_req.encrypt_type=PWD_ENCRYPTED_NONE;
	if(write_tcp_socket(priv->sockfd, (char *)&auth_req, CTRL_AUTHEN_REQ_LEN, priv->time_out)==NETLIB_ERR_WRITE)
	{
		printf("err <__tcp3_connect> Can't send CTRL_AUTHEN_REQ\n");
		return LS_ERR_TCP3_AUTHEN_REQ;
	}

	if((rc=read_tcp_socket(priv->sockfd, (char *)&auth_rsp, CTRL_AUTHEN_RSP_LEN, priv->time_out))==NETLIB_ERR_WRITE)
	{
		printf("err <__tcp3_connect> Can't read CTRL_AUTHEN_RSP\n");
		return LS_ERR_TCP3_AUTHEN_RSP;
	}
	
	if(auth_rsp.status!=TCP_AUTHEN_SUCCESS)
	{
		printf("err <__tcp3_connect>TCP3_RSP_ERR: %d\n", auth_rsp.status);
		return LS_ERR_TCP3_RSP_ERR;
	}

	strcpy(con->camera_name, auth_rsp.camera_name);
	priv->url_id=auth_rsp.sock;

	thread->status|=STATE_CONNECTED;

	printf("<__tcp3_connect-%d>Connect Success!\n", con->seq);
	return LS_SUCCESS;
}

void *__tcp3_thread(void *arg)
{
	CONECT_OBJ *con = arg;
	THREAD_T *thread=&con->stream_thread;
	TCP3_PRIV *priv=thread->priv;
	B2_HEADER *b2_header=NULL;
	char *buf=NULL;
	char *buf_tmp=NULL;
	int buf_len=B2_HEADER_LEN;
	int error_min=LS_SUCCESS;
	int rc=0;
	int seq=con->seq;
	
	printf("<__tcp3_thread-%d>Start\n", con->seq);

	if((error_min=__tcp3_connect(con))!=LS_SUCCESS)
	{
		printf("err <__tcp3_thread>control_connect FAIL!\n");
		thread->stop(con);
	}
	else
	{
		if(con->callback_stream_connected!=NULL)
			con->callback_stream_connected(con);
	}

	buf=(char *)malloc(buf_len);
	b2_header=(B2_HEADER *)buf;
	
	while((thread->status&STATE_CLOSING)==0)
	{
		rc=read_tcp_socket(priv->sockfd, buf, B2_HEADER_LEN, priv->time_out);
		if(rc<=0)
		{
			printf("err <__tcp3_thread>read b2_header FAIL!\n");
			thread->stop(con);
			error_min=LS_ERR_TCP3_READ_B2;
			break;
		}
		
		if(
			b2_header->head[0]!=0x00 ||
			b2_header->head[1]!=0x00 ||
			b2_header->head[2]!=0x01 ||
			b2_header->head[3]!=0xb2
		)
		{
			printf("err <__tcp3_thread>check b2_header FAIL!\n");
			thread->stop(con);
			error_min=LS_ERR_TCP3_CHECK_B2;
			break;
		}

		if((b2_header->len+B2_HEADER_LEN)>buf_len)
		{
			buf_len=b2_header->len+B2_HEADER_LEN;
			buf_tmp=(char *)malloc(buf_len);
			memcpy(buf_tmp, buf, B2_HEADER_LEN);
			free(buf);
			buf=buf_tmp;
			b2_header=(B2_HEADER *)buf;
			buf_tmp=NULL;
		}
		
		rc=read_tcp_socket(priv->sockfd, buf+B2_HEADER_LEN, b2_header->len, priv->time_out);
		if(rc<=0)
		{
			printf("err <__tcp3_thread>read b2 payload FAIL!\n");
			thread->stop(con);
			error_min=LS_ERR_TCP3_READ_DATA;
			break;
		}

		if(
			(
				b2_header->msg_type==B2_VIDEO_MPEG4 ||
				b2_header->msg_type==B2_VIDEO_MJPEG ||
				b2_header->msg_type==B2_VIDEO_H264

			) &&
			con->callback_video!=NULL
		)
			con->callback_video((VIDEO_B2_FRAME *)buf, con);

		if(
			b2_header->msg_type==B2_AUDIO_8KPCM &&
			con->callback_audio!=NULL
		)
			con->callback_audio((AUDIO_B2_FRAME *)buf, con);
		
	}
	
	if(buf!=NULL)
	{
		free(buf);
		buf=NULL;
	}

	if(buf_tmp!=NULL)
	{
		free(buf_tmp);
		buf=NULL;
	}

	if(priv->sockfd!=LS_FAIL)
	{
		close(priv->sockfd);
		priv->sockfd=LS_FAIL;
	}
	
	if(error_min!=LS_SUCCESS)
		ERR_CALLBACK(LS_ERR_TCP3, error_min, con);
	
	printf("<__tcp3_thread-%d/%d>STATUS_CLOSED\n", seq, con->seq);
	thread->status|=STATE_CLOSED;
	
	pthread_detach(pthread_self());
	pthread_exit(NULL);
}

void __tcp3_init(void* arg)
{
	CONECT_OBJ *con=(CONECT_OBJ *)arg;
	THREAD_T *thread = &con->stream_thread;
	TCP3_PRIV *priv;
	
	//printf("<__tcp3_init-%d>\n", con->seq);

	if(thread->priv!=NULL)
	{
		free(thread->priv);
		thread->priv=NULL;
	}
	
	priv=thread->priv=(TCP3_PRIV *)malloc(TCP3_PRIV_LEN);
	priv->sockfd=LS_FAIL;
	priv->time_out=DEFAULT_TIME_OUT;

	thread->start=&__tcp3_start;
	thread->stop=&__tcp3_stop;
	thread->destroy=&__tcp3_destroy;

	thread->status=STATE_NULL;
	
}

void __tcp3_start(void* arg)
{
	CONECT_OBJ *con=(CONECT_OBJ *)arg;
	THREAD_T *thread = &con->stream_thread;
	TCP3_PRIV *priv = thread->priv;
	
	printf("<__tcp3_start-%d>\n", con->seq);

	if(
		(thread->status&(STATE_CONNECTING)) >0
	)
		return;
	
	if (pthread_create(&priv->thread_id, NULL, __tcp3_thread, (void *)con) < 0)
	{
		printf("err <__tcp3_start>Creat control_thread FAIL\n");
		thread->stop(con);
	}
}

void __tcp3_stop(void* arg)
{
	CONECT_OBJ *con=(CONECT_OBJ *)arg;
	THREAD_T *thread = &con->stream_thread;
	TCP3_PRIV *priv = thread->priv;
	
	//if(priv->status>STATUS_NULL && priv->status<STATUS_CLOSING)
	//{
		thread->status|=STATE_CLOSING;
	
		if(priv->sockfd!=LS_FAIL)
			shutdown(priv->sockfd, 0);
		
		printf("<__tcp3_stop-%d>STATUS_CLOSING\n", con->seq);
	//}
}

void __tcp3_destroy(void* arg)
{
	CONECT_OBJ *con=(CONECT_OBJ *)arg;
	THREAD_T *thread = &con->stream_thread;
	TCP3_PRIV *priv = thread->priv;
	int counter=0;

	printf("<__tcp3_destroy-%d>Start\n", con->seq);

	if((thread->status&STATE_CONNECTING)>0)
	{
		thread->status|=STATE_CLOSING;

		while((thread->status&STATE_CLOSED)==0)
		{
			printf("<__tcp3_destroy-%d>Waiting, status\n", con->seq);
			usleep(priv->time_out * 1000);
			if(counter++>destroy_wait_time)break;
		}
	}
	
	if(priv!=NULL)
	{
		free(priv);
		priv=NULL;
	}
	printf("<__tcp3_destroy-%d>finished-2\n", con->seq);
	
}

int __mul_connect(CONECT_OBJ* con)
{
	THREAD_T *thread=&con->stream_thread;
	MUL_PRIV *priv=thread->priv;

	thread->status|=STATE_CONNECTING;
	
	if(create_udp_socket(&priv->sockfd)==NETLIB_ERR_SOCKET)
	{
		printf("err <__mul_connect>create_tcp_socket FAIL\n");
		priv->sockfd=LS_FAIL;
		return LS_ERR_MUL_SOCKET;
	}

	if(bind_socket(priv->sockfd, con->V2_MULTICAST_IP, con->PORT_MULTICAST)==NETLIB_ERR_BIND)
	{
		printf("err <__mul_connect>bind_socket FAIL\n");
		priv->sockfd=LS_FAIL;
		return LS_ERR_MUL_CONNECT;
	}

	if(set_mcast_rcv_interface(priv->sockfd, con->V2_MULTICAST_IP)==NETLIB_ERR_SET_OPT)
	{
		printf("err <__mul_connect>set_mcast_interface FAIL\n");
		priv->sockfd=LS_FAIL;
		return LS_ERR_MUL_INTERFACE;
	}

	if(set_rcvbuf(priv->sockfd, priv->rcvbuf)==NETLIB_ERR_SET_OPT)
	{
		printf("err <__mul_connect>set_rcvbuf FAIL\n");
		priv->sockfd=LS_FAIL;
		return LS_ERR_MUL_SET_BUF;
	}

	__util_get_cameraname(con);

	thread->status|=STATE_CONNECTED;
	
	return LS_SUCCESS;
}

int __mul_get_frame(CONECT_OBJ* con)
{
	THREAD_T *thread=&con->stream_thread;
	MUL_PRIV *priv=thread->priv;
	struct sockaddr_in host;
	int check_in=LS_FAIL;
	int rc=0;
	int frame_buf_index=0;
	B2_HEADER *b2_header=NULL;
	char pkg_buf[ETHER_MTU];
	MCAST_HEAD *mcast_header=(MCAST_HEAD *)pkg_buf;

	host.sin_port = htons(con->PORT_MULTICAST);
	host.sin_addr.s_addr = inet_addr(con->V2_MULTICAST_IP);

	check_in=LS_FAIL;
	frame_buf_index=0;
	while(1)
	{
		if((rc=read_udp_socket(priv->sockfd, pkg_buf, ETHER_MTU, &host, priv->time_out*1000))==NETLIB_ERR_READ)
		{
			printf("<__mul_get_frame>read_udp_socket FAIL\n");
			return LS_ERR_MUL_RECEIVE;
		}
		
		if(check_in==LS_FAIL)
		{
			if(mcast_header->seq==0x01)
			{
				check_in=LS_SUCCESS;
				b2_header=(B2_HEADER *)(pkg_buf+MCAST_HEAD_LEN);
				
				if(priv->frame_buf_len<(b2_header->len+B2_HEADER_LEN))
				{
					free(priv->frame_buf);
					priv->frame_buf_len=b2_header->len+B2_HEADER_LEN;
					priv->frame_buf=(char *)malloc(priv->frame_buf_len);
				}
				
				/*fix the bug of EPL Video Server: when video lost, last flag in mcast_head didn't be setted.*/
				if((rc-MCAST_HEAD_LEN)==VIDEO_B2_FRAME_LEN)
				{
					mcast_header->last=MCAST_HEAD_LAST_PKT;
				}
			}
		}

		if(check_in==LS_SUCCESS)
		{
			if((frame_buf_index+rc-MCAST_HEAD_LEN)>priv->frame_buf_len)
			{
				printf("<__mul_get_frame>data length error-1!%d/%d\n", (frame_buf_index+rc-MCAST_HEAD_LEN), priv->frame_buf_len);
				return LS_ERR_MUL_DATA_LEN_1;
			}

			rc-=MCAST_HEAD_LEN;
			memcpy(priv->frame_buf+frame_buf_index, pkg_buf+MCAST_HEAD_LEN, rc);
			frame_buf_index+=rc;
			
			if(mcast_header->last==MCAST_HEAD_LAST_PKT)
			{
				b2_header=(B2_HEADER *)(priv->frame_buf);
				if((b2_header->len+B2_HEADER_LEN)==frame_buf_index)
				{
					return LS_SUCCESS;
				}else
				{
					printf("<__mul_get_frame>data length error-2!%d/%d\n", frame_buf_index, b2_header->len+B2_HEADER_LEN);
					return LS_ERR_MUL_DATA_LEN_2;
				}
			}
		}
	}
	
	return LS_FAIL;
}

void *__mul_thread(void *arg)
{
	CONECT_OBJ *con = arg;
	THREAD_T *thread=&con->stream_thread;
	MUL_PRIV *priv=thread->priv;
	B2_HEADER *b2_header=NULL;
	
	int error_min=LS_SUCCESS;

	printf("<__mul_thread>Start\n");

	priv->frame_buf=(char *)malloc(priv->frame_buf_len);
	
	if((error_min=__mul_connect(con))!=LS_SUCCESS)
	{
		printf("<__mul_thread>__mul_connect FAIL\n");
		thread->stop(con);
	}
	else
	{
		if(con->callback_stream_connected!=NULL)
			con->callback_stream_connected(con);
	}
	
	while((thread->status&STATE_CLOSING)==0)
	{
		if(__mul_get_frame(con)==LS_SUCCESS)
		{
			b2_header=(B2_HEADER *)priv->frame_buf;
			
			if(
				b2_header->msg_type==B2_VIDEO_MPEG4 &&
				con->callback_video!=NULL
			)
			{
				con->callback_video((VIDEO_B2_FRAME *)priv->frame_buf, con);
			}
			else 
			if(
				b2_header->msg_type==B2_AUDIO_8KPCM &&
				con->callback_audio!=NULL
			)
			{
				con->callback_audio((AUDIO_B2_FRAME *)priv->frame_buf, con);
			}
		}
	}
	
	if(priv->sockfd!= LS_FAIL)
	{
		close(priv->sockfd);
		priv->sockfd=LS_FAIL;
	}

	if(priv->frame_buf!=NULL)
	{
		free(priv->frame_buf);
		priv->frame_buf=NULL;
	}

	if(error_min!=LS_SUCCESS)
		ERR_CALLBACK(LS_ERR_MUL, error_min, con);
	
	printf("<__mul_thread>STATUS_CLOSED\n");
	thread->status|=STATE_CLOSED;

	pthread_detach(pthread_self());
	pthread_exit(NULL);
}
	
void __mul_init(void* arg)
{
	CONECT_OBJ *con=(CONECT_OBJ *)arg;
	THREAD_T *thread = &con->stream_thread;
	MUL_PRIV *priv = thread->priv;

	printf("<__mul_init>\n");

	if(thread->priv!=NULL)
	{
		free(thread->priv);
		thread->priv=NULL;
	}
		
	priv=thread->priv=(MUL_PRIV *)malloc(MUL_PRIV_LEN);
	priv->sockfd=LS_FAIL;
	priv->time_out=DEFAULT_TIME_OUT;
	priv->rcvbuf=DEFAULT_MUL_RCVBUF;
	priv->frame_buf=NULL;
	priv->frame_buf_len=B2_HEADER_LEN;

	thread->start=&__mul_start;
	thread->stop=&__mul_stop;
	thread->destroy=&__mul_destroy;

	thread->status=STATE_NULL;
	
}

void __mul_start(void* arg)
{
	CONECT_OBJ *con=(CONECT_OBJ *)arg;
	THREAD_T *thread = &con->stream_thread;
	MUL_PRIV *priv = thread->priv;

	printf("<__mul_start>\n");
	
	if((thread->status&STATE_CONNECTED)>0)
		return;


	if (pthread_create(&priv->thread_id, NULL, __mul_thread, (void *)con) < 0)
	{
		printf("err <__mul_start>Creat control_thread FAIL\n");
		thread->stop(con);
	}
}

void __mul_stop(void* arg)
{
	CONECT_OBJ *con=(CONECT_OBJ *)arg;
	THREAD_T *thread = &con->stream_thread;
	MUL_PRIV *priv = thread->priv;

		thread->status|=STATE_CLOSING;
		shutdown(priv->sockfd, 0);
		printf("<__mul_stop>STATUS_CLOSING\n");
}

void __mul_destroy(void* arg)
{
	CONECT_OBJ *con=(CONECT_OBJ *)arg;
	THREAD_T *thread = &con->stream_thread;
	MUL_PRIV *priv = thread->priv;

	int counter=0;

	if((thread->status&STATE_CONNECTING)>0)
	{
		thread->status|=STATE_CLOSING;
		while((thread->status&STATE_CLOSED)==0)
		{
			printf("<__mul_destroy>Waiting\n");
			usleep(priv->time_out * 1000);
			if(counter++>destroy_wait_time)break;
		}
	}

	if(priv!=NULL)
	{
		free(priv);
		priv=NULL;
	}
	printf("<__mul_destroy>finished\n");
}

int __rtp_connect(CONECT_OBJ* con)
{
	THREAD_T *thread = &con->stream_thread;
	RTP_PRIV *priv = thread->priv;
	
	RTSP_HOST_CONF * rtsp_host_conf=&priv->rtsp_host_conf;
	RTCP_HOST_CONF * rtcp_host_conf=&priv->rtcp_host_conf;
	RTP_HOST_CONF * rtp_host_conf=&priv->rtp_host_conf;

	thread->status|=STATE_CONNECTING;
	
	__rtp_config(con);
	if(Connect2RTSPSrv(rtsp_host_conf) == RTSP_ERR)
	{
		printf( "<__rtp_start>Fail to create the RTCP sockets\n");
		return LS_FAIL;
	}

	InitRTCPHostConf(rtsp_host_conf, rtcp_host_conf);
	if(CreateRTCPHostSockets(rtcp_host_conf) == RTCP_ERR)
	{
		printf( "<__rtp_start>Fail to create the RTCP sockets\n");
		return LS_FAIL;
	}

	InitRTPHostConf(rtsp_host_conf, rtp_host_conf);
	if(CreateRTPHostSockets(rtp_host_conf) == RTCP_ERR) 
	{
		printf( "<__rtp_start>Fail to create the RTP sockets\n");
		__rtp_closeAllSockets(rtsp_host_conf, rtp_host_conf, rtcp_host_conf);
		return LS_FAIL;
	}

	set_rcvbuf(rtp_host_conf->Media[0].Sock, MAX_FRAME_SIZE*3);
	
	if(RTSPHostPlayHandle(rtsp_host_conf) == RTSP_ERR) 
	{
		printf("<__rtp_start>fail of connecting RTSP server\n");
		__rtp_closeAllSockets(rtsp_host_conf, rtp_host_conf, rtcp_host_conf);
		return LS_FAIL;
	}

	__util_get_cameraname(con);
	
	RTPSeqNumUpdate(rtsp_host_conf->Info.Media[0].Seq, rtsp_host_conf->Info.Media[1].Seq, rtp_host_conf);

	thread->status|=STATE_CONNECTED;
	
	return LS_SUCCESS;
}

void *__rtp_rtcp_thread(void *arg)
{
	CONECT_OBJ *con=(CONECT_OBJ *)arg;
	THREAD_T *thread = &con->stream_thread;
	RTP_PRIV *priv = thread->priv;
	
	//RTSP_HOST_CONF * rtsp_host_conf=&priv->rtsp_host_conf;
	RTCP_HOST_CONF * rtcp_host_conf=&priv->rtcp_host_conf;
	//RTP_HOST_CONF * rtp_host_conf=&priv->rtp_host_conf;
	int seq=con->seq;

	int ret;

	printf("<__rtp_rtcp_thread>Start\n");
	
	/* set the RTCP State to Run State now */
	 rtcp_host_conf->State = RTCP_HOST_STATE_RUN;

	/* handle the RTCP TX/RX tasks */
	while(rtcp_host_conf->State == RTCP_HOST_STATE_RUN)
	{
		ret = RTCPHostHandler(rtcp_host_conf);
	}

	
	printf("<__rtp_rtcp_thread>Closed-%d\n", seq);	
	rtcp_host_conf->State = RTCP_HOST_STATE_INIT;

	priv->rtcp_thread_state=1;
	
	pthread_detach(pthread_self());
	pthread_exit(NULL);
}

int __rtp_check_b2(B2_HEADER* b2_header)
{
	if(
		b2_header->head[0]==0x00 &&
		b2_header->head[1]==0x00 &&
		b2_header->head[2]==0x01 &&
		b2_header->head[3]==0xb2
		
	)
	{
		return LS_SUCCESS;
	}
	else
	{
		return LS_FAIL;
	}
	return LS_FAIL;
}

void *__rtp_video_thread(void *arg)
{
	CONECT_OBJ *con=(CONECT_OBJ *)arg;
	THREAD_T *thread = &con->stream_thread;
	RTP_PRIV *priv = thread->priv;
	
	//RTSP_HOST_CONF * rtsp_host_conf=&priv->rtsp_host_conf;
	RTCP_HOST_CONF * rtcp_host_conf=&priv->rtcp_host_conf;
	RTP_HOST_CONF * rtp_host_conf=&priv->rtp_host_conf;

	RTP_FRAME Frame;

	printf("<__rtp_video_thread>Start\n");

	//priv->video_thread_count=0;

	rtp_host_conf->Media[0].State = RTP_HOST_STATE_RUN;
	Frame.Buf=(unsigned char *)malloc(MAX_VIDEO_FRAME);

	Frame.Len=MAX_VIDEO_FRAME;
	if(RTPVideoIFrameHunting(&Frame,rtp_host_conf, rtcp_host_conf)==RTP_OK)
	{
		if(__rtp_check_b2((B2_HEADER *)Frame.Buf)==LS_SUCCESS)
		{
			if(con->callback_video!=NULL)
				con->callback_video((VIDEO_B2_FRAME *)Frame.Buf, con);	
		}else
		{
			printf("<__rtp_video_thread>Data error!\n");
		}
	}
	else
	{
		printf("<__rtp_video_thread>RTPVideoIFrameHunting FAIL!\n");
		rtp_host_conf->Media[0].State = RTP_HOST_STATE_CLOSE;
	}

	while(rtp_host_conf->Media[0].State == RTP_HOST_STATE_RUN)
	{
		Frame.Len=MAX_VIDEO_FRAME;
		
		if(RTPFrameVideoGet(&Frame,rtp_host_conf, rtcp_host_conf)==RTP_OK)
		{
			if(__rtp_check_b2((B2_HEADER *)Frame.Buf)==LS_SUCCESS)
			{
				if(con->callback_video!=NULL)
					con->callback_video((VIDEO_B2_FRAME *)Frame.Buf, con);
			}
			else
			{
				printf("<__rtp_video_thread>Data error!\n");
			}
		}
		else
		{
			printf("<__rtp_video_thread>RTPFrameVideoGet FAIL!\n");
			//rtp_host_conf->Media[0].State = RTP_HOST_STATE_INIT;
		}

		//priv->video_thread_count++;
	}
	
	free(Frame.Buf);
	printf("<__rtp_video_thread-%d>Closed\n", con->seq);	
	rtp_host_conf->Media[0].State = RTP_HOST_STATE_INIT;
	priv->video_thread_state=1;

	pthread_detach(pthread_self());
	pthread_exit(NULL);
}

void *__rtp_audio_thread(void *arg)
{
	CONECT_OBJ *con=(CONECT_OBJ *)arg;
	THREAD_T *thread = &con->stream_thread;
	RTP_PRIV *priv = thread->priv;
	
	//RTSP_HOST_CONF * rtsp_host_conf=&priv->rtsp_host_conf;
	RTCP_HOST_CONF * rtcp_host_conf=&priv->rtcp_host_conf;
	RTP_HOST_CONF * rtp_host_conf=&priv->rtp_host_conf;

	RTP_FRAME Frame;
	AUDIO_B2_FRAME *audio_frame;

	printf("<__rtp_audio_thread>Start\n");

	rtp_host_conf->Media[1].State = RTP_HOST_STATE_RUN;
	audio_frame=(AUDIO_B2_FRAME *)malloc(AUDIO_B2_FRAME_LEN+MAX_AUDIO_FRAME);
	Frame.Buf=(unsigned char *)audio_frame+AUDIO_B2_FRAME_LEN;

	Frame.Len=MAX_AUDIO_FRAME;
	if(RTPAudio1stFrameHunting(&Frame,rtp_host_conf, rtcp_host_conf)==RTP_OK)
	{
		//printf("<__rtp_audio_thread>Frame.Len=%d\n", Frame.Len);
		audio_frame->header.len=AUDIO_PRIVATE_DATA_LEN+Frame.Len;
		if(con->callback_audio!=NULL)
		{
				con->callback_audio(audio_frame, con);
		}
	}
	else
	{
		printf("<__rtp_audio_thread>RTPAudio1stFrameHunting FAIL!\n");
		rtp_host_conf->Media[1].State = RTP_HOST_STATE_CLOSE;
	}

	while(rtp_host_conf->Media[1].State == RTP_HOST_STATE_RUN)
	{
		Frame.Len=MAX_AUDIO_FRAME;
		if(RTPFrameAudioGet(&Frame, rtp_host_conf, rtcp_host_conf)==RTP_OK)
		{
			//printf("<__rtp_audio_thread>Frame.Len=%d\n", Frame.Len);
			audio_frame->header.len=AUDIO_PRIVATE_DATA_LEN+Frame.Len;
			if(con->callback_audio!=NULL)
			{
				con->callback_audio(audio_frame, con);
			}
		}
		else
		{
			printf("<__rtp_audio_thread>RTPFrameAudioGet FAIL!\n");
		}
	}
	
	free(Frame.Buf);
	printf("<__rtp_audio_thread-%d>Closed\n", con->seq);
	rtp_host_conf->Media[1].State = RTP_HOST_STATE_INIT;
	priv->audio_thread_state=1;
	pthread_detach(pthread_self());
	pthread_exit(NULL);
}

void __rtp_init(void* arg)
{
	CONECT_OBJ *con=(CONECT_OBJ *)arg;
	THREAD_T *thread = &con->stream_thread;
	RTP_PRIV *priv = thread->priv;

	printf("<__rtp_init>\n");

	if(thread->priv!=NULL)
	{
		free(thread->priv);
		thread->priv=NULL;
	}
		
	priv=thread->priv=(RTP_PRIV *)malloc(RTP_PRIV_LEN);

	thread->start=&__rtp_start;
	thread->stop=&__rtp_stop;
	thread->destroy=&__rtp_destroy;

	thread->status=STATE_NULL;
}

void __rtp_config(CONECT_OBJ *con)
{
	THREAD_T *thread = &con->stream_thread;
	RTP_PRIV *priv = thread->priv;
	
	RTSP_HOST_CONF * rtsp_host_conf=&priv->rtsp_host_conf;
	RTSP_HOST_INFO *Info = &rtsp_host_conf->Info;
	RTSP_MEDIA     *Media = rtsp_host_conf->Info.Media;

	int i;
	
	strcpy(rtsp_host_conf->SrvIP , con->WAN_IP);
	strcpy(rtsp_host_conf->HostIP, con->Local_WAN_IP);	/*TODO: Should we use LAN or WAN IP here?*/
	memset(rtsp_host_conf->SrvMcastIP, '\0', 16);
	rtsp_host_conf->SrvPort = con->V2_PORT_RTSP;
	rtsp_host_conf->ConnTime = 1;      /* 1 sec timer for connection establishment */
	rtsp_host_conf->RespTime = 10*1000;    /* 100msec for waiting Server's reply timer */
	strcpy(rtsp_host_conf->Name, con->user_name);
	strcpy(rtsp_host_conf->Pwd, con->password);
	rtsp_host_conf->Encoder = RTSP_ENCODER_DIGEST;
	memset((char *)&Info->Digest, '\0', sizeof(RTSP_DIGEST));

	/* setup URI base on the account and password */
	sprintf(
		Info->Digest.Uri, 
		"rtsp://%s:%s@%s:%d",
		rtsp_host_conf->Name, 
		rtsp_host_conf->Pwd, 
		rtsp_host_conf->SrvIP, 
		rtsp_host_conf->SrvPort
		);
	
	/* initialize the Midea Database */
	for(i = 0 ; i < 2 ; i ++) {
		memset(Media[i].Config, '\0', 128);
		Media[i].ConfigLen = 0;
		Media[i].Type = 0;
		Media[i].RTPSrvPort   = 0;
		Media[i].RTPHostPort  = 0;
		Media[i].RTCPSrvPort  = 0;
		Media[i].RTCPHostPort = 0;
		memset(Media[i].CtrlPath, '\0', 32);
	}
}

void __rtp_closeAllSockets(RTSP_HOST_CONF *Rtsp, RTP_HOST_CONF *Rtp, RTCP_HOST_CONF *Rtcp) 
{
	printf("<__rtp_closeAllSockets>\n");
	
	if(Rtsp->Sock) close(Rtsp->Sock);
	if(Rtp->Media[0].Sock)  close(Rtp->Media[0].Sock);
	if(Rtp->Media[1].Sock)  close(Rtp->Media[1].Sock);
	if(Rtcp->Media[0].Sock) close(Rtcp->Media[0].Sock);
	if(Rtcp->Media[1].Sock) close(Rtcp->Media[1].Sock);
	return;
}

void __rtp_start(void* arg)
{
	CONECT_OBJ *con=(CONECT_OBJ *)arg;
	THREAD_T *thread = &con->stream_thread;
	RTP_PRIV *priv = thread->priv;

	if(__rtp_connect(con)==LS_FAIL)
	{
		printf("err <__rtp_start> __rtp_connect FAIL\n");
		thread->stop(con);
		ERR_CALLBACK(LS_ERR_RTP, LS_ERR_RTP_CONNECT, con);
		return;
	}

	if (pthread_create(&priv->rtcp_thread_id, NULL, __rtp_rtcp_thread, (void *)con) < 0)
	{
		printf("err <__rtp_start>Creat __rtp_rtcp_thread FAIL\n");
		thread->stop(con);
		ERR_CALLBACK(LS_ERR_RTP, LS_ERR_RTP_RTCP_THREAD, con);
		return;
	}

	if (pthread_create(&priv->video_thread_id, NULL, __rtp_video_thread, (void *)con) < 0)
	{
		printf("err <__rtp_start>Creat __rtp_video_thread FAIL\n");
		thread->stop(con);
		ERR_CALLBACK(LS_ERR_RTP, LS_ERR_RTP_VIDEO_THREAD, con);
		return;
	}

	if (pthread_create(&priv->audio_thread_id, NULL, __rtp_audio_thread, (void *)con) < 0)
	{
		printf("err <__rtp_start>Creat __rtp_audio_thread FAIL\n");
		thread->stop(con);
		ERR_CALLBACK(LS_ERR_RTP, LS_ERR_RTP_AUDIO_THREAD, con);
		return;
	}

	if(con->callback_stream_connected!=NULL)
			con->callback_stream_connected(con);
	
	printf("<__rtp_start>\n");
	
}

void __rtp_stop(void* arg)
{
	CONECT_OBJ *con=(CONECT_OBJ *)arg;
	THREAD_T *thread = &con->stream_thread;
	RTP_PRIV *priv = thread->priv;
	
	//RTSP_HOST_CONF * rtsp_host_conf=&priv->rtsp_host_conf;
	RTCP_HOST_CONF * rtcp_host_conf=&priv->rtcp_host_conf;
	RTP_HOST_CONF * rtp_host_conf=&priv->rtp_host_conf;

	if(rtcp_host_conf->State==RTCP_HOST_STATE_RUN) rtcp_host_conf->State=RTCP_HOST_STATE_CLOSE;
	if(rtp_host_conf->Media[0].State==RTP_HOST_STATE_RUN) rtp_host_conf->Media[0].State = RTP_HOST_STATE_CLOSE;
	if(rtp_host_conf->Media[1].State==RTP_HOST_STATE_RUN) rtp_host_conf->Media[1].State = RTP_HOST_STATE_CLOSE;	

	RTCPSendByePkt(rtcp_host_conf);
	
	if(rtp_host_conf->Media[0].Sock)  shutdown(rtp_host_conf->Media[0].Sock, 2);
	if(rtp_host_conf->Media[1].Sock)  shutdown(rtp_host_conf->Media[1].Sock, 2);
}

void __rtp_destroy(void* arg)
{
	CONECT_OBJ *con=(CONECT_OBJ *)arg;
	THREAD_T *thread = &con->stream_thread;
	RTP_PRIV *priv = thread->priv;
	
	RTSP_HOST_CONF * rtsp_host_conf=&priv->rtsp_host_conf;
	RTCP_HOST_CONF * rtcp_host_conf=&priv->rtcp_host_conf;
	RTP_HOST_CONF * rtp_host_conf=&priv->rtp_host_conf;

	printf("<__rtp_destroy-%d>Start\n", con->seq);

	if(rtp_host_conf->Media[0].State!=0)
	{
		//while(rtp_host_conf->Media[0].State==RTP_HOST_STATE_CLOSE)
		while(priv->video_thread_state==0)
		{
			printf("<__rtp_destroy-%d>Waiting for rtp_video close-state-%d-%d\n", con->seq, rtp_host_conf->Media[0].State, priv->video_thread_state);
			usleep(10*1000);
		}
	}

	if(rtp_host_conf->Media[1].State!=0)
	{
		//while(rtp_host_conf->Media[1].State==RTP_HOST_STATE_CLOSE)
		while(priv->audio_thread_state==0)
		{
			printf("<__rtp_destroy-%d>Waiting for rtp_audio close\n", con->seq);
			usleep(10*1000);
		}
	}

	if(rtcp_host_conf->State!=0)
	{
		//while(rtcp_host_conf->State==RTCP_HOST_STATE_CLOSE)
		while(priv->rtcp_thread_state==0)
		{
			printf("<__rtp_destroy-%d>Waiting for rtcp_host close\n", con->seq);
			usleep(10*1000);
		}
	}
	
	__rtp_closeAllSockets(rtsp_host_conf, rtp_host_conf, rtcp_host_conf);

	if(thread->priv!=NULL)
	{
		free(thread->priv);
		thread->priv=NULL;
	}
	
	printf("<__rtp_destroy-%d>finished*********\n", con->seq);
}

int stream_set_video_callback(CONECT_OBJ* con, void *callback)
{
	con->callback_video=callback;
	//printf("<stream_set_video_callback>\n");
	return LS_SUCCESS;
}

int stream_set_audio_callback(CONECT_OBJ* con, void *callback)
{
	con->callback_audio=callback;
	//printf("<stream_set_audio_callback>\n");
	return LS_SUCCESS;
}

int stream_set_connected_callback(CONECT_OBJ* con, void *callback)
{
	con->callback_stream_connected=callback;
	//printf("<stream_set_audio_callback>\n");
	return LS_SUCCESS;
}

int stream_start(CONECT_OBJ* con)
{
	THREAD_T *thread=&con->stream_thread;

	if(thread->start!=NULL)
	{
		thread->start(con);
		return LS_SUCCESS;
	}
	printf("err <stream_start>connect obj didn't be init yet.\n");
	return LS_FAIL;
}

int stream_stop(CONECT_OBJ* con)
{
	THREAD_T *thread=&con->stream_thread;

	if(thread->stop!=NULL)
	{
		thread->stop(con);
		return LS_SUCCESS;
	}
	printf("err <stream_stop>connect obj didn't be init yet.\n");
	return LS_FAIL;
}

int stream_is_connected(CONECT_OBJ* con)
{
	if(
		(con->stream_thread.status&STATE_CONNECTED)>0 &&
		(con->stream_thread.status&STATE_CLOSING)==0
	)
		return 1;
	else
		return 0;
}

/**********************************************/
/********** Audio out connection ******************/ 
/**********************************************/
int __audioout_connect(CONECT_OBJ* con)
{
	THREAD_T *thread=&con->audio_out_thread;
	CONTROL_PRIV *priv = thread->priv;
	CTRL_AUTHEN_REQ auth_req;
	CTRL_AUTHEN_RSP auth_rsp;
	int rc;

	thread->status|=STATE_CONNECTING;
	
	if(create_tcp_socket(&priv->sockfd)==NETLIB_ERR_SOCKET)
	{
		printf("err <__audioout_connect>create_tcp_socket FAIL\n");
		priv->sockfd=LS_FAIL;
		return LS_FAIL;
	}

	set_socket_block_mode(priv->sockfd, NETLIB_SOCK_BLOCK_ON);
	
	if(connect_socket(priv->sockfd, con->WAN_IP, con->PORT_CONTROL, priv->time_out)==NETLIB_ERR_CONNECT)
	{
		printf("err <__audioout_connect> Can't connect to %s.\n", con->WAN_IP);
		close(priv->sockfd);
		priv->sockfd=LS_FAIL;
		return LS_FAIL;
	}

	sprintf(auth_req.name, con->user_name);
	sprintf(auth_req.pwd, con->password);
	auth_req.token=TOKEN_AUDIO_REQ;
	if(write_tcp_socket(priv->sockfd, (char *)&auth_req, CTRL_AUTHEN_REQ_LEN, priv->time_out)==NETLIB_ERR_WRITE)
	{
		printf("err <__audioout_connect> Can't send CTRL_AUTHEN_REQ\n");
		close(priv->sockfd);
		priv->sockfd=LS_FAIL;
		return LS_FAIL;
	}

	if((rc=read_tcp_socket(priv->sockfd, (char *)&auth_rsp, CTRL_AUTHEN_RSP_LEN, priv->time_out))==NETLIB_ERR_WRITE)
	{
		printf("err <__audioout_connect> Can't read CTRL_AUTHEN_RSP\n");
		close(priv->sockfd);
		priv->sockfd=LS_FAIL;
		return LS_FAIL;
	}
	
	if(auth_rsp.result!=CTRL_RSP_OK)
	{
		printf("err <__audioout_connect>CTRL_RSP_ERR: %d\n", auth_rsp.err_code);
		close(priv->sockfd);
		priv->sockfd=LS_FAIL;
		return LS_FAIL;
	}

	thread->status|=STATE_CONNECTED;
	printf("<__audioout_connect>Connect Success!\n");
	return LS_SUCCESS;
}

void *__audioout_thread(void *arg)
{
	CONECT_OBJ *con=(CONECT_OBJ *)arg;
	THREAD_T *thread = &con->audio_out_thread;
	//AUDIOOUT_PRIV *priv = thread->priv;
	int count=0;
	
	while(
		(thread->status&STATE_CONNECTED)==0 &&
		(thread->status&STATE_CLOSED)==0
	)
	{
		if(__audioout_connect(con)==LS_FAIL)
		{
			printf("<__audioout_thread>__audioout_connect FAIL!\n");
			//thread->stop(con);
			ERR_CALLBACK(LS_ERR_AUDIOOUT, LS_ERR_AUDIOOUT_CONNECT, con);

			count=0;
			while(
					(thread->status&STATE_CLOSED)==0 &&
					count<10
			)
			{
				usleep(500*1000);
				count++;
			}
			if((thread->status&STATE_CLOSED)==0)
				thread->status=STATE_NULL;

			printf("<__audioout_thread>Retry\n");
		}
		else
		{
			if(con->callback_audioout_connected!=NULL)
				con->callback_audioout_connected(con);
		}
	}	
	pthread_detach(pthread_self());
	//printf("<__audioout_thread>Close\n");
	pthread_exit(NULL);
}

void __audioout_init(void* arg)
{
	CONECT_OBJ *con=(CONECT_OBJ *)arg;
	THREAD_T *thread = &con->audio_out_thread;
	AUDIOOUT_PRIV *priv = thread->priv;

	//printf("<__audioout_init>\n");
	
	if(thread->priv!=NULL)
	{
		free(thread->priv);
		thread->priv=NULL;
	}
	
	priv=thread->priv=(MUL_PRIV *)malloc(AUDIOOUT_PRIV_LEN);
	priv->sockfd=LS_FAIL;
	priv->time_out=DEFAULT_TIME_OUT;

	thread->start=&__audioout_start;
	thread->stop=&__audioout_stop;
	thread->destroy=&__audioout_destroy;

	thread->status=STATE_NULL;
}

void __audioout_start(void* arg)
{
	CONECT_OBJ *con=(CONECT_OBJ *)arg;
	THREAD_T *thread = &con->audio_out_thread;
	AUDIOOUT_PRIV *priv = thread->priv;
	
	printf("<__audioout_start>\n");

	if((thread->status&STATE_CONNECTING)>0)
		return;

	if (pthread_create(&priv->thread_id, NULL, __audioout_thread, (void *)con) < 0)
	{
		printf("err <__audioout_start>Creat control_thread FAIL\n");
		thread->stop(con);
	}

}

void __audioout_stop(void* arg)
{
	CONECT_OBJ *con=(CONECT_OBJ *)arg;
	THREAD_T *thread = &con->audio_out_thread;
	AUDIOOUT_PRIV *priv = thread->priv;
	
	if(priv->sockfd!=LS_FAIL)
	{
		close(priv->sockfd);
		priv->sockfd=LS_FAIL;
	}
	thread->status|=STATE_CLOSED;
	printf("<__audioout_stop>CLOSED!\n");
}

void __audioout_destroy(void* arg)
{
	CONECT_OBJ *con=(CONECT_OBJ *)arg;
	THREAD_T *thread = &con->audio_out_thread;
	AUDIOOUT_PRIV *priv = thread->priv;

	thread->stop(con);
	
	if(priv!=NULL)
	{
		free(priv);
		priv=NULL;
	}
	printf("<__audioout_destroy>finished\n");
}

int audioout_set_connected_callback(CONECT_OBJ* con, void *callback)
{
	con->callback_audioout_connected=callback;
	return LS_SUCCESS;
}

int audioout_start(CONECT_OBJ* con)
{
	THREAD_T *thread=&con->audio_out_thread;

	if(thread->start!=NULL)
	{
		thread->start(con);
		return LS_SUCCESS;
	}
	printf("err <audioout_start>connect obj didn't be init yet.\n");
	return LS_FAIL;
}

int audioout_stop(CONECT_OBJ* con)
{
	THREAD_T *thread=&con->audio_out_thread;

	if(thread->stop!=NULL)
	{
		thread->stop(con);
		return LS_SUCCESS;
	}
	printf("err <audioout_stop>connect obj didn't be init yet.\n");
	return LS_FAIL;
}

int audioout_send(CONECT_OBJ* con, char *buf, int len)
{
	THREAD_T *thread = &con->audio_out_thread;
	AUDIOOUT_PRIV *priv = thread->priv;
	
	HANDSHAKE_HEADER handshake_header;
	
	if(len!=AUDIO_OUT_PKG_LEN)
	{
		printf("err <audioout_send>Audio out data length MUST be %d bytes!\n", AUDIO_OUT_PKG_LEN);
		
		ERR_CALLBACK(LS_ERR_AUDIOOUT, LS_ERR_AUDIOOUT_LEN, con);
		thread->stop(con);
		return LS_FAIL;
	}

	if(!audioout_is_connected(con))
	{
		//printf("err <audioout_send>Audio out didn't connect.\n");
		ERR_CALLBACK(LS_ERR_AUDIOOUT, LS_ERR_AUDIOOUT_NOCONNECTION, con);
		thread->stop(con);
		return LS_FAIL;
	}

	sprintf(handshake_header.head, "ACTi");
	handshake_header.len=AUDIO_OUT_PKG_LEN;
	handshake_header.msg_type=CTRL_AUDIO_PLAY_REQ;

	if(write_tcp_socket(priv->sockfd, (char *)&handshake_header, HANDSHAKE_HEADER_LEN, priv->time_out)==NETLIB_ERR_WRITE)
	{
		printf("err <audioout_send>Audio out header send FAIL!\n");
		ERR_CALLBACK(LS_ERR_AUDIOOUT, LS_ERR_AUDIOOUT_SEND1, con);
		thread->stop(con);
		return LS_FAIL;
	}

	if(write_tcp_socket(priv->sockfd, buf, AUDIO_OUT_PKG_LEN, priv->time_out)==NETLIB_ERR_WRITE)
	{
		printf("err <audioout_send>Audio out data send FAIL!\n");
		ERR_CALLBACK(LS_ERR_AUDIOOUT, LS_ERR_AUDIOOUT_SEND2, con);
		thread->stop(con);
		return LS_FAIL;
	}

	return LS_SUCCESS;
}

int inline audioout_is_connected(CONECT_OBJ* con)
{
	if(
		(con->audio_out_thread.status&STATE_CONNECTED)>0 &&
		(con->audio_out_thread.status&STATE_CLOSING)==0
	)
		return 1;
	else
		return 0;
}

