//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by H264SDKExample.rc
//
#define IDOK2                           2
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_H264SDKEXAMPLE_DIALOG       102
#define VIDEO_DIALOG                    129
#define IDB_RED                         130
#define IDB_GREEN                       131
#define IDD_FIND_FIALOG                 132
#define CAM_PROPS_DIALOG                133
#define IDC_STOP                        1000
#define IDC_H264                        1002
#define IDC_MJPEG                       1003
#define IDC_Q_SLIDER                    1004
#define IDC_CHECK1                      1005
#define IDC_CHECK_HALF                  1005
#define IDC_LOCK_CHECK                  1005
#define IDC_IPADDRESS1                  1006
#define IDC_EDIT1                       1008
#define IDC_DESCRIPTION_EDIT            1008
#define IDC_EDIT2                       1010
#define IDC_EDIT3                       1012
#define IDC_EDIT4                       1013
#define IDC_RES_COMBO                   1017
#define IDC_TFT_NUM                     1018
#define IDC_RES_COMBO3                  1019
#define IDC_CONN_TYPE_COMBO             1019
#define IDC_COMBO1                      1020
#define IDC_FPS_COMBO                   1021
#define IDC_COMBO2                      1023
#define IDC_RES_COMBO2                  1023
#define IDC_BUTTON1                     1024
#define IDC_DN_AUTO                     1025
#define IDC_DN_DAY                      1026
#define IDC_DN_NIGHT                    1027
#define IDC_LIGHT_50                    1028
#define IDC_LIGHT_60                    1029
#define IDC_FIND_BTN                    1031
#define IDC_CAMLIST                     1033
#define ID_FIND_BTN                     1034
#define IDC_MODIFYBTN                   1035
#define IDC_IPADDRESS                   1036
#define IDC_FD_BUTTON                   1037

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1038
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
