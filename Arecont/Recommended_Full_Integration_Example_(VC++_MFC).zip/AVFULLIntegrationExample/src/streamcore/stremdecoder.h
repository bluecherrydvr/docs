#pragma once
#include "../common/Runnable.h"
#include "../common/types.h"
#include "../decoder/videodecoder.h"
#include "../viewsupport/FrameDrawer.h"

class  StreamDecoder : public Runnable
{
public:
	StreamDecoder(FrameDataQueue& dataqueue, Drawer& drawer );
	~StreamDecoder();



private:
	void run();

private:

	FrameDataQueue& m_dataqueue;
	VideoCodec m_h264;
	VideoCodec m_mjpeg;
	Drawer& m_drawer;

    
};