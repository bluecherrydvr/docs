/********************************************************************************
** Form generated from reading ui file 'relaysdialog.ui'
**
** Created: Mon Mar 30 21:53:04 2009
**      by: Qt User Interface Compiler version 4.2.2
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_RELAYSDIALOG_H
#define UI_RELAYSDIALOG_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QDialog>
#include <QtGui/QDialogButtonBox>
#include <QtGui/QGroupBox>
#include <QtGui/QPushButton>

class Ui_RelaysDialog
{
public:
    QDialogButtonBox *buttonBox;
    QPushButton *uiBtnApply;
    QGroupBox *uiGrpRelays;
    QCheckBox *uiChkRelay2;
    QCheckBox *uiChkRelay3;
    QCheckBox *uiChkRelay4;
    QCheckBox *uiChkRelay12;
    QCheckBox *uiChkRelay5;
    QCheckBox *uiChkRelay13;
    QCheckBox *uiChkRelay14;
    QCheckBox *uiChkRelay6;
    QCheckBox *uiChkRelay15;
    QCheckBox *uiChkRelay7;
    QCheckBox *uiChkRelay8;
    QCheckBox *uiChkRelay16;
    QCheckBox *uiChkRelay10;
    QCheckBox *uiChkRelay11;
    QCheckBox *uiChkRelay09;
    QCheckBox *uiChkRelay17;
    QCheckBox *uiChkRelay1;

    void setupUi(QDialog *RelaysDialog)
    {
    RelaysDialog->setObjectName(QString::fromUtf8("RelaysDialog"));
    RelaysDialog->setWindowModality(Qt::ApplicationModal);
    buttonBox = new QDialogButtonBox(RelaysDialog);
    buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
    buttonBox->setGeometry(QRect(328, 150, 91, 27));
    buttonBox->setOrientation(Qt::Horizontal);
    buttonBox->setStandardButtons(QDialogButtonBox::Close);
    uiBtnApply = new QPushButton(RelaysDialog);
    uiBtnApply->setObjectName(QString::fromUtf8("uiBtnApply"));
    uiBtnApply->setGeometry(QRect(252, 150, 75, 27));
    uiGrpRelays = new QGroupBox(RelaysDialog);
    uiGrpRelays->setObjectName(QString::fromUtf8("uiGrpRelays"));
    uiGrpRelays->setGeometry(QRect(10, 0, 411, 131));
    uiChkRelay2 = new QCheckBox(uiGrpRelays);
    uiChkRelay2->setObjectName(QString::fromUtf8("uiChkRelay2"));
    uiChkRelay2->setGeometry(QRect(67, 31, 39, 21));
    uiChkRelay3 = new QCheckBox(uiGrpRelays);
    uiChkRelay3->setObjectName(QString::fromUtf8("uiChkRelay3"));
    uiChkRelay3->setGeometry(QRect(112, 31, 40, 21));
    uiChkRelay4 = new QCheckBox(uiGrpRelays);
    uiChkRelay4->setObjectName(QString::fromUtf8("uiChkRelay4"));
    uiChkRelay4->setGeometry(QRect(158, 31, 40, 21));
    uiChkRelay12 = new QCheckBox(uiGrpRelays);
    uiChkRelay12->setObjectName(QString::fromUtf8("uiChkRelay12"));
    uiChkRelay12->setGeometry(QRect(158, 71, 41, 21));
    uiChkRelay5 = new QCheckBox(uiGrpRelays);
    uiChkRelay5->setObjectName(QString::fromUtf8("uiChkRelay5"));
    uiChkRelay5->setGeometry(QRect(204, 31, 39, 21));
    uiChkRelay13 = new QCheckBox(uiGrpRelays);
    uiChkRelay13->setObjectName(QString::fromUtf8("uiChkRelay13"));
    uiChkRelay13->setGeometry(QRect(204, 71, 41, 21));
    uiChkRelay14 = new QCheckBox(uiGrpRelays);
    uiChkRelay14->setObjectName(QString::fromUtf8("uiChkRelay14"));
    uiChkRelay14->setGeometry(QRect(249, 71, 41, 21));
    uiChkRelay6 = new QCheckBox(uiGrpRelays);
    uiChkRelay6->setObjectName(QString::fromUtf8("uiChkRelay6"));
    uiChkRelay6->setGeometry(QRect(249, 31, 40, 21));
    uiChkRelay15 = new QCheckBox(uiGrpRelays);
    uiChkRelay15->setObjectName(QString::fromUtf8("uiChkRelay15"));
    uiChkRelay15->setGeometry(QRect(296, 71, 41, 21));
    uiChkRelay7 = new QCheckBox(uiGrpRelays);
    uiChkRelay7->setObjectName(QString::fromUtf8("uiChkRelay7"));
    uiChkRelay7->setGeometry(QRect(296, 31, 39, 21));
    uiChkRelay8 = new QCheckBox(uiGrpRelays);
    uiChkRelay8->setObjectName(QString::fromUtf8("uiChkRelay8"));
    uiChkRelay8->setGeometry(QRect(343, 31, 40, 21));
    uiChkRelay16 = new QCheckBox(uiGrpRelays);
    uiChkRelay16->setObjectName(QString::fromUtf8("uiChkRelay16"));
    uiChkRelay16->setGeometry(QRect(343, 71, 41, 21));
    uiChkRelay10 = new QCheckBox(uiGrpRelays);
    uiChkRelay10->setObjectName(QString::fromUtf8("uiChkRelay10"));
    uiChkRelay10->setGeometry(QRect(67, 71, 41, 21));
    uiChkRelay11 = new QCheckBox(uiGrpRelays);
    uiChkRelay11->setObjectName(QString::fromUtf8("uiChkRelay11"));
    uiChkRelay11->setGeometry(QRect(112, 71, 41, 21));
    uiChkRelay09 = new QCheckBox(uiGrpRelays);
    uiChkRelay09->setObjectName(QString::fromUtf8("uiChkRelay09"));
    uiChkRelay09->setGeometry(QRect(21, 71, 34, 21));
    uiChkRelay17 = new QCheckBox(uiGrpRelays);
    uiChkRelay17->setObjectName(QString::fromUtf8("uiChkRelay17"));
    uiChkRelay17->setGeometry(QRect(21, 100, 151, 21));
    uiChkRelay1 = new QCheckBox(uiGrpRelays);
    uiChkRelay1->setObjectName(QString::fromUtf8("uiChkRelay1"));
    uiChkRelay1->setGeometry(QRect(21, 31, 40, 21));

    retranslateUi(RelaysDialog);

    QSize size(437, 190);
    size = size.expandedTo(RelaysDialog->minimumSizeHint());
    RelaysDialog->resize(size);

    QObject::connect(buttonBox, SIGNAL(rejected()), RelaysDialog, SLOT(close()));

    QMetaObject::connectSlotsByName(RelaysDialog);
    } // setupUi

    void retranslateUi(QDialog *RelaysDialog)
    {
    RelaysDialog->setWindowTitle(QApplication::translate("RelaysDialog", "Relays", 0, QApplication::UnicodeUTF8));
    uiBtnApply->setText(QApplication::translate("RelaysDialog", "Apply", 0, QApplication::UnicodeUTF8));
    uiGrpRelays->setTitle(QApplication::translate("RelaysDialog", "Select Relays to be triggered:", 0, QApplication::UnicodeUTF8));
    uiChkRelay2->setText(QApplication::translate("RelaysDialog", "2", 0, QApplication::UnicodeUTF8));
    uiChkRelay3->setText(QApplication::translate("RelaysDialog", "3", 0, QApplication::UnicodeUTF8));
    uiChkRelay4->setText(QApplication::translate("RelaysDialog", "4", 0, QApplication::UnicodeUTF8));
    uiChkRelay12->setText(QApplication::translate("RelaysDialog", "12", 0, QApplication::UnicodeUTF8));
    uiChkRelay5->setText(QApplication::translate("RelaysDialog", "5", 0, QApplication::UnicodeUTF8));
    uiChkRelay13->setText(QApplication::translate("RelaysDialog", "13", 0, QApplication::UnicodeUTF8));
    uiChkRelay14->setText(QApplication::translate("RelaysDialog", "14", 0, QApplication::UnicodeUTF8));
    uiChkRelay6->setText(QApplication::translate("RelaysDialog", "6", 0, QApplication::UnicodeUTF8));
    uiChkRelay15->setText(QApplication::translate("RelaysDialog", "15", 0, QApplication::UnicodeUTF8));
    uiChkRelay7->setText(QApplication::translate("RelaysDialog", "7", 0, QApplication::UnicodeUTF8));
    uiChkRelay8->setText(QApplication::translate("RelaysDialog", "8", 0, QApplication::UnicodeUTF8));
    uiChkRelay16->setText(QApplication::translate("RelaysDialog", "16", 0, QApplication::UnicodeUTF8));
    uiChkRelay10->setText(QApplication::translate("RelaysDialog", "10", 0, QApplication::UnicodeUTF8));
    uiChkRelay11->setText(QApplication::translate("RelaysDialog", "11", 0, QApplication::UnicodeUTF8));
    uiChkRelay09->setText(QApplication::translate("RelaysDialog", "9", 0, QApplication::UnicodeUTF8));
    uiChkRelay17->setText(QApplication::translate("RelaysDialog", "17 - Alarm out Relay", 0, QApplication::UnicodeUTF8));
    uiChkRelay1->setText(QApplication::translate("RelaysDialog", "1", 0, QApplication::UnicodeUTF8));
    Q_UNUSED(RelaysDialog);
    } // retranslateUi

};

namespace Ui {
    class RelaysDialog: public Ui_RelaysDialog {};
} // namespace Ui

#endif // UI_RELAYSDIALOG_H
