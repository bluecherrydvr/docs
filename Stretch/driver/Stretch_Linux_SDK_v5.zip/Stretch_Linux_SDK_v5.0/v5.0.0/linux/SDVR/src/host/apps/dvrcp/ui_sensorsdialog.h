/********************************************************************************
** Form generated from reading ui file 'sensorsdialog.ui'
**
** Created: Mon Mar 30 21:53:04 2009
**      by: Qt User Interface Compiler version 4.2.2
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_SENSORSDIALOG_H
#define UI_SENSORSDIALOG_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QComboBox>
#include <QtGui/QDialog>
#include <QtGui/QDialogButtonBox>
#include <QtGui/QGroupBox>
#include <QtGui/QPushButton>

class Ui_SensorsCnfgDialog
{
public:
    QGroupBox *uiGrp1stCardSensors;
    QComboBox *uiComboSensor1Trigger;
    QComboBox *uiComboSensor2Trigger;
    QComboBox *uiComboSensor3Trigger;
    QComboBox *uiComboSensor4Trigger;
    QComboBox *uiComboSensor5Trigger;
    QComboBox *uiComboSensor6Trigger;
    QComboBox *uiComboSensor7Trigger;
    QComboBox *uiComboSensor8Trigger;
    QCheckBox *uiChkEnableSensor1;
    QCheckBox *uiChkEnableSensor2;
    QCheckBox *uiChkEnableSensor3;
    QCheckBox *uiChkEnableSensor4;
    QCheckBox *uiChkEnableSensor5;
    QCheckBox *uiChkEnableSensor6;
    QCheckBox *uiChkEnableSensor7;
    QCheckBox *uiChkEnableSensor8;
    QGroupBox *uiGrp2ndCardSensors;
    QCheckBox *uiChkEnableSensor09;
    QComboBox *uiComboSensor09Trigger;
    QCheckBox *uiChkEnableSensor10;
    QComboBox *uiComboSensor10Trigger;
    QCheckBox *uiChkEnableSensor11;
    QComboBox *uiComboSensor11Trigger;
    QCheckBox *uiChkEnableSensor12;
    QComboBox *uiComboSensor12Trigger;
    QCheckBox *uiChkEnableSensor13;
    QComboBox *uiComboSensor13Trigger;
    QCheckBox *uiChkEnableSensor14;
    QComboBox *uiComboSensor14Trigger;
    QComboBox *uiComboSensor15Trigger;
    QCheckBox *uiChkEnableSensor15;
    QComboBox *uiComboSensor16Trigger;
    QCheckBox *uiChkEnableSensor16;
    QPushButton *uiBtnEdgeTriggerAll;
    QPushButton *uiBtnEnableAll;
    QPushButton *uiBtnDisableAll;
    QPushButton *uiBtnLevelSensitiveAll;
    QDialogButtonBox *buttonBox;

    void setupUi(QDialog *SensorsCnfgDialog)
    {
    SensorsCnfgDialog->setObjectName(QString::fromUtf8("SensorsCnfgDialog"));
    SensorsCnfgDialog->setWindowModality(Qt::ApplicationModal);
    uiGrp1stCardSensors = new QGroupBox(SensorsCnfgDialog);
    uiGrp1stCardSensors->setObjectName(QString::fromUtf8("uiGrp1stCardSensors"));
    uiGrp1stCardSensors->setGeometry(QRect(20, 10, 411, 141));
    uiComboSensor1Trigger = new QComboBox(uiGrp1stCardSensors);
    uiComboSensor1Trigger->setObjectName(QString::fromUtf8("uiComboSensor1Trigger"));
    uiComboSensor1Trigger->setGeometry(QRect(66, 20, 104, 22));
    uiComboSensor2Trigger = new QComboBox(uiGrp1stCardSensors);
    uiComboSensor2Trigger->setObjectName(QString::fromUtf8("uiComboSensor2Trigger"));
    uiComboSensor2Trigger->setGeometry(QRect(66, 50, 104, 22));
    uiComboSensor3Trigger = new QComboBox(uiGrp1stCardSensors);
    uiComboSensor3Trigger->setObjectName(QString::fromUtf8("uiComboSensor3Trigger"));
    uiComboSensor3Trigger->setGeometry(QRect(66, 80, 104, 22));
    uiComboSensor4Trigger = new QComboBox(uiGrp1stCardSensors);
    uiComboSensor4Trigger->setObjectName(QString::fromUtf8("uiComboSensor4Trigger"));
    uiComboSensor4Trigger->setGeometry(QRect(66, 110, 104, 22));
    uiComboSensor5Trigger = new QComboBox(uiGrp1stCardSensors);
    uiComboSensor5Trigger->setObjectName(QString::fromUtf8("uiComboSensor5Trigger"));
    uiComboSensor5Trigger->setGeometry(QRect(286, 20, 104, 22));
    uiComboSensor6Trigger = new QComboBox(uiGrp1stCardSensors);
    uiComboSensor6Trigger->setObjectName(QString::fromUtf8("uiComboSensor6Trigger"));
    uiComboSensor6Trigger->setGeometry(QRect(286, 50, 104, 22));
    uiComboSensor7Trigger = new QComboBox(uiGrp1stCardSensors);
    uiComboSensor7Trigger->setObjectName(QString::fromUtf8("uiComboSensor7Trigger"));
    uiComboSensor7Trigger->setGeometry(QRect(286, 80, 104, 22));
    uiComboSensor8Trigger = new QComboBox(uiGrp1stCardSensors);
    uiComboSensor8Trigger->setObjectName(QString::fromUtf8("uiComboSensor8Trigger"));
    uiComboSensor8Trigger->setGeometry(QRect(286, 110, 104, 22));
    uiChkEnableSensor1 = new QCheckBox(uiGrp1stCardSensors);
    uiChkEnableSensor1->setObjectName(QString::fromUtf8("uiChkEnableSensor1"));
    uiChkEnableSensor1->setGeometry(QRect(20, 20, 40, 21));
    uiChkEnableSensor2 = new QCheckBox(uiGrp1stCardSensors);
    uiChkEnableSensor2->setObjectName(QString::fromUtf8("uiChkEnableSensor2"));
    uiChkEnableSensor2->setGeometry(QRect(20, 50, 39, 21));
    uiChkEnableSensor3 = new QCheckBox(uiGrp1stCardSensors);
    uiChkEnableSensor3->setObjectName(QString::fromUtf8("uiChkEnableSensor3"));
    uiChkEnableSensor3->setGeometry(QRect(20, 80, 40, 21));
    uiChkEnableSensor4 = new QCheckBox(uiGrp1stCardSensors);
    uiChkEnableSensor4->setObjectName(QString::fromUtf8("uiChkEnableSensor4"));
    uiChkEnableSensor4->setGeometry(QRect(20, 110, 40, 21));
    uiChkEnableSensor5 = new QCheckBox(uiGrp1stCardSensors);
    uiChkEnableSensor5->setObjectName(QString::fromUtf8("uiChkEnableSensor5"));
    uiChkEnableSensor5->setGeometry(QRect(240, 20, 39, 21));
    uiChkEnableSensor6 = new QCheckBox(uiGrp1stCardSensors);
    uiChkEnableSensor6->setObjectName(QString::fromUtf8("uiChkEnableSensor6"));
    uiChkEnableSensor6->setGeometry(QRect(240, 50, 40, 21));
    uiChkEnableSensor7 = new QCheckBox(uiGrp1stCardSensors);
    uiChkEnableSensor7->setObjectName(QString::fromUtf8("uiChkEnableSensor7"));
    uiChkEnableSensor7->setGeometry(QRect(240, 80, 39, 21));
    uiChkEnableSensor8 = new QCheckBox(uiGrp1stCardSensors);
    uiChkEnableSensor8->setObjectName(QString::fromUtf8("uiChkEnableSensor8"));
    uiChkEnableSensor8->setGeometry(QRect(240, 110, 40, 21));
    uiGrp2ndCardSensors = new QGroupBox(SensorsCnfgDialog);
    uiGrp2ndCardSensors->setObjectName(QString::fromUtf8("uiGrp2ndCardSensors"));
    uiGrp2ndCardSensors->setGeometry(QRect(20, 160, 411, 141));
    uiChkEnableSensor09 = new QCheckBox(uiGrp2ndCardSensors);
    uiChkEnableSensor09->setObjectName(QString::fromUtf8("uiChkEnableSensor09"));
    uiChkEnableSensor09->setGeometry(QRect(20, 20, 40, 21));
    uiComboSensor09Trigger = new QComboBox(uiGrp2ndCardSensors);
    uiComboSensor09Trigger->setObjectName(QString::fromUtf8("uiComboSensor09Trigger"));
    uiComboSensor09Trigger->setGeometry(QRect(66, 20, 104, 22));
    uiChkEnableSensor10 = new QCheckBox(uiGrp2ndCardSensors);
    uiChkEnableSensor10->setObjectName(QString::fromUtf8("uiChkEnableSensor10"));
    uiChkEnableSensor10->setGeometry(QRect(20, 50, 39, 21));
    uiComboSensor10Trigger = new QComboBox(uiGrp2ndCardSensors);
    uiComboSensor10Trigger->setObjectName(QString::fromUtf8("uiComboSensor10Trigger"));
    uiComboSensor10Trigger->setGeometry(QRect(66, 50, 104, 22));
    uiChkEnableSensor11 = new QCheckBox(uiGrp2ndCardSensors);
    uiChkEnableSensor11->setObjectName(QString::fromUtf8("uiChkEnableSensor11"));
    uiChkEnableSensor11->setGeometry(QRect(20, 80, 40, 21));
    uiComboSensor11Trigger = new QComboBox(uiGrp2ndCardSensors);
    uiComboSensor11Trigger->setObjectName(QString::fromUtf8("uiComboSensor11Trigger"));
    uiComboSensor11Trigger->setGeometry(QRect(66, 80, 104, 22));
    uiChkEnableSensor12 = new QCheckBox(uiGrp2ndCardSensors);
    uiChkEnableSensor12->setObjectName(QString::fromUtf8("uiChkEnableSensor12"));
    uiChkEnableSensor12->setGeometry(QRect(20, 110, 40, 21));
    uiComboSensor12Trigger = new QComboBox(uiGrp2ndCardSensors);
    uiComboSensor12Trigger->setObjectName(QString::fromUtf8("uiComboSensor12Trigger"));
    uiComboSensor12Trigger->setGeometry(QRect(66, 110, 104, 22));
    uiChkEnableSensor13 = new QCheckBox(uiGrp2ndCardSensors);
    uiChkEnableSensor13->setObjectName(QString::fromUtf8("uiChkEnableSensor13"));
    uiChkEnableSensor13->setGeometry(QRect(240, 20, 39, 21));
    uiComboSensor13Trigger = new QComboBox(uiGrp2ndCardSensors);
    uiComboSensor13Trigger->setObjectName(QString::fromUtf8("uiComboSensor13Trigger"));
    uiComboSensor13Trigger->setGeometry(QRect(286, 20, 104, 22));
    uiChkEnableSensor14 = new QCheckBox(uiGrp2ndCardSensors);
    uiChkEnableSensor14->setObjectName(QString::fromUtf8("uiChkEnableSensor14"));
    uiChkEnableSensor14->setGeometry(QRect(240, 50, 40, 21));
    uiComboSensor14Trigger = new QComboBox(uiGrp2ndCardSensors);
    uiComboSensor14Trigger->setObjectName(QString::fromUtf8("uiComboSensor14Trigger"));
    uiComboSensor14Trigger->setGeometry(QRect(286, 50, 104, 22));
    uiComboSensor15Trigger = new QComboBox(uiGrp2ndCardSensors);
    uiComboSensor15Trigger->setObjectName(QString::fromUtf8("uiComboSensor15Trigger"));
    uiComboSensor15Trigger->setGeometry(QRect(286, 80, 104, 22));
    uiChkEnableSensor15 = new QCheckBox(uiGrp2ndCardSensors);
    uiChkEnableSensor15->setObjectName(QString::fromUtf8("uiChkEnableSensor15"));
    uiChkEnableSensor15->setGeometry(QRect(240, 80, 39, 21));
    uiComboSensor16Trigger = new QComboBox(uiGrp2ndCardSensors);
    uiComboSensor16Trigger->setObjectName(QString::fromUtf8("uiComboSensor16Trigger"));
    uiComboSensor16Trigger->setGeometry(QRect(286, 110, 104, 22));
    uiChkEnableSensor16 = new QCheckBox(uiGrp2ndCardSensors);
    uiChkEnableSensor16->setObjectName(QString::fromUtf8("uiChkEnableSensor16"));
    uiChkEnableSensor16->setGeometry(QRect(240, 110, 40, 21));
    uiBtnEdgeTriggerAll = new QPushButton(SensorsCnfgDialog);
    uiBtnEdgeTriggerAll->setObjectName(QString::fromUtf8("uiBtnEdgeTriggerAll"));
    uiBtnEdgeTriggerAll->setGeometry(QRect(440, 110, 116, 27));
    uiBtnEnableAll = new QPushButton(SensorsCnfgDialog);
    uiBtnEnableAll->setObjectName(QString::fromUtf8("uiBtnEnableAll"));
    uiBtnEnableAll->setGeometry(QRect(440, 20, 116, 25));
    uiBtnDisableAll = new QPushButton(SensorsCnfgDialog);
    uiBtnDisableAll->setObjectName(QString::fromUtf8("uiBtnDisableAll"));
    uiBtnDisableAll->setGeometry(QRect(440, 50, 116, 25));
    uiBtnLevelSensitiveAll = new QPushButton(SensorsCnfgDialog);
    uiBtnLevelSensitiveAll->setObjectName(QString::fromUtf8("uiBtnLevelSensitiveAll"));
    uiBtnLevelSensitiveAll->setGeometry(QRect(440, 141, 116, 27));
    buttonBox = new QDialogButtonBox(SensorsCnfgDialog);
    buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
    buttonBox->setGeometry(QRect(380, 310, 180, 41));
    buttonBox->setOrientation(Qt::Horizontal);
    buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
    buttonBox->setCenterButtons(true);

    retranslateUi(SensorsCnfgDialog);

    QSize size(566, 358);
    size = size.expandedTo(SensorsCnfgDialog->minimumSizeHint());
    SensorsCnfgDialog->resize(size);

    QObject::connect(buttonBox, SIGNAL(rejected()), SensorsCnfgDialog, SLOT(close()));
    QObject::connect(buttonBox, SIGNAL(accepted()), SensorsCnfgDialog, SLOT(accept()));

    QMetaObject::connectSlotsByName(SensorsCnfgDialog);
    } // setupUi

    void retranslateUi(QDialog *SensorsCnfgDialog)
    {
    SensorsCnfgDialog->setWindowTitle(QApplication::translate("SensorsCnfgDialog", "Sensor Configuration", 0, QApplication::UnicodeUTF8));
    uiGrp1stCardSensors->setTitle(QApplication::translate("SensorsCnfgDialog", "Sensors on 1st Card:", 0, QApplication::UnicodeUTF8));
    uiChkEnableSensor1->setText(QApplication::translate("SensorsCnfgDialog", "1", 0, QApplication::UnicodeUTF8));
    uiChkEnableSensor2->setText(QApplication::translate("SensorsCnfgDialog", "2", 0, QApplication::UnicodeUTF8));
    uiChkEnableSensor3->setText(QApplication::translate("SensorsCnfgDialog", "3", 0, QApplication::UnicodeUTF8));
    uiChkEnableSensor4->setText(QApplication::translate("SensorsCnfgDialog", "4", 0, QApplication::UnicodeUTF8));
    uiChkEnableSensor5->setText(QApplication::translate("SensorsCnfgDialog", "5", 0, QApplication::UnicodeUTF8));
    uiChkEnableSensor6->setText(QApplication::translate("SensorsCnfgDialog", "6", 0, QApplication::UnicodeUTF8));
    uiChkEnableSensor7->setText(QApplication::translate("SensorsCnfgDialog", "7", 0, QApplication::UnicodeUTF8));
    uiChkEnableSensor8->setText(QApplication::translate("SensorsCnfgDialog", "8", 0, QApplication::UnicodeUTF8));
    uiGrp2ndCardSensors->setTitle(QApplication::translate("SensorsCnfgDialog", "Sensors on 2nd Card:", 0, QApplication::UnicodeUTF8));
    uiChkEnableSensor09->setText(QApplication::translate("SensorsCnfgDialog", "09", 0, QApplication::UnicodeUTF8));
    uiChkEnableSensor10->setText(QApplication::translate("SensorsCnfgDialog", "10", 0, QApplication::UnicodeUTF8));
    uiChkEnableSensor11->setText(QApplication::translate("SensorsCnfgDialog", "11", 0, QApplication::UnicodeUTF8));
    uiChkEnableSensor12->setText(QApplication::translate("SensorsCnfgDialog", "12", 0, QApplication::UnicodeUTF8));
    uiChkEnableSensor13->setText(QApplication::translate("SensorsCnfgDialog", "13", 0, QApplication::UnicodeUTF8));
    uiChkEnableSensor14->setText(QApplication::translate("SensorsCnfgDialog", "14", 0, QApplication::UnicodeUTF8));
    uiChkEnableSensor15->setText(QApplication::translate("SensorsCnfgDialog", "15", 0, QApplication::UnicodeUTF8));
    uiChkEnableSensor16->setText(QApplication::translate("SensorsCnfgDialog", "16", 0, QApplication::UnicodeUTF8));
    uiBtnEdgeTriggerAll->setText(QApplication::translate("SensorsCnfgDialog", "Edge Trigger All", 0, QApplication::UnicodeUTF8));
    uiBtnEnableAll->setText(QApplication::translate("SensorsCnfgDialog", "Enable All", 0, QApplication::UnicodeUTF8));
    uiBtnDisableAll->setText(QApplication::translate("SensorsCnfgDialog", "Disable All", 0, QApplication::UnicodeUTF8));
    uiBtnLevelSensitiveAll->setText(QApplication::translate("SensorsCnfgDialog", "Level Sensitive All", 0, QApplication::UnicodeUTF8));
    Q_UNUSED(SensorsCnfgDialog);
    } // retranslateUi

};

namespace Ui {
    class SensorsCnfgDialog: public Ui_SensorsCnfgDialog {};
} // namespace Ui

#endif // UI_SENSORSDIALOG_H
