//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by TestPlayers.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             102
#define IDR_MAINFRAME                   128
#define IDR_TestPlayersTYPE             129
#define IDD_DIALOG_NEW                  131
#define IDD_DIALOG_ZOOM                 132
#define IDC_EDIT1                       1000
#define IDC_EDIT2                       1001
#define IDC_EDIT3                       1002
#define IDC_EDIT4                       1003
#define IDC_EDIT5                       1004
#define IDC_RADIO1                      1011
#define IDC_RADIO2                      1012
#define IDC_RADIO3                      1013
#define ID_ACTION_PLAY                  32772
#define ID_ACTION_STOP                  32773
#define ID_ACTION_PAUSE                 32774
#define ID_SLIDER                       32775
#define ID_FILE_OPENSTREAM              32776
#define ID_ACTION_FASTFWD               32778
#define ID_ACTION_FASTREV               32779
#define ID_ACTION_STEPFWD               32780
#define ID_ACTION_STEPBWD               32781
#define ID_ACTION_CAPTURE               32783
#define ID_ACTION_SETDECODE             32786
#define ID_ACTION_ZOOM                  32787

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32788
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
