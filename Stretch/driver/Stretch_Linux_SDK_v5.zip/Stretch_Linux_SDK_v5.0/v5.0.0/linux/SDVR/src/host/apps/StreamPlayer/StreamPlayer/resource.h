//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MovPlayer.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_MOVPLAYER_DIALOG            102
#define IDR_MAINFRAME                   128
#define IDC_VIDWIN                      1000
#define IDC_BITRATE                     1005
#define IDC_PLAY                        1009
#define IDC_PAUSE                       1010
#define IDC_STOP                        1011
#define IDC_OPENFILE                    1024
#define IDC_TIMESLIDER0                 1026
#define IDC_TIMESLIDER                  1026
#define IDC_FASTPLAY                    1027
#define IDC_SLOWPLAY                    1028
#define IDC_PLAYRATE                    1029
#define IDC_NEXTFRAME                   1030
#define IDC_PREVFRAME                   1031
#define IDC_RTP_STREAM                  1034
#define IDC_SDP_NAME                    1035
#define IDC_LIST1                       1036
#define IDC_LIST2                       1037
#define IDC_STATUS                      1038

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1039
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
