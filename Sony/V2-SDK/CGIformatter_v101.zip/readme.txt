Sony IPcamera CGI command list
	This includes CGI commands of most of the SONY IPcamera.
	Useful functionalities are;
	1. All parameters of all models are compared to the parameters of the 
	   reference model which you can specify.
	2. All parameters of one model can be extracted.
	3. Comparison of available commands is also possible.

	4. Sort or grep is possible using excel's auto-filter.

Preparation
	1. Download the package at any directory in your PC.
	2. Un-zip the package to have three files.
		a. readme.txt  (This file)
		b. CGIformatter.xls
		c. CGImaster.xls (read-only)
	3. Open CGIformatter.xls with macro function enabled
	   If you have a front page with three big buttons, you are ready.
	   You may see the popup saying that you have to lower the security
	   level by changing the setting of tool->macro.

Getting started
	1.1. Press the left bottom button named "CGI cmd / All models".
	1.2. The popup for specifying input file comes out with the default
	     "CGImaster.xls".  Press OK.
	1.3. The popup for specifying output file comes out.  Fill out with
	     a name you like.  For example, type "qaz".  Don't bother with the suffix,
	     xls will be attached.  Press OK.
	1.4. After a few seconds, you will have a file called "qaz.xls" in the current 
	     directory where you have CGIformatter.xls. Open it and you will find the 
	     models of the IP camera horizontally, and cgi commands vertically, and the 
	     items that are the same as the reference model SMC-CS50 are painted in green.

	2.1. Press the right top button named "Parameter / One model".
	2.2. The popup comes out for specifying one model.
	     For SNC-DF50, DF50 will be understood as it's correct partial name
	     and also unique. Also not case-sensitive, i.e. df50 will do.
	     Additionally for the people familiar with N or P suffix like
	     df50n or df50p will also be understood. However there is no 
	     differenciation as a command list between NTSC and PAL model.
	2.3. The popup for specifying input file comes out with the default
	     "CGImaster.xls".  Press OK.
	2.4. The popup for specifying output file comes out.  Fill out with
	     a name you like.  For example, type "wsx".  Don't bother with the suffix,
	     xls will be attached.  Press OK.
	2.5. After 30 seconds, you will have a file called "wsx.xls" in the current 
	     directory where you have CGIformatter.xls. Open it and you will find all the 
	     parameters available for SNC-DF50 in one-parameter-per-line style. 
	     Ther format is the same as the separately released CGI command document for 
	     each model. The last column (most to the right) contains the comment
	     in Japanese. If not interested, ignore them.   And again, the items that are 
	     the same as the reference model SMC-CS50 are painted in green.
	     You may notice that the top row has "auto-filter" buttons to sort or grep
	     as you like to focus perticular area.

	3.1. Press the left top button named "Parameter / All models".
	3.2. The popup for specifying input file comes out with the default
	     "CGImaster.xls".  Press OK.
	3.3. The popup for specifying output file comes out.  Fill out with
	     a name you like.  For example, type "edc".  Don't bother with the suffix,
	     xls will be attached.  Press OK.
	3.4. After 30 seconds, you will have a file called "edc.xls" in the current 
	     directory where you have CGIformatter.xls. Open it and you will find all the 
	     parameters available for SNC-DF50 in one-parameter-per-8lines style. 
	     This is the same information as the CGImaster.xls in a different format.
	     This one-parameter-per-8lines is useful for human as it's not too wide.
	     (if you don't believe it, have a look at CGImaster.xls which is formatted in 
	     one-parameter-per-line to see how awful.)  Drawback is that "auto-filter"
	     cannot be used as is not in one-parameter-per-line format.

	3.5. Lastly, have a look at CGIformatter.xls.  There is a green cell for the
	     reference model. You can change it as you like. The naming convention is 
	     the same as specifying the model name in 2.2 above.
	     
Version:
	CGIformatter.xls	v1.00	issued at 2007/3/2
	CGImaster_ver1_01.xls	v1.01	issued at 2007/11/28
